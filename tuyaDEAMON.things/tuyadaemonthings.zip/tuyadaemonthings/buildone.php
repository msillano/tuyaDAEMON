<?php

function doOneThing($aTingId, $path)
{
/*
echo "<pre>";
echo "aTingId = $aTingId";
echo "</pre>";
*/
    $sqlquery = "SELECT * FROM  allthings WHERE thingID = $aTingId;";
    $res   = sqlArrayTot($sqlquery);
    $thing = $res[0];
    echo  "... processing Thing ID $aTingId ( a '".$thing["deviceName"]."')<br>";
// device file (by tuyadaemontoolkit)
    $filein = $path .DIRECTORY_SEPARATOR. 'device_' . ($thing["deviceName"]?$thing["deviceName"]:"NULL") . ".json";
// ---- debug
//    $fileout = $path .DIRECTORY_SEPARATOR. 'thing_' . toFileName($thing["thingName"]) . ".new.json";
//    echo "<i>alldevices.json</i> fragment for thing '" . $thing["thingName"] . "' ( device <i>" . $thing["deviceName"] . "</i>)<br>";
// echo "<pre>";
// echo print_r($thing);
// echo "</pre>";

    $thisthing = new stdClass();
    $thisthing->name = $thing["thingName"];
// note: in alldevices virtual things don't have id (using CID).
// in DB, for access problems, id == name | tuyaID
    if (strlen($thing["tuyaCID"]) > 5) {
            $thisthing->cid = $thing["tuyaCID"];
            $thisthing->gateway = $thing["tuyaGateway"];
        } else {
            $thisthing->id   = $thing["tuyaID"];
 	    	}
  // defined here for a correct field's sequence
	 $thisthing->comment = isset($thing["comment"])?$thing["comment"]:null;
	 $thisthing->device = null;
   $thisthing->capability =null;

   echo "... updated basic device data.<hr>";

   if (file_exists($filein))
       {
        $data = json_decode(file_get_contents($filein));
        unset($data->name);  // cleanup if present,
        unset($data->id);    // cleanup if present,

        $thisthing =(object)array_merge((array) $thisthing, (array) $data);
	 if (json_last_error() != JSON_ERROR_NONE)
		 echo  "+++ JSON Error - verify $filein";
    }
    else
    {
      if($thing["deviceName"])
        echo "+++ WARNING: Device file <code>device_" . $thing["deviceName"] . ".json</code> NOT found.<br>";
      else
        echo "+++ WARNING: Device not defined for thing ".$thing["thingName"]."...<br>";
   }


    // adds extra
    $sqlquery = "SELECT * FROM  specialthing WHERE thingID =  $aTingId  AND DPkey < 0 ;";
    $extras = sqlArrayTot($sqlquery);

    foreach ($extras as $more)
    {
      $key = $more[4] ;
      $kvalue =  trim(restoreValue($more[5]) , "\"");
      if ((strncmp($kvalue, "{", 1) === 0) || (strncmp($kvalue, "[", 1) === 0) ){
         $thisthing->$key = json_decode($kvalue);
		     if (json_last_error() != JSON_ERROR_NONE)
		     		echo  "+++ JSON Error - verify <b>newValue</b>";
         } else {
         $thisthing->$key = $kvalue;
         }
        echo "... added special to <i>device.$key</i> => $kvalue  <br>";
    }
    // adds extra dp
    $sqlquery = "SELECT * FROM  specialthing WHERE thingID = $aTingId AND DPkey != -1 ;";
    $extras = sqlArrayTot($sqlquery);

    if (count($extras) > 0){
	        if (!isset($thisthing->dps))
                      $thisthing->dps = array();
		foreach ($extras as $more)
		{
	    	$dp = $more[3];
		$key = $more[4];
			if (isset($thisthing->dps)) foreach ($thisthing->dps as $adp)
			{
				if ($adp->dp == $dp)
				{
					$adp->$key = trim(restoreValue($more[5]) , "\"");
					echo "... updated existing <i>DP[$dp].$key</i> => " . trim(restoreValue($more[5]) , "\"") . "<br>";
					$dp = "--";
				}
			}
			if ($dp !== "--")
			{
				// new dp
				$newdp = new stdClass();
				$newdp->dp = $dp;
				$newdp->$key = trim(restoreValue($more[5]) , "\"");
				array_push($thisthing->dps, $newdp);
				echo "... added special <i>DP[$dp].$key</i> => " . trim(restoreValue($more[5]) , "\"") . "<br>";
			}
		}
	}
  else
  {
      echo "... there are no <code>extras</code> to add to this thing.<br>";
  }

    echo "<hr>";

    // add shares
    $sharenames = sqlArrayTot("SELECT DISTINCT shareName FROM sharething WHERE thingID = $aTingId ;");
    if (count($sharenames) > 0)
    {
        foreach ($sharenames as $onename)
        {
            $onegroup = $onename['shareName'];
            $thishare = sqlArrayTot("SELECT * FROM sharething WHERE thingID = $aTingId AND shareName = '$onegroup' ;");
            $model = $thishare[0];

            $newshare = new stdClass();
		      	$newshare->name = $onegroup;
            foreach ($thishare as $element)
            {
                if ($element['type'] === "test")
                {
                    if (!isset($newshare->test)) $newshare->test = [];
                    array_push($newshare->test, trim(restoreValue($element["eval_test"]) , "\""));
                }
                else
                {
                    if (!isset($newshare->action)) $newshare->action = [];
                    $newaction = new stdClass();
             //       if (isset($element["remote"]) &&($element["remote"] != 'undefined')) $newaction->remote = trim(restoreValue($element["remote"]) , "\"");
				    if (isset($element["remote"])){
                   		if ($element["remote"] === 'NULL') $newaction->remote = NULL;
                        else if ($element["remote"] != 'undefined')	 $newaction->remote = trim(restoreValue($element["remote"]) , "\"");
					}

                    if (isset($element["device"])){
                   		if ($element["device"] === 'NULL') $newaction->device = NULL;
                        else if ($element["device"] != 'undefined')
							$newaction->device = trim(restoreValue($element["device"]) , "\"");
					}
			        if (isset($element["property"])){
                   		if ($element["property"] === 'NULL') $newaction->property = NULL;
                        else if ($element["property"] != 'undefined')
							$newaction->property = trim(restoreValue($element["property"]) , "\"");
					}
                   if (isset($element["str_value"])){
                   		if ($element["str_value"] === 'NULL') $newaction->value = NULL;
                        else if ($element["str_value"] != 'undefined') {
 							 $newaction->value = json_decode(restoreValue($element["str_value"]));
							 if (json_last_error() != JSON_ERROR_NONE)
                                 $newaction->value = restoreValue($element["str_value"]);
						}
					}
                     array_push($newshare->action, $newaction);
                }
             }


			$dp = $model['DPkey'];

			foreach ($thisthing->dps as $adp)
			{
				if ($adp->dp == $dp)
				{
					if (!isset($adp->share)) $adp->share = [];
					array_push($adp->share, $newshare);
					echo "... added special <i>DP[$dp].share($onegroup)</i> " . "<br>";
				}
			}
        }
    }
    else
    {
        echo "... there are no <code>shares</code> to add to this thing.<br>";
    }
// clean-up
  if ($thisthing->comment === null) unset($thisthing->comment);
  if ($thisthing->capability === null) unset($thisthing->capability);
  if ($thisthing->device === null) unset($thisthing->device);

 // -----------------  save as file (debug))
    // file_put_contents($fileout, restoreValue(json_encode($thisthing, JSON_PRETTY_PRINT)));
	// if (json_last_error() != JSON_ERROR_NONE)
	//			echo  "+++ JSON output encode Error - verify <b>output</b>";

  return ($thisthing);
}

?>
