
Tuyadaemon things:  


Unzip in web dir:
example:
  …/htdocs/tuyadaemonthings/

config: update the files
       lib/commonSQL.php  // db access
       commonTuya.php        // file path


DBstructure
    tuyathome_things.sql.zip

   Use the sql file to build the tables ( in ’tuyathome’ db):
      lookupserver (you can edit it)
     allthings
     specialthing
     sharething
