<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$r = dirname(__FILE__);
require_once("$r/lib/commonSQL.php"); // library + DB acess def
require_once("$r/commonTuya.php");    // utilities
//
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo '<title>TuyaDEAMON Things</title>';
echo StyleSheet();
echo "</head><body>";

if (file_exists("$r/setupdata.tmp.php")) {
    require_once("$r/setupdata.tmp.php"); // data from setup
} else {
    echo "<div class=error>Can't find the file <i> $r/setupdata.tmp.php. </i><br>";
    echo" Please do the <b>Setup config file</b> step before.</div>";
    exit;
}

// --------------- start tests
if (isset($_GET['adfile'])) {
    $_POST = $_GET; // POST/GET compatible
}

if (isset($_POST["adfile"])) {
    echo "<h3>parsing alldevices file <i>'".$_POST["adfile"]."'</i>, overwriting DB data... </h3>";
} else {
    echo '<div class="error">This page requires some parameters: you can\'t open it directly.<BR>
    Start from the <a href="index.php">index page.</a>';
    exit;
}

echo "<pre>";
echo print_r($_POST);
echo "</pre>";

//  read max value from DB
 $scount =  sqlValue("SELECT IFNULL(MAX(CAST(SUBSTRING(shareName, 7) AS UNSIGNED)),0) FROM `sharething` ");

// ------------- functions

function capabilityNum($avalue) {

  $n = 0;
  if (!is_array($avalue)) return $n;
  $astring = implode(" ", $avalue);
  //  ALL SET GET SCHEMA MULTIPLE REFRESH NONE
  if (strpos($astring, 'ALL') !== false)
    $n += 1;
    if (strpos($astring, 'SET') !== false)
      $n += 2;
      if (strpos($astring, 'GET') !== false)
        $n += 4;
        if (strpos($astring, 'SCHEMA') !== false)
          $n += 8;
          if (strpos($astring, 'MULTIPLE') !== false)
            $n += 16;
            if (strpos($astring, 'REFRESH') !== false)
              $n += 32;
              if (strpos($astring, 'NONE') !== false)
                $n += 64;
      return $n;
}

function getDvName($thing) {
    if (isset($thing->device) && ($thing->device != NULL)) return $thing->device;
    $dvName = sqlValue("SELECT deviceName FROM `allthings` WHERE `thingName` = '$thing->name'");
    if (!isset($dvName) && isset($thing->id))
        $dvName = sqlValue("SELECT deviceName FROM `allthings` WHERE `tuyaID` = '$thing->id' ");
    if (isset($dvName)) return $dvName;
    return NULL;
}

function appendThing($type, $thing)
{
// normalize
  if ((!isset($thing->id)) && isset($thing->name))
		$thing->id = $thing->name ;

  if (!isset($thing->name))
		 $thing->name = NULL;

 // find by  ID
 if (isset($thing->id))
        $stored = sqlRecord("SELECT * FROM `allthings` WHERE `tuyaID` = '$thing->id' LIMIT 1;");
	else {
	    echo "++++ <b>ERROR: not defined id for the  '$thing->name' thing. Skipping <i>special</i> and <i>share</i>.</b><br>";
		return;
	}

    $akey = isset($stored['thingID'])?$stored['thingID']:NULL;
    $devn = getDvName($thing);
    if (isset($stored['thingID'])) {
        // record exists: update
        $mySQL =  "UPDATE `allthings` SET `thingName` = '$thing->name'";
        $mySQL .=  ", `deviceClass` = '$type'";
        if (property_exists($thing, 'device'))
            $mySQL .=  ", `deviceName` = '".getDvName($thing)."'";
        if (property_exists($thing, 'id') && (trim($thing->id) != ""))
            $mySQL .=  ", `tuyaID` = '$thing->id'";
        if (property_exists($thing, 'cid'))
            $mySQL .=  ", `tuyaCID`= '$thing->cid'";
        if ($type == 'real')
            $mySQL .=  ", `tuyaGateway` = NULL";
        else
            if (property_exists($thing, 'gateway'))
                $mySQL .=  ", `tuyaGateway` = '$thing->gateway'";
		if (property_exists($thing, 'comment'))
			    $mySQL .=  ", `comment` = '".cleanUpValue($thing->comment)."'";
        $mySQL .= " WHERE `thingID` = $akey ;";
        echo "<br>... DB <i>allthings</i> update $type thing <b>$thing->name</b> " . (isset($devn) ? "($devn)" : "(unknown device)") . "<br>";
    } else {
        // new record
        $mySQL = "REPLACE INTO `allthings` (`thingID`,`thingName`, `deviceClass`, `deviceName`, `tuyaID`, `tuyaCID`, `tuyaGateway`, `server`, `comment`)  VALUES ( ";
        $mySQL .= " NULL";
        $mySQL .= ", '$thing->name'";
        $mySQL .= ", '$type'";
        $mySQL .= ($devn == NULL)?", NULL":", '$devn'";
        $mySQL .= isset($thing->id) ? ", '$thing->id'" : ", NULL";
        $mySQL .= empty($thing->cid) ?", NULL": ", '$thing->cid'" ;
        if ($type == 'real')
            $mySQL .= ", NULL";
        else
            $mySQL .= isset($thing->gateway) ? ", '$thing->gateway'" : ", NULL";
	//  group UI
        $mySQL .= ", '".$_POST["key2"]."'";
		$mySQL .= empty($thing->comment) ?", NULL": ", '".cleanUpValue($thing->comment)."'" ;

        $mySQL .= " );";
        echo "<br>... DB <i>allthings</i> insert $type thing <b>$thing->name</b> " . (isset($devn) ? "($devn)" : "(unknown device)") . "<br>";
    }
    sql($mySQL);
}

function appendSpecial($thing_name, $dp, $key, $value, $ddp)
{
    if (isset($ddp-> {$key})) {
        $modelvalue = $ddp-> {$key};
    } else {
        $modelvalue = null;
    }
    if ($value === $modelvalue)
        return; // nothing to do
    $akey = sqlValue("SELECT thingID  FROM `allthings` WHERE `thingName` = '$thing_name'");
    if (!$akey)
        $akey = 'NULL';
    echo ".... <b>DP[$dp].$key</b> default: " . ($modelvalue == null ? 'null' : json_encode($modelvalue)) . "  ===> " . json_encode($value) . "<br>";
    $specialsql = 'REPLACE INTO `specialthing` (`thingID`, `thingName`, `DPkey`, `DPattribute`, `newValue`) VALUES ';
    $specialsql .= "('$akey', '$thing_name', '$dp', '$key', '" . cleanUpValue(json_encode($value)) . "' );";
	if (json_last_error() != JSON_ERROR_NONE)
				echo  "+++ JSON value encode Error - verify <b>value</b>";

    sql($specialsql);
}

    function fieldStore($af){
//		if (!isset($af)) return 'undefined';
		if ($af === null) return 'NULL';
		return is_string($af)? cleanUpValue($af): cleanUpValue(json_encode($af));
	}

function process_oneshare($akey, $tname, $dp, $key, $sname, $aShare)
{

    if (isset($aShare->test)) {
        $tcount = 1;
        foreach ($aShare->test as $test) {
            $shareql = 'INSERT INTO `sharething` (`thingID`, `thingName`, `DPkey`, `shareName`, `type`, `count`, `eval_test`) VALUES';
            $shareql .= "('$akey', '$tname', '$dp', '$sname', 'test', " . $tcount . ", '" . cleanUpValue($test) . "' );";
            //     $shareql .= "('$akey', '$tname', '$dp', '$sname', 'test','" . cleanUpValue(json_encode($test)) . "');";
            sql($shareql);

            echo ".... <b>DP[$dp].share[$sname].test[".$tcount++."]</b> ---> " . json_encode($test) . "<br>";
			if (json_last_error() != JSON_ERROR_NONE)
				echo  "+++ JSON test encode Error - verify <b>test</b>";

        }
    }
    if (isset($aShare->action)) {
        $acount = 1;

        foreach ($aShare->action as $action) {
			/*
			echo "<pre>";
            echo print_r($action);
            echo "</pre>";
            */
         $storeValue = "undefined";
         if (property_exists($action,'value'))	{
                if (empty($action->value))
                    $storeValue =  'NULL';
                else
                    $storeValue = is_string($action->value)? cleanUpValue($action->value): cleanUpValue(json_encode($action->value));
            }
	    if (json_last_error() != JSON_ERROR_NONE)
				echo  "+++ JSON value encode Error - verify <b>value</b>";

		$shareql = 'INSERT INTO `sharething` (`thingID`, `thingName`, `DPkey`, `shareName`, `type`,  `count`, `str_value`, `remote`, `device`, `property`) VALUES';
		$shareql .= "('$akey', '$tname', '$dp', '$sname', 'action', $acount,";
		$shareql .= "'$storeValue'," ;
//        $shareql .= (($storeValue == NULL) ? "NULL":"'$storeValue'").", " ;
		//       $shareql .= (isset($action->value) ? "'" . cleanUpValue(json_encode($action->value)) . "'," : " NULL, ");

		$shareql .= "'".(property_exists($action,'remote')? fieldStore($action->remote): 'undefined') . "', ";
		$shareql .= "'".(property_exists($action,'device')? fieldStore($action->device): 'undefined')   . "', ";
		$shareql .= "'".(property_exists($action,'property')? fieldStore($action->property): 'undefined')  . "'); ";
		sql($shareql);

            echo ".... <b>DP[$dp].share[$sname].action[".$acount++."]</b> ---> " . json_encode($action) . "<br>";
        }
    }
    /*
    echo "<pre>------ found share: \n";
    echo print_r($aShare);
    echo "</pre>";
    */
}



function appendShare($tname, $dp, $key, $share)
{
    global $scount;
    // else
    $akey = sqlValue("SELECT thingID  FROM `allthings` WHERE `thingName` = '$tname'");

    foreach ($share as $oneShare) {
        if ($oneShare === "_debug"){
          echo ".... <b>WARNING</b> found <i>'_debug'</i> flag (ignored) '<br>";
        } else {
          $sname = "share-" . ++$scount;
          if (isset($oneShare->name))
            $sname = $oneShare->name;
          process_oneshare($akey, $tname, $dp, $key, $sname, $oneShare);
        }
    }
}

function append_one($thing_name, $key, $value, $device)
{
    if (isset($device-> {$key})) {
        $modelvalue = $device-> {$key};
    } else {
        $modelvalue = null;
    }
    if ($value === $modelvalue)
        return; // nothing to do
    // special case for caopability
    if(($key === "capability") &&  (capabilityNum($value) === capabilityNum($modelvalue)))
        return; // nothing to do
    // else
    $akey = sqlValue("SELECT thingID  FROM `allthings` WHERE `thingName` = '$thing_name'");
    if (!$akey)
        $akey = 'NULL';
    echo ".... <b>$key</b> default: '" . ($modelvalue == null ? 'null' : json_encode($modelvalue)) . "'  ===> '" . json_encode($value) . "'<br>";
    $specialsql = 'REPLACE INTO `specialthing` (`thingID`, `thingName`, `DPkey`, `DPattribute`, `newValue`) VALUES ';
    $specialsql .= "('$akey', '$thing_name', -1, '$key', '" . cleanUpValue(json_encode($value)) . "');";
    sql($specialsql);
	if (json_last_error() != JSON_ERROR_NONE)
				echo  "+++ JSON value encode Error - verify <b>value</b>";

}

function do_onedp($tname, $tdp, $ddp)
{
    $i = 0;
    if ($ddp === null) {
        echo ".... Not found in the device the DP " . $tdp->dp . "<br>";
        $i = 1;
      }
    foreach ($tdp as $key => $value) {
        switch ($key) {
        case "dp":
            break;
        case "share":
          echo " FOUND SHARE <br>";
            appendShare($tname, $tdp->dp, (isset($tdp->name) ? $tdp->name : null), $value);
            break;
        case "name":
        case "typefield":
        case "capability":
        case "type":
        default:
  //        echo " FOUND DP ".(isset($tdp->name) ? $tdp->name : $tdp->dp).".$key: $value <br>";
          if (($ddp == null) || !(property_exists($ddp, $key) && ($value == $ddp->$key))) {
              $i = 0;
              appendSpecial($tname, $tdp->dp, $key, $value, $ddp);
              }
        }
    }
    if ($i > 0){
          appendSpecial($tname, $tdp->dp, "_comment", "added dp", $ddp);
    }
    /*
    echo "<pre>------ found dp: \n";
    echo print_r($tdp);
    echo print_r($ddp);
    echo "</pre>";
    */
}
function do_pds($tname, $xdp, $dpd)
{
  /*
  echo "<pre>------ do_pds(".$tname."): \n";
  echo print_r($xdp);
  echo print_r($dpd);
  echo "</pre>";
*/
    if (!is_array($dpd)) {
        do_onedp($tname, $xdp, null);
        return;
    }
    if (in_array($xdp, $dpd))
        return;
    foreach ($dpd as $element) {
        if ($xdp->dp == $element->dp) {
            do_onedp($tname, $xdp, $element);
            return;
        }
    }
    do_onedp($tname, $xdp, null);
}

function appendExtra($thing)
{
    global $BASEPATH;
    if (!isset($thing->id))
		return;
    $aDevice = getDvName($thing);
    if ($aDevice == null) {
        echo "++++ <b>WARNING: not defined device for thing '$thing->name'. </b><br>";
		$aDevice = 'none';
    }
    // cleanup
    $cleanSQL = "DELETE FROM sharething WHERE thingName = '$thing->name'  ; ";
    sql($cleanSQL);
    $cleanSQL = "DELETE FROM specialthing WHERE thingName = '$thing->name'   ; ";
    sql($cleanSQL);
    $devdef = "{ }";
  try {
    if ($aDevice != 'none') {
        $file_name = $BASEPATH . DIRECTORY_SEPARATOR . "device_" . $aDevice . ".json";
        if (file_exists($file_name))
           $devdef  = file_get_contents($file_name);
        else {
           echo "++++  <b>ERROR: file '<i>device_". $aDevice . ".json</i>' not found.</b><br>";
        }
    }
    $xdevice = json_decode($devdef);
    if (json_last_error() !== JSON_ERROR_NONE){
            echo "++++  <b>decoding <i>device_". $aDevice . ".json</i>: ERROR ". json_last_error_msg()."</b><br>";
          }
    }  catch (Throwable $t) {
          echo "<div class=error>FATAL ERROR: file <i>$file_name</i>  $t  JSON.</div>";
          exit;
    }

    foreach ($thing as $key => $value) {
        switch ($key) {
        case "device":
        case "name":
        case "id":
        case "cid":
        case "gateway":
            break; // not from device def
        case "dps":
            foreach ($thing->dps as $adp) {
                if (isset($adp->dp)) {
                    if (isset($xdevice->dps))
                        do_pds($thing->name, $adp, $xdevice->dps);
                    else
                        do_onedp($thing->name, $adp, null);
                } else
                    echo "<b>++++ ERROR: found malformed dp: " . json_encode($adp) . "</b><br>";
            }
            break;
        default:
            append_one($thing->name, $key, $value, $xdevice);
        }
    }
}
// ----------  main
$filein = $BASEPATH . DIRECTORY_SEPARATOR . $_POST["adfile"];
if (!file_exists($filein)) {
    echo "<div class=error>FATAL ERROR: file <i>$filein</i> not found.</div>";
    exit;
}
try {
    $data = file_get_contents($filein);
} catch (Throwable $t) {
    echo "<div class=error>FATAL ERROR: file <i>$filein</i> not found.</div>";
    exit;
}
if (strlen($data) < 10) {
    echo "<div class=error>FATAL ERROR: BAD data file.</div>";
    exit;
}

echo "Compares \"<i>$filein</i>\" with \"<i>devicedata/device_xxx.json\"</i><br>";
echo "<li> Differences are stored in 'specialthing' DB.<li> <code>share</code> are stored in 'sharething' DB. <br><br>";

echo "Process log:<br>";
echo "<ul> <li>The plus (+++) indicates a data ERROR: you should correct the problem before continuing. ";
echo "<li>The dots (...) indicates differences between the things in 'alldevices' and the standard devices definitions. ";
echo "<li> <i> You must evaluate if is required some update (in device definition or in alldevices) to reduce differences</i>. </ul> <br>";
$allthings = json_decode($data);

if (json_last_error() != JSON_ERROR_NONE)
				echo  "+++ JSON Error - verify <i>$filein</i>";
echo "<hr><b>REAL</b> things<br>";
foreach ($allthings->real as $thing) {
    appendThing("real", $thing);
    appendExtra($thing);
}

echo "<hr><b>VIRTUAL</b> things<br>";
foreach ($allthings->virtual as $thing) {
    appendThing("virtual", $thing);
    appendExtra($thing);
}

echo "<hr><b>FAKE</b> things<br>";
foreach ($allthings->fake as $thing) {
    appendThing("fake", $thing);
    appendExtra($thing);
}
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr>'; // end page menu
echo "<b>" . $_POST["adfile"] . "</b> input file (for reference): <br>";
echo "<pre>";
echo json_encode($allthings, JSON_PRETTY_PRINT);
echo "</pre>";
// -------------------------------------------------- END PAGE (end stuff required by crudClass4)
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br><br>'; // end page menu
echo "</body></html>";

?>
