<?php
// tuyaDAEMON things project
// An application for the management of Tuya and custom things used in one or more tuyaDAEMON servers.
// Definitions:
//     -device: an IOT class of tuya or custom gadgets, defined via DPs and capabilities (see tuiadaemontoolkit)
//     - thing: a single device instance, with ID, KEY, quirks and functions.
// Used data resources, all in BASEPATH dir:
//   a) the 'device_xxxxx.json' files with device definitions, from tuyadaemontoolkit.
//   b) the 'alldevices.server.json' file, from node-red tuyaDAEMON servers
//   c) the 'tuyawizard.txt' file, from tuya-cli wizard console output.
// Data base: 'tuyathome', tables:
//         'allthings'    : defines a thing: name, type, device etc...
//         'specialthing' : defines single thing's quirks as delta from standard device capabilities.
//         'sharewthing'  : defines single thing's actions using 'share' tuyaDAEMON feature.
// Goals:
//     - popolate and update the 'tuyathome' DB from resources in a simple and iterable way.
//     - Thing's definition and management with easy CRUD forms.
//     - export of 'alldevices.server.json' for one or more tuyaDAEMON servers.
//     - documentation production.
// ===================================================
// default constat: you CAN CHANGE it:
// example iMac
$BASEPATH   = '/Applications/MAMP/htdocs/tuyadaemontoolkit/devicedata';                     // default for 'devicexxx.json' (tuyadaemontoolkit) and 'addevices.XXSERVER.json'
$WIZARDFILE = '/Applications/MAMP/htdocs/tuyadaemontoolkit/devicedata/tuyawizard.txt';      // default name for captured tuya-cli wizard console output. (MUST exist)
 // note: execute in console 'tuya-cli wizard', then capture all and paste it in the tuyawizard.txt file.

// =================================================== common functions (do NOT change)
// builds GatewayID list[thingID => tuyaID].  (MUST have 'Gateway' in thingName or TuyaName)
$gateways = sqlLookup("SELECT thingID, tuyaID FROM allthings WHERE deviceClass = 'real' AND ((thingName COLLATE UTF8_GENERAL_CI LIKE '%_ateway%') OR (tuyaName COLLATE UTF8_GENERAL_CI LIKE '%_ateway%'));");

// parse wizard data file
function forEachWizard($callback, $afile) {
  $data = file($afile);
  $one  = array();
// from Wizard:
// [0]:tuyaname/[1]:tuyaid/[2]:tuyakey/[3]:tuyacid/[4]:isGateway
 foreach ($data as $key =>$line) {
    $test  = trim($line);
    $parts = explode("'", $test);
// start allways by name, id:
    if (trim($parts[0]) == 'name:')
        $one[0] = $parts[1];
    if (trim($parts[0]) == 'id:')
        $one[1] = $parts[1];
// next or key (real) or cid (virtual)
    if (trim($parts[0]) == 'key:') {
        $one[2] = $parts[1];
	    	$one[3] = null;
        $one[4] = (strpos($data[$key+1],'subDevices') != false );
	      $callback($one);
       }
   if (trim($parts[0]) == 'cid:') {
 	    	$one[2] = null;
        $one[3] = $parts[1];
        $one[4] = false;
	      $callback($one);
       }
   }
}

function cleanName($usrstr)
{
	/*

Caratteri pericolosi per i nomi dei file su Windows:

< (meno)
> (maggiore)
: (due punti)
" (virgolette doppie)
/ (barra)
\ (barra rovesciata)
| (pipe)
? (punto interrogativo)
* (asterisco)

Caratteri pericolosi per i nomi dei file su macOS:
: (due punti)
/ (barra)

Caratteri pericolosi per i nomi dei file su Linux:
/ (barra)

Caratteri pericolosi per MQTT:
# (cancelletto)
+ (più)

Caratteri pericolosi per le query SQL in MySQL:
' (apostrofo singolo)
" (virgolette doppie)
\ (barra rovesciata)
; (punto e virgola)
-- (commento in linea)
/ * * / (commento multi-riga)

Caratteri pericolosi per gli URL:
< (meno)
> (maggiore)
" (virgolette doppie)
' (apostrofo singolo)
{ (parentesi graffa aperta)
} (parentesi graffa chiusa)
| (pipe)
\ (barra rovesciata)
^ (cappuccio)
~ (tilde)
[ (parentesi quadra aperta)] (parentesi quadra chiusa)
` (accento grave)
`` (backtick)
% (percentuale)
& (ampersand)
$ (simbolo del dollaro)
+ (più)
, (virgola)
/ (barra)
: (due punti)
; (punto e virgola)
= (uguale)
? (punto interrogativo)
@ (chiocciola)
# (cancelletto)
[spazio]
*/
  // Definisci l'array di caratteri pericolosi e il carattere di sostituzione
    $dangerousChars = array('/', '\\', '?', '%', '*', ':',';','@','|', '"','\'', '<', '>', ',', '+', '#','`' );
    $replacementChar = '_';

    // Sostituisci i caratteri pericolosi con il carattere di sostituzione
   return strtr($usrstr, array_combine($dangerousChars, array_fill(0, count($dangerousChars), $replacementChar)));


}

function cleanUpValue($usrstr)
{
    // safe for sql injection
    return str_replace(array(
//        "\\",
//        "\"",
        "'",
        "<",
        ">"
    ) , array(
 //       "\\\\",
 //       "&#34;",
        "&#39;",
        "&#60;",
        ">"
    ) , $usrstr);
}
function restoreValue($usrstr)
{
    return str_replace(array(
  //      "\\\\",
 //       "&#34;",
        "&#39;",
        "&#60;",
        ">"
    ) , array(
 //       "\\",
 //       "\"",
        "'",
        "<",
        ">"
    ) , $usrstr);
}


?>
