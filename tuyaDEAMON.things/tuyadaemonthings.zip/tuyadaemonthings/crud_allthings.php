<?php
//
$r = dirname(__FILE__);
require_once("$r/lib/crudClass4.php");
require_once("$r/lib/commonSQL.php"); // library + DB acess def
if (isset($_GET['path']) || isset($_GET['thingID'])) { // CHANGE:  here the PK
    $_POST = $_GET; // POST/GET compatible
}
/*
echo '<pre>';
echo print_r($_POST);
echo '<pre>';
*/
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo '<title>TuyaDEAMON Things</title>';
echo StyleSheet();

if (file_exists("$r/setupdata.tmp.php")) {
    require_once("$r/setupdata.tmp.php"); // data from setup
} else {
    echo "<div class=error>Can't find the file <i> $r/setupdata.tmp.php. </i><br>";
    echo " Please do the <b>Setup config file</b> step before.</div>";
    exit;
}
// --------------- some exta actions:



// check in 'edit' case (eg. DB modified):
if (isset($_POST['edit'])) {
    $thingCheck = sqlValue("SELECT thingID FROM  allthings WHERE thingID = '" . $_POST['thingID'] . "' ;");
    if ($thingCheck != $_POST['thingID']) {
        echo "<div class=error>Bad thingID<i> " . $_POST['thingID'] . ". </i><br>";
        echo " Please verify.</div>";
        exit;
    }
}

echo "</head><body>";
//
echo "<h1> table <b>allthings</b>: <i>add/edit/delete records</i></h1>"; // CHANGE:  page Title


if (isset($_POST['edit'])) {
    $thingName = sqlValue("SELECT thingName FROM  allthings WHERE thingID = '" . $_POST['thingID'] . "' ;");

    echo "<div class='note' align='left'>
EDIT the existing <b>$thingName</b> record.<br><br>
<li><b>tuyaXXX</b> fields: updated from wizard output (keys: <i>tuyaName, tuyaID, tuyaCID</i>).
<li><b>server</b>: or <i>Group</i>, to select things, user defined in <code>lookupserver</code> table, plus 'COMMON', 'NEW'.
<li><b>comment</b>: this is added to 'alldevices' json output.
<li><b>location</b>: local information like SmartLife 'room'.
<li><b>notes</b>: local informations.
<li><i> IDs, names, dPs, etc., starting with 'underscore' [_] cannot be changed: can be used as a stable reference.
</div>";
} else {
    echo "<div class='note' align='left'>
NEW record to define a new <b>Thing</b>.<br><br>
<li><b>tuyaXXX</b> fields: updated from wizard output (keys: <i>tuyaName, tuyaID, tuyaCID</i>).
<li><b>server</b>: or <i>Group</i>, to select things.
<li><b>comment</b>: this is added to 'alldevices' json output.
<li><b>location</b>: local information like SmartLife 'room'.
<li><b>notes</b>: local informations.
<li><i> IDs, names, dPs, etc., starting with 'underscore' [_] cannot be changed: can be used as a stable reference.
</div>"; //  CHANGE: intro boz
}

//--------------------------------------------------  CALLBACKS (if required)
// callbacks use examples: see crud_base
function make_select_extra($field, $sql, $selected = NULL) {
    $code = "$field: <select name='$field'>";
    $code .= "<option value='' " . ($selected == NULL ? ' selected = "selected"' : '') . " ></option>\n";
    $code .= "<option value='none' " . ($selected == 'none' ? ' selected = "selected"' : '') . " >none</option>\n";
    $code .= optionsList($sql, $selected);
    $code .= '</select><br>';
    return ($code);
}

// MASTER: add action SHOW DETAILS (thingID is the pk/fk), goto: crud_specialthings.php?thingID=xxxx
function crud_action_hook($record) {
    // add action button 'VIEW SPECIALS' 'VIEW SHARE' :
    $code = "<form action='crud_specialthing.php'  mode='POST'>";
    $code .= "<input type='hidden' name='thingID' value=" . $record['thingID'] . ">";
    $code .= "<input type='submit'  value='SPECIALS'></form>";
    $code .= "<form action='crud_sharething.php'  mode='POST'>";
    $code .= "<input type='hidden' name='thingID' value=" . $record['thingID'] . ">";
    $code .= "<input type='submit'  value='SHARE'></form><b>" . $record['thingName'] . "</b>";
    return $code;
}
function crud_get_input($field) {
    // same as edit
    return crud_get_edit($field, NULL);
}

function crud_get_edit($field, $value) {
    global $tuyanamesTmp;
    $code = "$field: <input type='text' name='$field' value='$value' /><br>"; // general case txt
    // custom special cases

    if ($field === 'deviceClass') {
        // radio,
        $code = crudClass::make_radio($field, "real,virtual,fake", $value); //  list
    }
    if ($field === 'deviceName') {
        // gets values from lookup table
        //       $code = make_select_extra($field, "(SELECT 'NULL') UNION ALL (SELECT dName     FROM deviceinfos ORDER BY dName)", $value);   //        list
        $code = make_select_extra($field, "SELECT dName     FROM deviceinfos ORDER BY dName", $value); //        list
    }
    if ($field === 'tuyaName') {
        $code = crudClass::make_select4list($field, "none," . $tuyanamesTmp, $value); //        list
    }
    if ($field === 'tuyaID') {
        $Xclass = (isset($_POST['thingID'])) ? sqlValue("SELECT deviceClass FROM  allthings WHERE thingID =" . $_POST['thingID'] . " ;") : 'none';
        if ($Xclass != 'fake')
            $code = "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;'  /><br>";
    }
    if ($field === 'tuyaCID') {
        $code = "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;'  /><br>";
    }
    if ($field === 'tuyaGateway') {
        $code = "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";
    }
    if ($field === 'tuyaKEY') {
        $code = "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";
    }
    if ($field === 'server') {
        $code = crudClass::make_select($field, "SELECT groups FROM lookupserver  WHERE id > 10 ORDER BY id", $value);
    }
    return $code;
}

function crud_get_show($field, $value) {
    global $BASEPATH;
    $code = $value; // general case
    if (($field === 'deviceName') && (isset($value)) && file_exists($BASEPATH . DIRECTORY_SEPARATOR . "device_" . $value . ".pdf")) {
        $code = " $value <a href='http://localhost/tuyadaemontoolkit/devicedata/device_" . $value . ".pdf' target='_blank'>view</a>";
        $code .= " | <a href='http://localhost/tuyadaemontoolkit/crud_deviceinfos.php?dName=" . $value . "&edit=EDIT' target='_blank'>edit</a>";
    }

    return $code;
}

function before_create($fields) {
    // to force some rules, note: $fields is an array of values like:  "[2] => 'none'". Note: (') are in the string

    $_POST['thingName'] = cleanName($_POST['thingName']);
/*
    echo '<pre>';
    echo print_r($fields);
    echo '<pre>';
*/
    if (!empty($_POST['tuyaGateway']) || !empty($_POST['tuyaCID'])) {
        $fields[0] = 'virtual';
    }
    // NULL cases
    if (isset($_POST['deviceName']) && ($_POST['deviceName'] == 'none'))
        $fields[2] = 'NULL';
    if (isset($_POST['tuyaName']) && ($_POST['tuyaName'] == 'none'))
        $fields[3] = 'NULL';

//   field escaped:
 	  $fields[1] = empty($_POST['thingName'])? "NULL":("'".cleanName($_POST['thingName'])."'");
   	  $fields[9] = empty($_POST['location'])? " NULL":("'".cleanUpValue($_POST['location'])."'");
   	  $fields[10] = empty($_POST['comment'])? " NULL":("'".cleanUpValue($_POST['comment'])."'");
   	  $fields[11] = empty($_POST['notes'])? " NULL":("'".cleanUpValue($_POST['notes'])."'");

    /*
    echo '<pre>';
    echo print_r($fields);
    echo '<pre>';
    */
    return $fields;
}
function before_update($fields) {
    // to force some rules, note: $fields is an array of strings like:  "`deviceClass` = 'virtual'" (sql fragments).
/*
    echo '<pre>';
    echo print_r($fields);
    echo '<pre>';
    */
    $_POST['thingName'] = cleanName($_POST['thingName']);
    if (!empty($_POST['tuyaGateway']) || !empty($_POST['tuyaCID'])) {
        $fields[0] = "`deviceClass` = 'virtual'";
    }
    // NULL cases
    if (isset($_POST['deviceName']) && ($_POST['deviceName'] == 'none'))
        $fields[2] = "`deviceName` = NULL";
    ;
    if (isset($_POST['tuyaName']) && ($_POST['tuyaName'] == 'none'))
        $fields[3] = "`tuyaName` = NULL";
	// cascade update thingName if modified
	$oldName = sqlvalue("SELECT thingName FROM allthings WHERE thingID = ".$_POST['thingID']." LIMIT 1 ");
    if (isset($_POST['thingName']) && ($_POST['thingName'] != $oldName)) {
		sql("UPDATE specialthing SET thingName = '".$_POST['thingName']."'  WHERE thingID = ".$_POST['thingID'] );
		sql("UPDATE sharething SET thingName = '".$_POST['thingName']."'  WHERE thingID = ".$_POST['thingID'] );
	}
 //   field escaped:
   	  $fields[1] = "`thingName` = ".(empty($_POST['thingName'])? " NULL":("'".cleanName($_POST['thingName'])."'"));
   	  $fields[9] = "`location`= ".(empty($_POST['location'])? " NULL":("'".cleanUpValue($_POST['location'])."'"));
   	  $fields[10] = "`comment`= ".(empty($_POST['comment'])? " NULL":("'".cleanUpValue($_POST['comment'])."'"));
   	  $fields[11] = "`notes`  = ".(empty($_POST['notes'])? " NULL":("'".cleanUpValue($_POST['notes'])."'"));


  /*
    echo '<pre>';
    echo print_r($fields);
    echo '<pre>';
    */
    return $fields;
}


// -------------------------------------------------- END CALLBACKS

$crud = new crudClass('allthings', 'deviceClass,thingName,deviceName,tuyaName,tuyaID,tuyaCID,tuyaGateway,tuyaKEY,server,location,comment,notes', 'thingID'); //  with table information: name, fields, pk

// ================= don't change
if (isset($_POST['submit'])) {
    $create_sql = $crud->create(); //Fetch INSERT query
    sql($create_sql);
}
if (isset($_POST['update'])) {
    $update_sql = $crud->update(); //Fetch UPDATE query
    sql($update_sql);
}
if (isset($_POST['delete'])) {
    $delete_sql = $crud->delete(); //Fetch DELETE query
    sql($delete_sql);
}
// ================= new operations
if (isset($_POST['destroy'])) {
	sql("DELETE FROM specialthing WHERE thingID = ".$_POST['thingID'].";");    // delete extra
	sql("DELETE FROM sharething WHERE thingID = ".$_POST['thingID'].";");    // delete share
	sql("DELETE FROM allthings WHERE thingID = ".$_POST['thingID'].";");    // delete thing
}

if (isset($_POST['clone'])) {
	sql("INSERT INTO allthings( deviceClass,thingName,deviceName, tuyaGateway,server,location,comment,notes)
	SELECT deviceClass,CONCAT(thingName,'_new') AS 'thingName' ,deviceName, tuyaGateway,server,location,comment,notes FROM allthings WHERE thingID = ".$_POST['thingID'] );    // copy thing

	$cloneID = sqlvalue("SELECT last_insert_id() FROM allthings");
    sql("INSERT INTO specialthing (thingID,thingName,DPkey,DPattribute,newValue)
	SELECT  $cloneID AS 'thingID', CONCAT(thingName,'_new') AS 'thingName', DPkey,DPattribute,newValue FROM specialthing WHERE thingID = ".$_POST['thingID'] );    // copy special

    $smax =  sqlValue("SELECT IFNULL(MAX(CAST(SUBSTRING(shareName, 7) AS UNSIGNED)),0) FROM `sharething` ");
    $sstart = sqlValue("SELECT IFNULL(MIN(CAST(SUBSTRING(shareName, 7) AS UNSIGNED)),0) FROM `sharething` WHERE thingID = ".$_POST['thingID'] );
	$delta = $smax - $sstart + 1;
    sql("INSERT INTO sharething (thingID,thingName,DPkey,shareName,type,count,eval_test,remote,device,property,str_value)
	SELECT  $cloneID AS 'thingID', CONCAT(thingName,'_new') AS 'thingName', DPkey,CONCAT('share_',(CAST(SUBSTRING(shareName, 7) AS UNSIGNED) + $delta)) AS 'shareName', type,count,eval_test,remote,device,property,str_value FROM sharething WHERE thingID = ".$_POST['thingID'] );    // copy share

}



// ------------- builds HTML page
if (isset($_POST['edit'])) {
    // edit
    echo "<div class='note' align='right'>";
    echo $crud->renderEditor(); //Prepare data edit form
    echo  "<form action='crud_allthings.php'  mode='POST'>";
    echo  "<input type='hidden' name='thingID' value=" . $_POST['thingID'] . ">";
    echo  "<input type='submit' name='destroy' value='DESTROY' onclick='return confirm(\'Recursive delete of  $thingName!\nAre you sure?\');' >";
    echo  "<input type='submit' name='clone' value='CLONE' onclick='return confirm(\'Duplicate of  $thingName!\nAre you sure?\');'></form>";
    echo '</div>';


} else {
    // or insert
    echo "<div class='note' align='right'>";
    echo $crud->create_form(); //Prepare data entry form
    echo '</div>';
}
// table
//  =============== don't change ends
echo $crud->renderVertically('ORDER BY `deviceClass`, `thingName`'); // CHANGE: for WHERE or ORDER or LIMIT
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><br>'; //                    CHANGE: end page menu
echo "</body></html>";

?>
