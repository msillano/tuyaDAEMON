<?php
 // -------- user updated constans:
$BASEPATH = '/Applications/MAMP/htdocs/tuyadaemontoolkit/devicedata';
$WIZARDFILE= '/Applications/MAMP/htdocs/tuyadaemontoolkit/devicedata/tuyawizard.txt';
 // -------- actual values:
$tuyanamesTmp = '1CH,3 Gang ZigBee Remote,Bluetooth ZigBee hub,Breaker ,Clima Ariston,corridoio,DBT box,Dimmer Switch,esterna,External Temperature Humidity,finestraletto,finestraospiti,giardino anteriore,giardino laterale,HC010-2 ok,HC010-2 test,hot water,IR hub,Letto,LightSensor,Luce esterna ,Main AC,meter,meterB - frigo,meterC dishwasher,MK6,Ospiti,PC stand,piante grasse ,plugZ kitchen,portafinestra,Portone,Schermo pc,Sensore di movimento,Sensore porta,Sirena,Smart Breaker,smart camera,Smart Inverter Plug-and-Play,Smart IR 1,Smart IR 2,Smart IR 3,Smoke Detector,socketA,socketD,socketE,Soggiorno,Sonytv,switch module #1,Televisione,Temperatura letto,Temperatura soggiorno,Temperatura studio,Temperature and humidity alarm,Termo letto,Termo soggiorno,Termo studio,terreno,tuya_bridge,umidificatore,Water leak sensor,Water leak sensor 2,Water leak sensor 3,Watering main,Watering remote 3 gang,Watering timer,Wifi Plug,Zigbee Gateway'; 
?>