<?php

$r=dirname(__FILE__);
require_once ("$r/lib/commonSQL.php");
require_once("$r/commonTuya.php");

// set some data strucures required by all tasks in 'setupdata.tmp.php' dynamic file.

if (isset($_GET['apath'])) {
    $_POST = $_GET; // POST/GET compatible
}

//---------- set page+
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo '<title>TuyaDEAMON Things</title>';
echo StyleSheet();
echo '</head><body>';

echo "<hr><h3>Input parameters:</h3> \n";
echo "<pre>";
echo print_r($_POST);
echo "</pre>";

//  ------- setting user path
if (! empty($_POST['apath'])){
    $test = glob($_POST['apath'].DIRECTORY_SEPARATOR.'alldevice*.json');
    if (count($test)){
          $BASEPATH = $_POST['apath'];
          echo "<hr><b>BASEPATH updated to <i>$BASEPATH</i></b> <br>";
    } else {
	  echo "<div class=error>PATH ERROR: can't found files like <i>".$_POST['apath']."/alldevice*.json </i><br>".PHP_EOL;
          echo" Enter the work path with required <i>alldevice.json</i>, <i>wizard.txt</i> and <i>device_xxxx.json</i> files.</div>";
          exit;
    }
}
//  ------- setting wizard file
if (! empty($_POST['afile'])){
    if ( is_file($BASEPATH. DIRECTORY_SEPARATOR.$_POST['afile']))
    {
          $WIZARDFILE= $BASEPATH. DIRECTORY_SEPARATOR .$_POST['afile'];
          echo "<hr><b>WIZARDFILE updated to <i>$WIZARDFILE</i></b> <br>";
    } else {
	  echo "<div class=error>WIZARD file ERROR: can't found the file <i>".$BASEPATH. DIRECTORY_SEPARATOR.$_POST['afile']."</i><br>".PHP_EOL;
          echo" Enter the correct name of the <i>wizard</i> file.</div>";
          exit;
    }
}



// is_file()

// ===============  local functions
//  ------------------ generates a list of 'alldevice_xxxxx.json' fies
 function getAlldevice(){
   global $BASEPATH;
// get the array of file names
   $all = array_map( function( $item ) {
    return basename( $item );
    }, glob($BASEPATH. DIRECTORY_SEPARATOR.'alldevice*.json'));

echo "<pre>";
echo print_r($all);
echo "</pre>";
}

//   ---------------- generates a list of server names from lookupserver table
function getAllServers(){
  $temp = sqlArray("SELECT DISTINCT groups FROM lookupserver WHERE (groups != '') AND (groups != 'ALL') AND (groups != 'NEW') AND (groups != 'COMMON');");
return ($temp);
}

//  ------------------ generates a list of device names in $WIZARDFILE
$listTuyaNames = array();
$toList  = function($a) {
          global $listTuyaNames;
          $listTuyaNames[] = $a[0];
          };

$my_sort = function($a,$b){
	if (strtoupper($a)==strtoupper($b)) return 0;
	return (strtoupper($a)<strtoupper($b))?-1:1;
	};

// note: forEachWizard() is defined in commonTuya.php
function wizardNames(){
   global $WIZARDFILE, $toList,$listTuyaNames, $my_sort;
   forEachWizard($toList, $WIZARDFILE);
   usort($listTuyaNames, $my_sort);
   }

// --------------- start tests
echo "<hr><h3><i>alldevice.xxx.json</i> file list:</h3> \n";

getAlldevice();

// -------------  print data
$prove =  getAllServers();
echo "<hr><h3>Server list:</h3> \n";
echo "<pre>";
echo print_r($prove);
echo "</pre>";
//
wizardNames();
echo "<hr><h3>Tuya thing's names from WIZARD file:</h3> \n";
echo "<pre>";
echo print_r($listTuyaNames);
echo "</pre>";

// ------------- save setup
$filesetup = "$r".DIRECTORY_SEPARATOR."setupdata.tmp.php";
$content =  "<?php".PHP_EOL;
$content .= ' // -------- user updated constans:'.PHP_EOL;
$content .= '$BASEPATH = '."'$BASEPATH';".PHP_EOL;
$content .= '$WIZARDFILE= '."'$WIZARDFILE';".PHP_EOL;
$content .= ' // -------- actual values:'.PHP_EOL;
$content .= '$tuyanamesTmp = '."'".implode(',', $listTuyaNames)."'; ".PHP_EOL;
$content .= '?>' ;
file_put_contents($filesetup, $content);
echo "<hr><b>Updated setup file <i>$filesetup</i> with actual data.</b> \n";

//  cleanup db
if(isset($_POST['key2'])) {
sql("DELETE FROM `tuyathome`.`sharething`");
sql("DELETE FROM `tuyathome`.`specialthing`");
sql("ALTER TABLE `tuyathome`.`specialthing` AUTO_INCREMENT = 1");
sql("DELETE FROM `tuyathome`.`allthings`");
sql("ALTER TABLE `tuyathome`.`allthings` AUTO_INCREMENT = 1");
echo "<hr><b>Truncated DB tables:`allthings`,`specialthing`,`sharething`. </b> \n";
}

// -------------- end
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br>'; //   end page menu
echo '</body></html>';

?>
