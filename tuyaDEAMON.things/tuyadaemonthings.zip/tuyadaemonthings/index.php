<?php
// for // DEBUG:
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$r=dirname(__FILE__);
require_once ("$r/lib/commonSQL.php");
include("$r/odtReportSQL.php");
include("$r/commonTuya.php");



// for custom menu, same look as getReportMenu  (in odtReportSQL.php)
function putUI($title, $description, $body, $href) {
$hcode = '<table border="1" cellpadding="0" cellspacing="0" id="dvContainer" >	<tr> <td>';
$hcode .= '<div style="font-family:verdana,arial,tahoma;	font-size:22px;	color:#316B40;	background-color:#E9E5D9; padding-left: 8px; width:500">'.$title.'</div>';
$hcode .= '</td></tr><tr><td>			<div style="font-family:verdana,arial,tahoma;font-size:12px;color:black;background-color:#F7F7EF;	padding-left: 3px;">';
$hcode .= $description.'</div></td></tr><tr>	<td style="background-color:#F7F7EF">';
$hcode .= '<form  border="1" name="report" style=" margin-bottom: 8pt;   margin-top: 8pt;" action="'.$href.'" method="put">';
$hcode .=  '<table id="dvForm" cellspacing="1" cellpadding="0" style="width: 340pt;background-color:#F7F7EF;">	<tr><td colspan=2></td>';
$hcode .=  '<td rowspan="3" style="width:60pt; vertical-align:middle;"><div>
						<button type="submit" style="background-color:#529214;border:1px solid #529214;color:#ffffff;" id="update" ><img src="update.gif" />   Go  </button>';
/*
<!--
$hcode .= <button type="submit" class="positive" id="update" name="update_x" value="1" onclick="return confirm('Questa operazione può cancellare tutto il DataBase!\nEffettuare prima un backup dei dati!') && validateData();"><img src="update.gif" /> Esegui</button>
-->
*/
$hcode .=  '</div></td></tr>'.$body;
/*
<!--fieldBlock
 $hcode .=
     <tr><td  style="vertical-align:middle;"><div  style="text-align:right;">#fieldName#</div>
    		</td>
			<td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">#fieldInput#</td>
		</tr>

fieldBlock-->
*/
$hcode .=  '</table> </form>	</td> </tr> </table>';
return ($hcode);
}

//  now HTML
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo  '<link rel="stylesheet" type="text/css" href="./css/style2.css">';
echo '<title>TuyaDEAMON Things</title>';

/*
echo  '<script>';
echo  'document.getElementById("myfile").onchange = function() {';
echo  'document.getElementById("infile").value = this.files[0].name;};';
echo  '</script>';
*/
echo "</head><body>";
echo "<h1> tuyaDAEMON things tool</h1>";


echo "<div class='note' align='center'><b>two ways tool for the <i>alldevices</i> structure management</b>";
echo  "<div align='left'><BR>You can, starting from empty <i>allthings, specialthing, sharething</i> DB tables:<ul> \n";
echo "<li>Import all your things informations from an <i>alldevice</i> file to DB: you get in <i>allthings</i> the list of things.</li>";
echo "<li>Use the DB master form (<i>allthings</i> table) to :";
echo    "<ul><li>  associate <i>things &lt;=&gt; devices</i> (defined using <a href='./../tuyadaemontoolkit' target='_blank' >TuyaDaemon Toolkit</a>).";
echo    "<li>  associate <i>things to TuyaDAEMON instances </i> (defined in <i> tuyahome.lookupserver </i> DB table).";
echo    "<li>  edit thing's comments</ul></li>";
echo    "<li>Customize thing's behavior using the DB detail forms (<i>specialthing</i> and <i>sharething</i> tables) to :";
echo    "<ul><li> add extra  dPs (attributes) to a thing.";
echo    "<li> define methods as 'share'</ul></li>";

echo "<li>Refresh all <i>Tuya devices IDx and KEYs</i> from the <code>wizard</code> output file.</li>";

echo "<li>Generate a JSON fragment for only  <i> one thing</i>, to update a <i>global.alldevices</i> json structure.</li>";
echo "<li>Export all information about a <i>things group</i>: this step builds the full <i>global.alldevice</i>.";
echo "</ul>Default Work dir: <code>$BASEPATH</code></div></div>";
// menu 0 init
   $body =  '<tr><td  style="vertical-align:middle;"><div  style="text-align:right;">Work dir: <BR> Wizard:<br>&nbsp;<br></div>	</td><td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">';
   $body .= '<input type="text" id="apath" name="apath"  placeholder='.$BASEPATH.'  size="36" ><BR>';
   $body .= '<input type="file" id="wizfile" name="wizfile"   style="display: none;" onchange = "document.getElementById(\'afile\').value = this.files[0].name;" />';
   $body .= ' <input type="button" value="browse..." onclick="document.getElementById(\'wizfile\').click();" />';
   $body .= '<input type="text" id="afile" name="afile"  placeholder="tuyawizard.txt"><BR>Clear DB <input type="checkbox" id="key2" name="key2" value="clear"></td></tr>';

   echo "<div align='center'>".putUI("Setup config file","Do it before doing any task. Or to clear the DB.",$body,'startsetup.php')."</div><BR>";

//  ------------------ generates a list of 'alldevice_xxxxx.json' fies
 function getAlldevice(){
   global $BASEPATH;
// get the array of file names
   $all = array_map( function( $item ) {
    return basename( $item );
    }, glob($BASEPATH.'/alldevice*.json'));
  return( $all);
}

function getSelect($data){
$Dfiles =  getAlldevice();
$select= '<select name="adfile" id="adfile">';
foreach ($Dfiles as $value) {
   $select .= "<option value='$value'>$value</option>";
}
$select .= '</select>';
return ($select);
}
// ----------------------------------------
// menu 1 import
   $body = '<tr><td  style="vertical-align:middle;"><div  style="text-align:right;">input:</div><br>&nbsp;<br></td><td st $DIRECTORY_SEPARATORyle="vertical-align:middle;padding-left: 5px;">';
   $body .= getSelect(getAlldevice());
   $body .= '<br><br>To Group: <select name="key2">'.optionsList("SELECT groups FROM lookupserver ORDER BY id").'</select><BR>';
   $body .= '</td></tr>';
   echo "<div align='center'>".putUI("IMPORT from <i>alldevice</i> file","Updates table  <i>allthings</i>, <i>specialthing</i> and <i>sharething</i>",$body,'inputdbase.php')."</div><BR> ";

// menu 2 db custom
   $body ='<tr><td  colspan=2 style="vertical-align:middle;padding-left: 5px;"> Main/detail pages: define before the <b>master</b>, after the <b>details</b></td></tr><input type="hidden" id="path" name="path"  value="'.$BASEPATH.'" >';
   echo "<div align='center'>".putUI("Things <i>DataBase</i> access","Edit master <i>allthings</i> and detail tables <i>specialthing</i>, <i>sharething</i>",$body, 'crud_allthings.php')."</div><BR>";

// menu 3 import key
   $body = '<tr><td  style="vertical-align:middle;">&nbsp;</td><td style="vertical-align:middle;padding-left: 5px;">Precess NEW devices:<input type="checkbox" id="key2" name="key2" value="donew"><input type="hidden" id="index" name="index"  value="1" ><BR></td></tr>';
   echo "<div align='center'>".putUI("IMPORT from <i>wizard</i> file","Updates tuya IDs and KEYs on table <i>allthings</i></i>",$body,'tuyakeydbase.php')."</div><BR>";

// menu 4 export one
   $body = '<tr><td  style="vertical-align:middle;"><div  style="text-align:right;">Choose a <b>thing</b> </div></td><td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">';
   $body .= '<select name="key1">'.optionsList("SELECT thingID, IFNULL(thingName,tuyaName)  FROM allthings ORDER BY thingName").'</select><BR><input type="hidden" id="path" name="path"  value="'.$BASEPATH.'" ></td></tr>';
   echo "<div align='center'>".putUI("single <i>thing</i> JSON creation","Copy/paste the output into <code>global.alldevices</code>",$body,'dump_one.php')."</div><br>";
   // menu 4 export all

     // menu 5 export all
$body = '<tr><td  style="vertical-align:middle;"><div  style="text-align:right;">Choose the active group</div></td><td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">';
$body = '<tr><td  style="vertical-align:middle;"><div  style="text-align:right;">Choose max 3 <b>groups </b> </div></td><td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">';
$body .= '<select name="key1" value="none">'.optionsList("SELECT groups FROM lookupserver ORDER BY id").'</select><BR>';
$body .= '<select name="key2">'.optionsList("SELECT groups FROM lookupserver ORDER BY id").'</select><BR>';
$body .= '<select name="key3">'.optionsList("SELECT groups FROM lookupserver ORDER BY id").'</select><BR><input type="hidden" id="path" name="path"  value="'.$BASEPATH.'" ></td></tr>';
 echo "<div align='center'>".putUI("EXPORT full <i>alldevices</i> file","Copy/paste the output into <code>global.alldevices</code>",$body,'dump_all.php')."</div><br>";

?>
