<?php
// detail page for sharething table, very customized for many controls and fields auto-updating
$r = dirname(__FILE__);
include("$r/lib/crudClass4.php");
require_once("$r/lib/commonSQL.php"); // library + DB acess def
if (isset($_GET['thingID'])) // CHANGE:  here the PK
 {
  $_POST = $_GET; // POST/GET compatible
 }

echo '<pre>';
echo print_r($_POST);
echo '<pre>';

echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo '<title>TuyaDEAMON Things</title>';
echo StyleSheet();
echo "</head><body>";
//
 $thingName = sqlValue("SELECT thingName FROM  allthings WHERE thingID = '" . $_POST['thingID'] . "' ;");
echo "<h1>  $thingName 'shares': <i>add/edit/delete records</i></h1>"; // CHANGE:  page Title
echo "<div class='note' align='left'>
<b>shareName:</b><br>
<li>The proposed value is for a new share, you must set also the new <code>DPkey</code>.
<li>Edit <code>shareName</code> to add one record to an existing share: <code>DPkey</code> is auto.<br>
<b>eval_test:</b><br>
<li> eval() JS expression with <code>msg.info{}, tuyastatus{}, ...</code><br>
<b>device, property, str_value</b>:
    <li> 'undefined' => set at runtime by inheritance.
    <li> 'NULL' =>  missed (to do GET, SCHEMA).
    <li> @onestrig => <code>eval(onestring)</code>, recursive in objects (json for value).
	<li> In the DB fields the char (&quot;) is escaped, while (') and (&lt;) are replaced by &amp;#39; and &amp;#60;.</div>"; //  CHANGE: intro box

$scount =  sqlValue("SELECT IFNULL(MAX(CAST(SUBSTRING(shareName, 7) AS UNSIGNED)),0) FROM `sharething` ");

//--------------------------------------------------  CALLBACKS

// callback for input fields (new)
function crud_get_input($field) {
	global $scount;
    $code = "$field: <input type='text' name='$field' value=NULL /><br>"; // general case

    if ($field === 'thingID')
   {
    if (isset($_POST['thingID']))     {
      $code = "$field: <input type='text' name='$field' value='" . $_POST['thingID'] . "' readonly style='background-color: lightgray;' /><br>";
     }
   }
  if ($field === 'thingName')   {
    if (isset($_POST['thingID']))  {
      $Xname = sqlValue("SELECT thingName FROM  allthings WHERE thingID =" . $_POST['thingID'] . " ;");
      $code  = "$field: <input type='text' name='$field' value='$Xname' readonly style='background-color: lightgray;' /><br>";
     }
   }
    if ($field === 'shareName')   {
	 $sharenew = 'share-'.(++$scount);
     $code = ("$field: <input type='text' name='$field' value='$sharenew'  /><br>");
   }
   if ($field === 'type')   {
     $code  = crudClass::make_select4list($field, "test,action");
  }

  if ($field === 'count')   {
    $code = ("$field: <input type='text' name='$field' value='auto' readonly style='background-color: lightgray;' /><br>");
   }
  if ($field === 'remote')   {
      $code  =  crudClass::make_select($field, "(SELECT  'undefined' as 'a', 'undefined' as 'b') UNION ALL (SELECT groups AS 'a', groups AS 'b' FROM lookupserver WHERE id > 20 ORDER BY id)");
  }

   return $code;
 }
//callback for input fields (edit)
function crud_get_edit($field, $value) {
  $code = "$field: <input type='text' name='$field' value='$value' /><br>"; // general case
  // custom special cases
  if ($field === 'thingID')
   $code  =  "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";
  if ($field === 'thingName')
   $code  =  "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";
 if ($field === 'DPkey')
   $code  =  "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";
 if ($field === 'shareName')
   $code  =  "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";
 if ($field === 'type')
   $code  =  "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";
 if ($field === 'count')
   $code  =  "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";

  if ($field === 'remote')   {
     $code  =  crudClass::make_select($field, "(SELECT  'undefined' as 'a', 'undefined' as 'b') UNION ALL (SELECT groups AS 'a', groups AS 'b' FROM lookupserver WHERE id > 20 ORDER BY id)");
  }

   return $code;
 }

function crud_action_hook($record) {
  global $BASEPATH;
  // add action button 'VIEW SPECIALS' 'VIEW SHARE' :
  $code = "<b>" . $record['shareName'] . "-" . $record['type'] . "-" . $record['count'] . "</b>";
  return $code;
 }
 function before_create($fields) {
    // to force some rules, note: $fields is an array of values like:  "` [2] => 'none'"

echo '<pre>';
echo print_r($fields);
echo '<pre>';

//	cleanUpValue($usrstr)
    echo '<pre> INPUT:';
    echo print_r($fields);
    echo '<pre>';
   // forces DPkey
    $Scount = sqlvalue("SELECT COUNT(*) FROM sharething WHERE shareName = '".$_POST['shareName']."';");
	if ( $Scount > 0){
	  $Xdp = sqlvalue("SELECT DPkey FROM sharething WHERE shareName = '".$_POST['shareName']."' LIMIT 1;");
	  $fields[2] = "'$Xdp'";
      }
   // update count
    $xcount = sqlvalue("SELECT IFNULL(MAX(count),0) FROM sharething WHERE shareName = '".$_POST['shareName']."' AND type = '".$_POST['type']."';");
	$fields[5] = ++$xcount;

	// Test fields
	  if ($_POST['type'] == 'test'){
	  $fields[7] = 'NULL';
	  $fields[8] = 'NULL';
	  $fields[9] = 'NULL';
	  $fields[10] = 'NULL';
	  } else {



	  $fields[6]  = 'NULL';
	  $fields[10] = cleanUpValue($_POST['str_value']);
 	  }


    echo '<pre> OUTPUT:';
    echo print_r($fields);
    echo '<pre>';

    return $fields;
}
function before_update($fields) {
    // to force some rules, note: $fields is an array of strings like:  "`deviceClass` = 'virtual'" (sql fragments).
    echo '<pre>';
    echo print_r($fields);
    echo '<pre>';
	    // Clenup some fields
		// Test fields
	 if ($_POST['type'] == 'test'){
	  $fields[7] =  "`remote` = NULL";
	  $fields[8] =  "`device` = NULL";
	  $fields[9] =  "`property` = NULL";
	  $fields[10] = "`str_value` = NULL";
	  } else {
	  $fields[6] =  "`eval_test` = NULL";
	  $fields[10] = "`str_value` ='".cleanUpValue($_POST['str_value'])."'";
 	  }

    /*
    echo '<pre>';
    echo print_r($fields);
    echo '<pre>';
    */
    return $fields;
}


// -------------------------------------------------- END CALLBACKS
$crud = new crudClass('sharething', 'thingID,thingName,DPkey,shareName,type,count,eval_test,remote,device,property,str_value', 'thingName,shareName,type,count,thingID'); // CHANGE: Initiate the class with table information: table-name, fields, pk
// ================= don't change
if (isset($_POST['submit'])) {
  $create_sql = $crud->create(); //Fetch INSERT query
  sql($create_sql);
  $scount =  sqlValue("SELECT IFNULL(MAX(CAST(SUBSTRING(shareName, 7) AS UNSIGNED)),0) FROM `sharething` ");
 }
if (isset($_POST['update'])) {
  $update_sql = $crud->update(); //Fetch UPDATE query
  sql($update_sql);
 }
if (isset($_POST['delete'])) {
  $delete_sql = $crud->delete(); //Fetch DELETE query
  sql($delete_sql);
  $scount =  sqlValue("SELECT IFNULL(MAX(CAST(SUBSTRING(shareName, 7) AS UNSIGNED)),0) FROM `sharething` ");
 }
// -------------
if (isset($_POST['edit'])){
  // edit
  echo "<div class='note' align='right'>";
  echo $crud->renderEditor(); //Prepare data new form
  echo '</div>';
 }
else {
  // or insert
  echo "<div class='note' align='right'>";
  echo $crud->create_form(); //Prepare data entry form
  echo '</div>';
 }


$scount =  sqlValue("SELECT IFNULL(MAX(CAST(SUBSTRING(shareName, 7) AS UNSIGNED)),0) FROM `sharething` ");

// table
//  =============== don't change ends
if (isset($_POST['thingID'])){       // if becomes from master page  CHANGE:
    echo $crud->renderVertically('WHERE thingID  = '.$_POST['thingID'].' ORDER BY DPkey ASC, `type` ASC, `count` ASC' );// DETAIL: limit records
    } else
    echo $crud->renderVertically(' ORDER BY DPkey ASC, `type` ASC, `count` ASC');   // else show all
//                    CHANGE: end page menu

echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="crud_allthings.php?path=dummy">Master</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><br>';
echo "</body></html>";
?>
