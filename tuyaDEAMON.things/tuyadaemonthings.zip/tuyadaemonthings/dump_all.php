<?php
$r = dirname(__FILE__);
require_once ("$r/lib/commonSQL.php");   // library + DB acess def
require_once ("$r/commonTuya.php");      // extra functions
// --------------- start tests
if (isset($_GET['key1']))
{
    $_POST = $_GET; // POST/GET compatible
}

/*
echo "<pre>";
echo print_r($_POST);
echo "</pre>";
*/

require_once ("$r/buildone.php"); // library

//==================  main
//  now HTML
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo  '<link rel="stylesheet" type="text/css" href="./css/style2.css">';
echo '<title>TuyaDEAMON Things</title>';

$alldevices = new stdClass();
$alldevices->comment = "by daemonThing  for: ".$_POST['key1'].", ".$_POST['key2'].",".$_POST['key3']." @".date('Y.m.d-H:i:s');
$alldevices->real = [];
$alldevices->virtual = [];
$alldevices->fake = [];
$mythings = sqlArrayTot("SELECT thingID, deviceClass, thingName, server FROM allthings ORDER BY thingName;");
foreach ($mythings as $onethings){
     echo "<hr>";
     if (($_POST['key1'] == 'ALL') || ($_POST['key2'] == 'ALL') ||($_POST['key3'] == 'ALL') ||
         ($onethings['server'] == $_POST['key1']) || ($onethings['server'] == $_POST['key2']) ||
		 ($onethings['server'] == $_POST['key3'])){
		  echo "... adding <b>".$onethings['deviceClass'].'.'.$onethings['thingName'].'</b> <br>';
      switch ($onethings['deviceClass']){
        case "real":
             array_push($alldevices->real,    doOneThing($onethings['thingID'], $_POST["path"]));
             break;
        case "virtual":
             array_push($alldevices->virtual, doOneThing($onethings['thingID'], $_POST["path"]));
             break;
        case "fake":
             array_push($alldevices->fake,    doOneThing($onethings['thingID'], $_POST["path"]));
             break;
      }
    } else
		  echo "... skipping ".$onethings['deviceClass'].'.'.$onethings['thingName'].'<br>';
    }
// done
$fileout = $_POST['path'] .DIRECTORY_SEPARATOR. "alldevices.new_".date('YmdHis').".json";
 // save as file
echo "<hr style=\"height:3px;border-width:0;color:gray;background-color:gray\">";
echo "<h3> Output alldevices </h3>";
echo "file: <i>$fileout</i><br><br>";
echo "<pre>";
echo restoreValue(json_encode($alldevices, JSON_PRETTY_PRINT));
echo "</pre>";
if (json_last_error() != JSON_ERROR_NONE)
		echo  "+++ JSON output encode Error - verify up.";

file_put_contents($fileout, restoreValue(json_encode($alldevices, JSON_PRETTY_PRINT)));


// ---------------------- END PAGE (end stuff required by crudClass4)
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br><br>'; // end page menu
echo "</body></html>";

?>
