<?php
//
$r=dirname(__FILE__);
include("$r/lib/crudClass4.php");
require_once ("$r/lib/commonSQL.php");  // library + DB acess def
if (isset($_GET['thingID'])){                                       // CHANGE:  here the FK
   $_POST = $_GET;   // POST/GET compatible
   }
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo '<title>TuyaDEAMON Things</title>';
echo StyleSheet();

if (file_exists("$r/setupdata.tmp.php")) {
    require_once("$r/setupdata.tmp.php"); // data from setup
} else {
    echo "<div class=error>Can't find the file <i> $r/setupdata.tmp.php. </i><br>";
    echo" Please do the <b>Setup config file</b> step before.</div>";
    exit;
}
echo "</head><body>";


echo "<pre>";
echo print_r($_POST);
echo "</pre>";


//

 $thingName = sqlValue("SELECT thingName FROM  allthings WHERE thingID = '" . $_POST['thingID'] . "' ;");

echo "<h1> $thingName <b>Specials</b>: <i>add/edit/delete records</i></h1>";// CHANGE:  page Title
echo "<div class='note' align='left'>
<li> <b>PDkey</b>[-1] => device, else PDs.
<li> <u>edit</u> opens the 'toolkit' to edit the device (after changes rebuild json and documentation!)
 </div>";                                                               //  CHANGE: intro box
//--------------------------------------------------  CALLBACKS

// callback for input fields (new)
 function crud_get_input($field){
   $code = "$field: <input type='text' name='$field' /><br>";
 if ($field === 'thingID'){
	  if(isset($_POST['thingID'])) {
        $code = "$field: <input type='text' name='$field' value='".$_POST['thingID']."' readonly style='background-color: lightgray;' /><br>";
	     }
    }
if ($field === 'thingName'){
  if(isset($_POST['thingID'])) {
	$Xname = sqlValue("SELECT thingName FROM  allthings WHERE thingID =".$_POST['thingID']." ;");
	$code = "$field: <input type='text' name='$field' value='$Xname' readonly style='background-color: lightgray;' /><br>";
  }
	}
 return $code;
}

//callback for input fields (edit)
function crud_get_edit($field, $value){
  $code = "$field: <input type='text' name='$field' value='$value' /><br>";  // general case
   // custom special cases

if ($field === 'thingID'){
	  if(isset($_POST['thingID'])) {
        $code = "$field: <input type='text' name='$field' value='".$_POST['thingID']."' readonly style='background-color: lightgray;' /><br>";
	     }
    }
if ($field === 'thingName'){
  if(isset($_POST['thingID'])) {
	$Xname = sqlValue("SELECT thingName FROM  allthings WHERE thingID =".$_POST['thingID']." ;");
	$code = "$field: <input type='text' name='$field' value='$Xname' readonly style='background-color: lightgray;' /><br>";
	}
}
if ($field === 'DPkey')
		$code = "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";
if ($field === 'DPattribute')
		$code = "$field: <input type='text' name='$field' value='$value' readonly style='background-color: lightgray;' /><br>";


 return $code;
}

function crud_get_show($field, $value){
	$code =  $value;  // general case

 if (($field === 'DPkey') && (isset($value)) && ($value != -1)) {
	 $Xname = sqlValue("SELECT deviceName FROM  allthings WHERE thingID =".$_POST['thingID']." ;");
	 $dpID  =  sqlValue("SELECT id FROM  devicedpoints WHERE dName ='$Xname' AND DPnumber ='$value';");
	 if (isset($dpID))
	  $code = " $value <a href='http://localhost/tuyadaemontoolkit/crud_devicedpoints.php?dName=$Xname&id=$dpID&edit=EDIT target='_blank'>edit</a>";
  //http://localhost/tuyadaemontoolkit/crud_devicedpoints.php?dName=BreakerDIN&id=340&edit=EDIT
	}
 if (($field === 'DPkey') && (isset($value)) && ($value == -1)) {
	 $Xname = sqlValue("SELECT deviceName FROM  allthings WHERE thingID =".$_POST['thingID']." ;");
  	 $code = " $value <a href='http://localhost/tuyadaemontoolkit/crud_deviceinfos.php?dName=$Xname&edit=EDIT target='_blank'>edit</a>";
	 //http://localhost/tuyadaemontoolkit/crud_deviceinfos.php?dName=dimmer01&edit=EDIT
}

	return $code;
}

// -------------------------------------------------- END CALLBACKS

$crud = new crudClass('specialthing','thingID,thingName,DPkey,DPattribute,newValue','thingID,DPkey,DPattribute' );// CHANGE: Initiate the class with table information: table-name, fields, pk (no spaces)

// ================= don't change
if (isset($_POST['submit'])){
    $create_sql = $crud->create();//Fetch INSERT query
    sql($create_sql);
}
if (isset($_POST['update'])){
    $update_sql = $crud->update();//Fetch UPDATE query
   sql($update_sql);
}
if (isset($_POST['delete'])){
    $delete_sql = $crud->delete();//Fetch DELETE query
    sql($delete_sql);
}
// -------------
if (isset($_POST['edit'])){
// edit
    echo "<div class='note' align='right'>";
    echo $crud->renderEditor();//Prepare data edit form
    echo '</div>' ;
    } else {
// or insert
    echo "<div class='note' align='right'>";
    echo $crud->create_form();//Prepare data entry form
    echo '</div>';
    }
 // table
 //  =============== don't change ends
 if (isset($_POST['thingID'])){       // if becomes from master page  CHANGE:
    echo $crud->renderVertically('WHERE thingID  = '.$_POST['thingID']);// DETAIL: limit records to id_invoice
    } else
    echo $crud->renderVertically('');   // else show all
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="crud_allthings.php?path=dummy">Master</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><br>'; //                    CHANGE: end page menu
echo "</body></html>";

?>
