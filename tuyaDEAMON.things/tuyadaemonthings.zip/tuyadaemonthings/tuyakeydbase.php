<?php
// for debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$r = dirname(__FILE__);
require_once("$r/lib/commonSQL.php"); // library + DB acess def
require_once("$r/commonTuya.php");

echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo '<title>TuyaDEAMON Things</title>';
echo StyleSheet();
echo "</head><body>";

if (file_exists("$r/setupdata.tmp.php")){
   require_once("$r/setupdata.tmp.php"); // data from setup
} else {
	  echo "<div class=error>Can't find the file <i> $r/setupdata.tmp.php. </i><br>";
          echo" Please do <b>Setup config file</b> step before.</div>";
          exit;
}

// --------------- start tests
if (isset($_GET['index'])) {
    $_POST = $_GET; // POST/GET compatible
}

if(isset($_POST["index"])){
   echo "<h3>parsing <i>tuya-cli wizard</i> file <i>$WIZARDFILE</i>... </h3>";
} else {
    echo '<div class="error">This page requires some parameters: you can\'t open it directly.<BR>
      Start from the <a href="index.php">index page.</a>';
    exit;
}

/*
echo "<pre>";
echo print_r($_POST);
echo "</pre>";
*/

$namelist = " ";
$lastgway = null;
// --------------  functions

 $ctotal = 0;
 $cvirtual = 0;
 $cnew = 0;

function  do_updateGateway($oldid, $tuyaid, $tuyaKEY ){
global $ctotal, $cvirtual;
$virtuals = sqlArray("SELECT thingID FROM allthings WHERE tuyaGateway = '$oldid' AND deviceClass = 'virtual' ;");
if (isset($virtuals) && (count($virtuals)>0))
	foreach($virtuals as $onev) {
		 sql("UPDATE `allthings` SET `tuyaGateway` = '$tuyaid', `tuyaKEY` = '$tuyaKEY' WHERE `thingID` = '$onev';");
		 $ctotal++;
         $cvirtual++;
 		 $virthing = sqlValue("SELECT thingName FROM allthings WHERE `thingID` = '$onev';");
		 echo "&nbsp;&nbsp;&nbsp; ...updated virtual device <i>$virthing</i>. <br>";
		 }
}


// saveone: exports a complete thing
function saveone($tuyaname, $tuyaid, $tuyakey, $tuyacid, $isGateway)
{
global $namelist, $gateways, $ctotal, $cvirtual, $cnew ;
// first pass: set
   //   echo "in saveone($tuyaname,$tuyaid,$tuyakey, $tuyacid)<br>";
    if ($tuyaname === null)
        return;
    if ($tuyaid === null)
        return;
 	$namelist .= ",$tuyaname";

	$match = "";  // to pretty print log
    $record = sqlRecord("SELECT * FROM allthings WHERE tuyaName = '$tuyaname' LIMIT 1");
    if (isset($record['thingID'])) {
	   $match =  "... match tuyaName<br>";
	} else{
        $record = sqlRecord("SELECT * FROM allthings WHERE tuyaID = '$tuyaid' LIMIT 1");
        if (isset($record['thingID'])) {
		  $match =  "... match tuyaID<br>";}
		else  if (!empty($tuyacid)){
			$record = sqlRecord("SELECT * FROM allthings WHERE tuyaCID = '$tuyacid' LIMIT 1 ");
			if (isset($record['thingID'])) {
		      $match =  "... match tuyaCID<br>";}
		}
	  }
   /// not found
    if (!isset($record['thingID'])) {
		$cnew++;
 	    echo "... not found thing in DB for  <b>$tuyaname</b> SmartLife device (new). <br>";
       	return;
    }

// found
    $oldid	= $record['tuyaID'];
    echo "... DB <i>allthings</i>: updated the " . $record['deviceClass'] . " thing <b>" . $record['thingName'] . "</b> ($tuyaname)<br>";
    echo "    ".$match ;
 	if (isset($record['thingID'])){
    $upsql = "UPDATE `allthings` SET `tuyaName` = '$tuyaname', `tuyaID` ='$tuyaid', `tuyaKEY` = ".(empty($tuyakey)? "NULL":"'$tuyakey'").", `tuyaCID` = ".(empty($tuyacid)?"NULL":"'$tuyacid'") ;
    $upsql .= " WHERE `thingID` = " . $record['thingID'] . ";";
//	echo $upsql ;
    sql($upsql);
	$ctotal++;
 	if ($record['deviceClass'] == 'real')
	     foreach($gateways as $id => $code){
	        if($oldid == $code){
               echo "... device " . $record['thingName'] . " is a Gateway: updating subdevices...<br>";
			   do_updateGateway($oldid, $tuyaid, $tuyakey );
	        }
	    }
    }
}

// saveone: exports a NEW thing
function savetwo($tuyaname, $tuyaid, $tuyakey, $tuyacid,$isGateway)
{
	global $lastgway, $ctotal, $cvirtual, $cnew ;

     if ($tuyaname === null)
        return;
    if ($tuyaid === null)
        return;
    if ($isGateway)  // is Gateway ?
          $lastgway = $tuyaid;

	$match = "";  // to pretty print log
    $record = sqlRecord("SELECT * FROM allthings WHERE tuyaName = '$tuyaname' LIMIT 1");
    if (isset($record['thingID'])) {
    	$ctotal++;
	   $match =  "... match tuyaName<br>";
	} else{
        $record = sqlRecord("SELECT * FROM allthings WHERE tuyaID = '$tuyaid' LIMIT 1");
  if (isset($record['thingID'])) {
        	      $ctotal++;
          		  $match =  "... match tuyaID<br>";}
        		else  if (!empty($tuyacid)){
        			$record = sqlRecord("SELECT * FROM allthings WHERE tuyaCID = '$tuyacid' LIMIT 1 ");
        			if (isset($record['thingID'])) {
        	          $ctotal++;
        		      $match =  "... match tuyaCID<br>";}
        		}
        	  }

   /// not found
    if (!isset($record['thingID'])) {
        $mySQL = "INSERT INTO `allthings` (`thingID`,`thingName`, `deviceClass`, `tuyaName`, `tuyaID`,  `tuyaKEY`, tuyaCID, `server`)";
        $mySQL .= "VALUES ( NULL, '$tuyaname', 'real', '$tuyaname','$tuyaid', '$tuyakey', ".($tuyacid?"'$tuyacid'":"NULL").", 'NEW' )";
 	    $cnew++;
       sql($mySQL);

		if (!empty($tuyacid)){
			 $upsql = "UPDATE `allthings` SET `deviceClass` = 'virtual', `tuyaGateway` ='$lastgway' ";
             $upsql .= " WHERE  `tuyaID` = '$tuyaid';";
             sql($upsql);
             echo "... DB <i>allthings</i>: added NEW virtual thing <b>undefined</b> ($tuyaname)<br>";

		 } else  {
	       echo "... DB <i>allthings</i>: added NEW real thing <b>undefined</b> ($tuyaname)<br>";
	 }
 } else {   //m found
		if($record['server'] == 'NEW'){
	    	echo "... NEW thing <b>". (isset($record['thingName'])?$record['thingName']:'undefined')."</b> ($tuyaname) exists: nothing to do<br>";
 		    }
		}
        return;
    }

/*
function savenames()
{
global $namelist, $BASEPATH;
$filenames = $BASEPATH . DIRECTORY_SEPARATOR ."tuyanames.tmp.php";
$content =  '<?php  $tuyanames = \''.$namelist."'; \n ?>" ;
file_put_contents($filenames, $content);
}
*/

/*
echo "<pre>";
echo print_r($record);
echo "</pre>";
*/

if (!file_exists($WIZARDFILE)){
		echo "<div class=error>FATAL ERROR: not found the file $$WIZARDFILE.</div>";
		exit;
		}

// -------------------  main
// local callback

$exportThing  = function($a) {
 saveone($a[0],$a[1],$a[2],$a[3],$a[4]);
};

$exportNew  = function($a) {
 savetwo($a[0],$a[1],$a[2],$a[3],$a[4]);
};

// forEachWizard in commonTuya.php
if (!isset($_POST['key2'])){
  echo " <b>merging wizard tuya data with DBase...</b><hr><br>";
  forEachWizard($exportThing, $WIZARDFILE);
  echo "<hr> <b> <br>Things (processed): $ctotal   <li> virtual: $cvirtual <li> real: ".($ctotal-$cvirtual)."<br><br>&nbsp;&nbsp; new things (not processed): $cnew<br>&nbsp;&nbsp; Total Things from wizard : ".($ctotal+$cnew). "</b><hr><br>";
}

if (isset($_POST['key2']) && ($_POST['key2'] == 'donew'))	{
    echo " <b> processing  wizard NEW tuya devices: </b><hr><br>";
   forEachWizard($exportNew, $WIZARDFILE);
 echo "<hr> <b> <br>New Things (added): $cnew </b><hr><br>";
}


// -------------------------------------------------- END PAGE (end stuff required by crudClass4)
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br><br>'; // end page menu
echo "</body></html>";

?>
