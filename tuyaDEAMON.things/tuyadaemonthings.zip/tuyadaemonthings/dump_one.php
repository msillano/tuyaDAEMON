<?php
$r = dirname(__FILE__);
require_once ("$r/lib/commonSQL.php"); // library + DB acess def
require_once ("$r/commonTuya.php");      // extra functions

// --------------- start tests
if (isset($_GET['key1']))
{
    $_POST = $_GET; // POST/GET compatible
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once ("$r/buildone.php"); // library

/*
echo "<pre>";
echo print_r($_POST);
echo "</pre>";
*/

//==================  main
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo '<link rel="stylesheet" type="text/css" href="./css/style2.css">';
echo '<title>TuyaDEAMON Things</title>';
// process one
$oneResult = doOneThing($_POST["key1"], $_POST["path"]);
// done
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center>'; // end page menu
echo "<HR>";
echo "<i>alldevices.json</i> fragment for ".(sqlValue("SELECT deviceClass FROM  allthings WHERE thingID = ".$_POST["key1"]." ;"))." Thing: <b>".(sqlValue("SELECT thingName FROM  allthings WHERE thingID = ".$_POST["key1"]." ;"))."</b><br><br>";
echo "<pre>";
echo restoreValue(json_encode($oneResult, JSON_PRETTY_PRINT));
if (json_last_error() != JSON_ERROR_NONE)
  echo  "+++ JSON Error - verify $filein";
echo "</pre>";
// -------------------------------------------------- END PAGE (end stuff required by crudClass4)
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br><br>'; // end page menu
echo "</body></html>";
?>
