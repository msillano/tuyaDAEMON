
-- --------------------------------------------------------

--
-- Struttura della tabella `lookupdecode`
--

DROP TABLE IF EXISTS `lookupdecode`;
CREATE TABLE `lookupdecode` (
  `type` char(40) NOT NULL COMMENT 'data encode/decode function'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `lookupdecode`
--

INSERT INTO `lookupdecode` (`type`) VALUES
('ARRAY8INT'),
('BOOLEANONOFF'),
('BOOLEANOPENCLOSE'),
('BYTESMALLFLOAT'),
('ENUMHIGHGOODLOW'),
('ENUMONOFFHOLD'),
('INTE2FLOAT'),
('NULL'),
('RECMODE'),
('SDSPACES'),
('STRUCTARGETTEMP'),
('STRUCTCOLOUR'),
('STRUCTELERT'),
('STRUCTINCH'),
('STRUCTRAND'),
('STRUCTREPEAT'),
('STRUCTTIMEHMS'),
('TSTAMP2TIME'),
('INTE3FLOAT');
