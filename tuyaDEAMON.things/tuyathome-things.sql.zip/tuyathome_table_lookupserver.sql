
-- --------------------------------------------------------

--
-- Struttura della tabella `lookupserver`
--

DROP TABLE IF EXISTS `lookupserver`;
CREATE TABLE IF NOT EXISTS `lookupserver` (
  `id` int(2) NOT NULL COMMENT 'for select: any id, for Things: id>10',
  `groups` char(16) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups` (`groups`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `lookupserver`
--

INSERT INTO `lookupserver` (`id`, `groups`) VALUES
(1, 'ALL'),
(30, 'Circeo 24H'),
(35, 'Circeo test'),
(8, 'COMMON'),
(7, 'COMMON-RM'),
(6, 'COMMON-SFC'),
(5, 'NEW'),
(20, 'Rome 24H'),
(25, 'Rome test'),
(0, 'void');
