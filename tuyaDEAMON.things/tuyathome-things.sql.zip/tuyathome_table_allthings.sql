
-- --------------------------------------------------------

--
-- Struttura della tabella `allthings`
--

DROP TABLE IF EXISTS `allthings`;
CREATE TABLE IF NOT EXISTS `allthings` (
  `thingID` int(11) NOT NULL AUTO_INCREMENT,
  `thingName` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `deviceClass` enum('real','virtual','fake') CHARACTER SET utf8 DEFAULT NULL,
  `deviceName` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaName` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaID` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaCID` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaGateway` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaKEY` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `server` char(16) CHARACTER SET utf8 DEFAULT NULL,
  `location` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `comment` tinytext CHARACTER SET utf8,
  `notes` tinytext CHARACTER SET utf8,
  PRIMARY KEY (`thingID`) USING BTREE,
  UNIQUE KEY `tuyaID` (`tuyaID`),
  KEY `thingName` (`thingName`) USING BTREE,
  KEY `use lookupserver` (`server`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4;
