
-- --------------------------------------------------------

--
-- Struttura della tabella `allthings`
--

DROP TABLE IF EXISTS `allthings`;
CREATE TABLE `allthings` (
  `thingID` int(11) NOT NULL,
  `thingName` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `deviceClass` enum('real','virtual','fake') CHARACTER SET utf8 DEFAULT NULL,
  `deviceName` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaName` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaID` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaCID` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaGateway` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `tuyaKEY` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `server` char(16) CHARACTER SET utf8 DEFAULT NULL,
  `location` char(40) CHARACTER SET utf8 DEFAULT NULL,
  `comment` tinytext CHARACTER SET utf8,
  `notes` tinytext CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
