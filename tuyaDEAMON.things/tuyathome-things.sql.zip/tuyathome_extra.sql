
--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `allthings`
--
ALTER TABLE `allthings`
  ADD PRIMARY KEY (`thingID`) USING BTREE,
  ADD UNIQUE KEY `tuyaID` (`tuyaID`),
  ADD KEY `thingName` (`thingName`) USING BTREE,
  ADD KEY `use lookupserver` (`server`);

--
-- Indici per le tabelle `sharething`
--
ALTER TABLE `sharething`
  ADD UNIQUE KEY `shareName` (`shareName`,`type`,`count`,`thingName`) USING BTREE,
  ADD KEY `thing must exist` (`thingID`);

--
-- Indici per le tabelle `specialthing`
--
ALTER TABLE `specialthing`
  ADD PRIMARY KEY (`id`),
  ADD KEY `thingID` (`thingID`,`DPkey`,`DPattribute`) USING BTREE;

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `allthings`
--
ALTER TABLE `allthings`
  MODIFY `thingID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `specialthing`
--
ALTER TABLE `specialthing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `allthings`
--
ALTER TABLE `allthings`
  ADD CONSTRAINT `use lookupserver` FOREIGN KEY (`server`) REFERENCES `lookupserver` (`groups`);

--
-- Limiti per la tabella `sharething`
--
ALTER TABLE `sharething`
  ADD CONSTRAINT `thing must exist` FOREIGN KEY (`thingID`) REFERENCES `allthings` (`thingID`) ON DELETE CASCADE ON UPDATE NO ACTION;
