
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `allthings`
--
ALTER TABLE `allthings`
  ADD CONSTRAINT `use lookupserver` FOREIGN KEY (`server`) REFERENCES `lookupserver` (`groups`);

--
-- Limiti per la tabella `sharething`
--
ALTER TABLE `sharething`
  ADD CONSTRAINT `thing must exist` FOREIGN KEY (`thingID`) REFERENCES `allthings` (`thingID`) ON DELETE CASCADE ON UPDATE NO ACTION;
