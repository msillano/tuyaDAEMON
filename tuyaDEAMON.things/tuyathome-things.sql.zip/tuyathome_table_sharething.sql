
-- --------------------------------------------------------

--
-- Struttura della tabella `sharething`
--

DROP TABLE IF EXISTS `sharething`;
CREATE TABLE IF NOT EXISTS `sharething` (
  `thingID` int(11) DEFAULT NULL,
  `thingName` char(40) DEFAULT NULL,
  `DPkey` char(40) DEFAULT NULL,
  `shareName` char(40) NOT NULL,
  `type` enum('test','action') NOT NULL,
  `count` int(3) NOT NULL DEFAULT '0',
  `eval_test` tinytext,
  `str_value` tinytext,
  `remote` char(80) DEFAULT NULL,
  `device` char(80) DEFAULT NULL,
  `property` char(80) DEFAULT NULL,
  UNIQUE KEY `shareName` (`shareName`,`type`,`count`,`thingName`) USING BTREE,
  KEY `thing must exist` (`thingID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
