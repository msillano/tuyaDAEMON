
-- --------------------------------------------------------

--
-- Struttura della tabella `specialthing`
--

DROP TABLE IF EXISTS `specialthing`;
CREATE TABLE `specialthing` (
  `id` int(11) NOT NULL,
  `thingID` int(11) NOT NULL,
  `thingName` char(80) NOT NULL,
  `DPkey` char(40) NOT NULL,
  `DPattribute` char(40) NOT NULL,
  `newValue` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
