
-- --------------------------------------------------------

--
-- Struttura della tabella `specialthing`
--

DROP TABLE IF EXISTS `specialthing`;
CREATE TABLE IF NOT EXISTS `specialthing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thingID` int(11) NOT NULL,
  `thingName` char(80) NOT NULL,
  `DPkey` char(40) NOT NULL,
  `DPattribute` char(40) NOT NULL,
  `newValue` tinytext,
  PRIMARY KEY (`id`),
  KEY `thingID` (`thingID`,`DPkey`,`DPattribute`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
