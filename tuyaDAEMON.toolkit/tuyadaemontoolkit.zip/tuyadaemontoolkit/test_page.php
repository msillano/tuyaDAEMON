 <?php
  error_reporting( E_ALL );
$r = dirname(__FILE__);
include("$r/lib/commonSQL.php");

// --------------- start tests
if (isset($_GET['key1'])) {
   $_POST = $_GET; // POST/GET compatible
}

if (!isset($_POST['key1'])) {
   echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
   echo StyleSheet();
   echo '</head><body><div class="error">This is a DEVICE page: you can\'t open it directly.<BR>
   Start from <a href="index.php">index page.</a>';
   echo '</body></html>';
   exit;
}
// globals
 $BASEURL = "http://localhost:1984";  // nodered  access
 $BASEREST= "/tuyaDAEMONdebug" ;  // REST debug interface
 $BASEFAST= "/tuyaDAEMON" ;  // REST fast interface
 $WAITTIME = 5500;   // for all, in ms, MUST be bigger than the timout defined in tuyaDEAMON CORE, node 'REST timeout', default 5 s
 
// ------ globals
$thedevice = sqlArrayTot("SELECT * FROM deviceinfos WHERE dName = '".$_POST['key1']."';");
$thedps = sqlArrayTot("SELECT * FROM devicedpoints WHERE dName = '".$_POST['key1']."' ORDER BY DPnumber *1, DPnumber ;");
// building page
echo "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8' /> \n";
echo "<style>body {background-color: linen;}.dp {font-weight:bold;text-align: center;}.note {font-family:verdana,arial,tahoma; font-size:12px; background-color: #eaf1dd; text-indent:0px; text-decoration:none; margin: 20px auto 10px auto; width: 700px; padding: 10px; border: solid 1px #8064a2;} \n";
echo "</style><script> \n";
echo " const initDetails = {method: 'get',headers: {'Content-Type': 'application/json; charset=utf-8'},mode: 'cors'} \n";
echo " var useURL = ''; \n // \n ";
 //
echo "  function httpGet(theUrl)   \n ";
echo "   {  let xhr = new XMLHttpRequest();   \n ";
echo "      xhr.open('GET', theUrl, false);   \n ";
echo "      try {xhr.send();  \n ";
echo "       if (xhr.status != 200) {   \n ";
echo "          alert(`Error \${xhr.status}: \${xhr.statusText}`);  \n ";
echo "          } else {  return(xhr.response); }    \n ";
echo "      } catch(err) {  alert('Request failed');}}  \n ";
//
echo "async function askList(url) { \n ";
echo "  const response = await fetch(url,initDetails);\n ";
echo "  return response.json(); }\n ";
//
echo " function getList() { ";
echo " var newurl = document.getElementById('useURL').value +'$BASEREST'; "; 
echo " askList(newurl) \n";
echo "  .catch((error) => { alert('Error:', error); return;}) " ;
echo "  .then ( data => { \n";
echo "            var newCODE = \"<select id='myDevice' > \"; \n ";
echo "            if (Array.isArray(data)) for( const item of data) { newCODE += \"<option value=\"+item+\">\"+item+\"</option>\"; }   \n ";
echo " 		      newCODE +='</select>'; \n ";	  
echo " if (useURL == newurl) { \n ";
echo " var x = document.getElementById('myDevice'); \n";
echo "	var xurl = document.getElementById('useURL').value +'$BASEFAST?device='+ encodeURIComponent (x.options[ x.selectedIndex].text) + '&property=' ; \n";
echo "  var aval ='';\n";
foreach($thedps as $adp){
 echo " aval = httpGet(xurl +'".urlencode($adp['DPnumber'])."'); \n";
 echo " var aval2 = JSON.parse(aval); \n";
 echo " document.getElementById('RESGET".$adp['DPnumber']."').value = ( typeof(aval2['value']) === 'object'? JSON.stringify(aval2['value']):aval2['value']); \n";
   }
echo " } else { \n ";
foreach($thedps as $adp){
 echo " document.getElementById('RESGET".$adp['DPnumber']."').value = ''; \n";
   }
echo " 	document.getElementById('devList').innerHTML = newCODE;    \n ";
echo "  useURL = newurl;  }}) }; \n";
//
echo " function GetData(url, butt) {fetch( url, initDetails ) .then( response =>{if ( response.status !== 200 ){alert( 'Looks like there was a problem. Status Code: ' +response.status ); return;} \n"; 
echo " console.log( response.headers.get( 'Content-Type' ) ); return response \n";
echo " .json();}).then( myJson =>{ var strrep = JSON.stringify(  myJson ); \n";
// echo " alert('Response ' + strrep) ;  \n ";
echo "if ((strrep.startsWith('{\"device\"') && ! strrep.includes('_connected'))     // set/get + multiple  \n";
echo "  ||  ((!strrep.startsWith('{\"device\"')) && strrep.includes('_connected'))) // schema  \n";
echo " {document.getElementById(butt).style.background='PaleGreen'; document.getElementById('RES'+butt).value = (typeof myJson.value === 'string'? myJson.value:JSON.stringify( myJson.value));} else document.getElementById(butt).style.background='tomato';}) \n";
echo " .catch( err =>{console.log( 'Fetch Error :-S', err );} );} \n";
echo " // \n ";
echo " var urlGET = []; var urlSET =[];\n";
  foreach($thedps as $adp){
   echo   "urlGET[".$adp['DPnumber']."] = \"&property=".$adp['DPnumber']."\" ; \n";
   echo   "urlSET[".$adp['DPnumber']."] = \"&property=".$adp['DPnumber']."&value=\" ; \n";
}
echo " // \n ";
//
echo "function myQuery(mode, dpx) {\n";
echo "document.getElementById( mode+dpx).style.background='yellow'; \n";
echo " var e = document.getElementById('myDevice'); \n";
echo "	var aurl = useURL+'?device='+ encodeURIComponent(e.options[e.selectedIndex].text); \n";
echo "	if (mode== 'GET') aurl +=  urlGET[dpx]; \n";
echo "	  else aurl += urlSET[dpx] + encodeURIComponent(document.getElementById('RESGET'+dpx).value) ; \n";	
echo " document.getElementById('showurl').value = aurl ;  \n ";
echo "	GetData(aurl, mode+dpx);} \n";
//
echo "async function doTests(){ document.getElementById('stime').style.display = 'inline'; \n";
$count = 0;
  foreach($thedps as $adp){
  if (in_array($adp['DPcapability'], ['RW','RO','UNK'] )) {
    echo   "document.getElementById('GET".$adp['DPnumber']."').style.background='lightgray';  \n";
    echo   "setTimeout(function(){ document.getElementById('GET".$adp['DPnumber']."').click(); }, ".($WAITTIME * $count++)."); \n";
    }
  if (in_array($adp['DPcapability'], ['RW','WW','WO','UNK'] )){
    echo   "document.getElementById('SET".$adp['DPnumber']."').style.background='lightgray';  \n";
    echo   "setTimeout(function(){ document.getElementById('SET".$adp['DPnumber']."').click(); }, ".($WAITTIME * $count++)."); \n"; }
   }
//   
echo  "doinfo(".((($WAITTIME * ($count -1))+3000)/1000)."); } \n";
echo " // \n ";
//
echo "function doSchema() {  \n";
echo " var f = document.getElementById('myDevice'); \n";
echo "	var burl = useURL+'?device='+ encodeURIComponent(f.options[f.selectedIndex].text) ; \n";
echo " document.getElementById('showurl').value = burl ;  \n ";
echo "	GetData(burl,'doSchema'); \n";
echo "   } ;  \n ";
//
echo "function doMultiple() {  \n";
echo " var g = document.getElementById('myDevice'); \n";
echo " var curl = useURL+'?device='+ encodeURIComponent(g.options[g.selectedIndex].text)+'&property=MULTIPLE&value={' ; \n";
foreach($thedps as $adp){
//  echo "   var ptype = document.getElementById('RULE".$adp['DPnumber']."').innerText; \n";
 echo "if (document.getElementById(\"MLT".$adp['DPnumber']."\").checked) {\n";
 echo "try { var xvalue =  document.getElementById(\"RESGET".$adp['DPnumber']."\").value; \n";
    switch($adp['DPtype']){                                               
          case 'boolean': 
             echo "  curl += '\"".$adp['DPnumber']."\":'+ (xvalue == true)+',';  \n";
             break;
          case 'int': 
          case 'enum': 
             echo "  curl += '\"".$adp['DPnumber']."\":'+ Number(xvalue) +','; \n";
             break;
          case 'string': 
             echo "  curl += '\"".$adp['DPnumber']."\":\"'+ xvalue +'\",'; \n";
             break;
        default:
             echo "  curl += '\"".$adp['DPnumber']."\":'+ (isNaN(Number(xvalue)) ? '\"'+xvalue+'\"' : Number(xvalue))+','; \n";
         }
   echo " } catch (error) {node.warn('Error in conversion from value(' + xvalue + ') to type ".$adp['DPtype']." : ' + error); } } \n ";
  }
echo " curl = curl.slice(0, -1)+ '}';  \n";
echo " document.getElementById('showurl').value = curl ;  \n ";
echo "	GetData(curl,'doMultiple'); \n";
echo "   } ;  \n ";

echo "function doinfo( tot) {var elem = document.getElementById('wtime'); var time = tot;var id = setInterval(frame, 1000);function frame() {if (time <= 0) {clearInterval(id);document.getElementById('stime').style.display = 'none';} else {time--; elem.textContent = time;}}} ;  \n ";
echo "</script></head><body onload='getList();'>  \n "; 
//
echo "<h2>Test for Tuya device: <i>".$thedevice[0]['dName']."</i></h2> \n";
//
echo "<div class='note' ><ul>";
echo " <li> This test requires <i> tuyaDEAMON running </i> and accessible at URL  <input type='text' id='useURL' value ='$BASEURL'  /> &nbsp; &nbsp;<button id='doList' onclick='getList()' style='background:#eaf1dd'>submit</button> <BR><BR>\n";
echo " <li> Select a device of type <b><i>".$thedevice[0]['dName']."</i></b> from: <span id='devList'><select name='myDevice' > </select></span>&nbsp; &nbsp;<button id='doList' onclick='getList()' style='background:#eaf1dd'>submit</button> \n";
echo "</ul><i>Use notes:<ol> <li> This <b>test mode</b> uses the </i><code>dp-ID</code><i> for requests, so don't worry about DBase property names. \n";
echo "<li> This <b>test mode</b> uses the </i><code>DPcapability</code><i> defined in DBase. To do a complete test you must set the 'device' capabilities to </i><code>ALL</code><i> and the 'dp' capability to </i><code>RW</code><i> (or delete/rename it) in the <code>global.alldevices</code>.  \n";
echo "<li>In some cases a <code>dp.type</code> can be required in <code>global.alldevices</code> to force a data type (e.g. <code>dp.type:string</code>, to send <code>'3'</code>[string] instead of the default <code>3</code>[int]).";
echo " <li>Performing a </i><b>[test SET]</b><i> with an empty <b><i>data</i></b> field becomes a </i><CODE>SET:null</CODE>.<i> Some dp that don't accept a GET, accepts the </i><CODE>SET:null</CODE><i> as a GET: this behavior can be forced in <code>alldevices</code> with the </i><code>'WW' DPcapability</code><i>. \n";
echo " <li>SET requires uncoded values, that is like values that appear after a [submit] or from a GET, but MULTIPLE requires encoded values.<i>. \n";
echo " <li>When doing tests on an unknown device, it is useful to see also the <b>tuyaDAEMON</b> debug pad with the </i>'<code>trace msg OUT from tuya devices</code>'<i> node enabled.\n"; 
echo " <li>After testing is complete, update the </i>DBase<i> tables with the production values and copy/paste the final JSON structure in </i><code>global.alldevices</code>.</ol></i></div></div> \n";
//
echo "<div class='note'><table border=1 align='center'> \n ";
echo "<tr><th width= 40>dp</th><th width= 200>name</th><th width= 80>GET</th><th width= 200>data</th><th width= 80>SET</th><th width= 10>MLT</th>  </tr>   \n ";
 foreach($thedps as $adp){
 $WRdisabled = ' disabled ';
 $RDdisabled = ' disabled ';
 if (in_array($adp['DPcapability'], ['RW','WW','WO','UNK'] ))  $WRdisabled = '';
 if (in_array($adp['DPcapability'], ['RW','RO','UNK'] ))  $RDdisabled = '';
  echo "<tr><td class='dp'>".$adp['DPnumber']."</td><td>&nbsp;".$adp['DPname']."</td><td> &nbsp;<button id='GET".$adp['DPnumber']."' $RDdisabled onclick=\"myQuery('GET', ".$adp['DPnumber'].")\">test GET</button>  \n ";
  echo "<td> &nbsp;<input type='text' id='RESGET".$adp['DPnumber']."' /> </td><td> &nbsp;<button id='SET".$adp['DPnumber']."'$WRdisabled onclick=\"myQuery('SET',".$adp['DPnumber'].")\">test SET</button></td><td><input type='checkbox' id='MLT".$adp['DPnumber']."' /></td></tr> \n ";
   }

echo "</table></div><hr> \n ";
//
echo "<div ><table width=800><tr><td width=50>&nbsp;</td><td width=300><button id='doTest' onclick='doTests()' style='background:#eaf1dd' >AUTO GET/SET</button><span id='stime' style='display:none'>&nbsp;&nbsp;wait &nbsp;<label id='wtime'>30</label>&nbsp;s</span></td><td><button id='doMultiple' onclick='doMultiple()' style='background:#eaf1dd' >MULTIPLE</button></td><td width=50>&nbsp;</td><td><button id='doSchema' onclick='doSchema()' style='background:#eaf1dd' >SCHEMA</button></td><td></td></tr></table></div> \n "; 
//
echo "<b><i>REST call:</i></b><br><div ><table width=800><tr><td width=50>&nbsp;</td> <td><input size=100 type='url' id='showurl' > </td><td></td></tr></table></div> \n "; 

//
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><br>'; //                    CHANGE: end page menu 
echo "</body></html> \n "; 
?>