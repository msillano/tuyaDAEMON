INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('power_strip', 'MS1801214', 'power_strip.jpg', 'Socket', 'ahwernlcacvtwe3c', 'WiFi', 'AC', 'ALL', 'Power Strip EU Standard With 4 Plug and 4 USB Port', 'Any GET sends all data (1-5,9-13, like SCHEMA), SET:null works OK, so all dp &#39;WW&#39;', 'MULTIPLE  sends switch data only if status changed.', 'https://www.aliexpress.com/item/32921984017.html', 'http://www.mumubiz.com/pd.jsp?id=153#_pp=102_582,https://aileen188.en.ec21.com/EU_WiFi_Smart_Power_Socket--10639011_10639195.html', 'MS1801214', '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'power_strip', '1', 'Switch1', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'power_strip', '2', 'Switch2', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'power_strip', '3', 'Switch3', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'power_strip', '4', 'Switch4', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'power_strip', '5', 'SwitchUSB', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'power_strip', '9', 'countdown1', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Relay toggles when count reaches 0. SET:0 no toggle.', 'PUSHed every 30 sec.'),
 ('', 'power_strip', '10', 'countdown2', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Relay toggles when count reaches 0. SET:0  no toggle.', 'PUSHed every 30 sec.'),
 ('', 'power_strip', '11', 'countdown3', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Relay toggles when count reaches 0. SET:0  no toggle.', 'PUSHed every 30 sec.'),
 ('', 'power_strip', '12', 'countdown4', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Relay toggles when count reaches 0. SET:0  no toggle.', 'PUSHed every 30 sec.'),
 ('', 'power_strip', '13', 'countdownUSB', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Toggles when count reaches 0. SET:0  no toggle.', 'PUSHed every 30 sec.');