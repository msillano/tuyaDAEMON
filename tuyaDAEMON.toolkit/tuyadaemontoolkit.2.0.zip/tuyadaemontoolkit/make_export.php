 <?php
$r = dirname(__FILE__);
include("$r/lib/commonSQL.php");
include("$r/lib/pclzip.lib.php");
  
// --------------- start tests
if (isset($_GET['key1'])) {
   $_POST = $_GET; // POST/GET compatible
}
 echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
 echo StyleSheet();

if (!isset($_POST['key1'])) {
   echo '</head><body><div class="error">This is a DEVICE page: you can\'t open it directly.<BR>
   Start from <a href="index.php">index page.</a>';
   echo '</body></html>';
   exit;
}
// globals
 $TMPDIR  = "\\tmp\\tuya\\work";      // must be writable
 //
 $thedevice = sqlArrayTot("SELECT * FROM deviceinfos WHERE dName = '".$_POST['key1']."';");
 $thedps =    sqlArrayTot("SELECT * FROM devicedpoints WHERE dName = '".$_POST['key1']."' ORDER BY DPnumber *1, DPnumber;");
//
function file_build_path(...$segments) {
    return join(DIRECTORY_SEPARATOR, $segments);
}

	function rrmdir($dir) {	 
		  if (is_dir($dir)) {
       $objects = scandir($dir);
       foreach ($objects as $object) {
         if ($object != "." && $object != "..") {
             if (filetype($dir.DIRECTORY_SEPARATOR.$object) == "dir") rrmdir($dir.DIRECTORY_SEPARATOR.$object); else unlink($dir.DIRECTORY_SEPARATOR.$object);
           }
         }
	       @rmdir($dir);
		   }
		}		
// step 0: buids a dir 
 if(file_exists($TMPDIR) && is_dir($TMPDIR)){
		//cleanup of the tmp dir													  
				  rrmdir(realpath(file_build_path($TMPDIR,'..')));
			}
   mkdir($TMPDIR, 0777, true);
   echo "STEP 0: temp dir is - ".realpath($TMPDIR)." <br>"; 
   
   $fromdir = realpath('.');
   $todir = realpath($TMPDIR);
   
 // step 1: copy image file
   $frompath = file_build_path($fromdir,'pics',$thedevice[0]['picName']);
   $topath = file_build_path($todir,'pics');
   mkdir($topath, 0777, true);
   $topath = file_build_path($topath,$thedevice[0]['picName']);
   if(file_exists($frompath)){
        copy($frompath, $topath);    
    }  else echo "ERROR: not found the image jpg file: $frompath <br>";   
   if(file_exists($topath)){
      echo "STEP 1: image file - PROCESSED <br>";
   }
   else
   {
      echo "STEP 1: image file - ABORT <br>";
      exit;
   }
   // step 2: copy JSON file
   $frompath = file_build_path($fromdir,'devicedata','device_'.$_POST['key1'].'.json');
   $topath = file_build_path($todir,'devicedata');
   mkdir($topath, 0777, true);
   $topath = file_build_path($topath, 'device_'.$_POST['key1'].'.json' );
   if(file_exists($frompath )){
        copy($frompath, $topath);    
    }  else echo "ERROR: not found the JSON file: $frompath <br>";   
   if(file_exists($topath)){
      echo "STEP 2: JSON file - PROCESSED <br>";
   }
   else
   {
      echo "STEP 2: JSON file - ABORT <br>";
      exit;
   }
    // step 3: copy pdf file
   $frompath = file_build_path($fromdir,'devicedata','device_'.$_POST['key1'].'.pdf');
   $topath = file_build_path($todir,'devicedata','device_'.$_POST['key1'].'.pdf');
   if(file_exists($frompath )){
        copy($frompath, $topath);    
    }  else echo "ERROR: not found the info pdf file: $frompath <br>";   
   if(file_exists($topath)){
      echo "STEP 3: Info pdf file - PROCESSED <br>";
   }
   else
   {
      echo "STEP 3: Info pdf file - ABORT <br>";
      exit;
   }

 $sql = "INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('".$thedevice[0]['dName']."', ".
(empty($thedevice[0]['model'])?"NULL":"'".$thedevice[0]['model']."'").", ".
(empty($thedevice[0]['picName'])?"NULL":"'".$thedevice[0]['picName']."'").", ".
(empty($thedevice[0]['tuyaType'])?"NULL":"'".$thedevice[0]['tuyaType']."'").", ".
(empty($thedevice[0]['tuyaProductID'])?"NULL":"'".$thedevice[0]['tuyaProductID']."'").", ".
(empty($thedevice[0]['protocol'])?"NULL":"'".$thedevice[0]['protocol']."'").", ".
(empty($thedevice[0]['power'])?"NULL":"'".$thedevice[0]['power']."'").", ".
(empty($thedevice[0]['capabilities'])?"NULL":"'".$thedevice[0]['capabilities']."'").", ".
(empty($thedevice[0]['description'])?"NULL":"'".$thedevice[0]['description']."'").", ".
(empty($thedevice[0]['note01'])?"NULL":"'".$thedevice[0]['note01']."'").", ".
(empty($thedevice[0]['note02'])?"NULL":"'".$thedevice[0]['note02']."'").", ".
(empty($thedevice[0]['sellerURL'])?"NULL":"'".$thedevice[0]['sellerURL']."'").", ".
(empty($thedevice[0]['refURL'])?"NULL":"'".$thedevice[0]['refURL']."'").", ".
(empty($thedevice[0]['infoURL'])?"NULL":"'".$thedevice[0]['model']."'").", ".
(empty($thedevice[0]['copynotice'])?"NULL":"'".$thedevice[0]['copynotice']."'")."); \r\n" ;

 if (isset($thedps[0])) {         
       $sql .= "INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   " ;
       foreach($thedps as $adp) {
           $sql .= "\r\n ('', ";
           $sql .= (empty($adp['dName'])?"NULL":"'".$adp['dName']."'").", ";
           $sql .= (empty($adp['DPnumber'])?"NULL":"'".$adp['DPnumber']."'").", ";
           $sql .= (empty($adp['DPname'])?"NULL":"'".$adp['DPname']."'").", ";
           $sql .= (empty($adp['DPtype'])?"NULL":"'".$adp['DPtype']."'").", ";
           $sql .= (empty($adp['DPvalues'])?"NULL":"'".$adp['DPvalues']."'").", ";
           $sql .= (empty($adp['DPdecode'])?"NULL":"'".$adp['DPdecode']."'").", ";
           $sql .= (empty($adp['DPcapability'])?"NULL":"'".$adp['DPcapability']."'").", ";
           $sql .= (empty($adp['DPnote01'])?"NULL":"'".$adp['DPnote01']."'").", ";
           $sql .= (empty($adp['DPnote02'])?"NULL":"'".$adp['DPnote02']."'")."),";
           };
        $sql =substr($sql, 0, -1).";";
        }
   // save as file
   $frompath = file_build_path($fromdir,'devicedata','device_'.$_POST['key1'].'.sql');
   file_put_contents($frompath, $sql);
   // step 4: copy sql file
   $topath = file_build_path($todir,'devicedata','device_'.$_POST['key1'].'.sql');
   if(file_exists($frompath )){
        copy($frompath, $topath);    
    }  else echo "ERROR: not found the SQL file: $frompath <br>";   
   if(file_exists($topath)){
      echo "STEP 4: SQL file - PROCESSED <br>";
   }
   else
   {
      echo "STEP 4: SQL file - ABORT <br>";
      exit;
   }
 
    $zippath = file_build_path($fromdir,'devicedata','device_'.$_POST['key1'].'.zip');
		  try {
	     $archive = new PclZip($zippath);
		   	$archive->create($todir,PCLZIP_OPT_REMOVE_PATH, $todir);	
		    }
   catch(Exception $e) {
       echo 'STEP 5: Compressing: ',  $e->getMessage(), "\n";
       exit;
       }
     echo "STEP 5: ZIP file - DONE <br>";
     echo "Export device file is: <code>$zippath</code>";
     echo '<hr><center><a href="" onclick="history.go(-1); return false;"> &lt;&lt; back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br><br>'; //   end page menu
     echo '</body></html>';
?>