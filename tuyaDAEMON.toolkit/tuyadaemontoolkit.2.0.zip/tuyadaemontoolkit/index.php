<?php 
$r=dirname(__FILE__);
// include("$r/lib/crudClass4.php");
require_once ("$r/lib/commonSQL.php");
include("$r/odtReportSQL.php");
// for custom menu, same look as getReportMenu  (in odtReportSQL.php)
function putUI($title, $description, $body, $href) {
$hcode = '<table border="1" cellpadding="0" cellspacing="0" id="dvContainer" >	<tr> <td>';
$hcode .= '<div style="font-family:verdana,arial,tahoma;	font-size:22px;	color:#316B40;	background-color:#E9E5D9; padding-left: 8px; width:500">'.$title.'</div>';
$hcode .= '</td></tr><tr><td>			<div style="font-family:verdana,arial,tahoma;font-size:12px;color:black;background-color:#F7F7EF;	padding-left: 3px;">';
$hcode .= $description.'</div></td></tr><tr>	<td style="background-color:#F7F7EF">';
$hcode .= '<form  border="1" name="report" style=" margin-bottom: 8pt;   margin-top: 8pt;" action="'.$href.'" method="put">';
$hcode .=  '<table id="dvForm" cellspacing="1" cellpadding="0" style="width: 340pt;background-color:#F7F7EF;">	<tr><td colspan=2></td>';
$hcode .=  '<td rowspan="3" style="width:60pt; vertical-align:middle;"><div>
						<button type="submit" style="background-color:#529214;border:1px solid #529214;color:#ffffff;" id="update" ><img src="update.gif" />   Go  </button>';
/*      
<!--					
$hcode .= 						<button type="submit" class="positive" id="update" name="update_x" value="1" onclick="return confirm('Questa operazione può cancellare tutto il DataBase!\nEffettuare prima un backup dei dati!') && validateData();"><img src="update.gif" /> Esegui</button>			  
-->	
*/					
$hcode .=  '</div></td></tr>'.$body;
/*
<!--fieldBlock			   
 $hcode .=  
     <tr><td  style="vertical-align:middle;"><div  style="text-align:right;">#fieldName#</div>
    		</td>
			<td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">#fieldInput#</td>
		</tr>
		
fieldBlock-->		 
*/                    
$hcode .=  '</table> </form>	</td> </tr> </table>';
return ($hcode);
}

//  now HTML
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
// echo StyleSheet();
echo  '<link rel="stylesheet" type="text/css" href="./css/style2.css">';
echo "</head><body>";
echo "<h1> tuyaDAEMON toolkit</h1>";// CHANGE:  page Title
echo "<div class='note' align='center'>Simple tool for the analysis of Tuya devices.";
echo  "<div align='left'><BR>You can, from here:<ul> \n";
echo "<li>Add/edit/delete tuya devices information on a MySQL database.</li>";
echo "<li>Test all Data Point capabilities of devices actually in <b>tuyaDAEMON</b></li>";
echo "<li>Generate a JSON fragment to update the <i>'global.alldevices'</i> as required by <b>tuyaDAEMON</b></li>";
echo "<li>Print an information page on a tuya device as documentation ('.odt' for OpenOffice).";
echo "<li>Build a zip file to share information about a device</b></li>";
echo "</ul></div></div>"; 
// menu 1 custom
   $body ='<tr><td  colspan=2 style="vertical-align:middle;padding-left: 5px;"> Main/detail pages: define before the <b>device</b>, after the <b>pds</b>. First delete the <b>pds</b>, then the <b>device</b>.</td></tr>';  
   echo "<div align='center'>".putUI("devices DBase access","Tables deviceinfos & devicedpoints management",$body, 'crud_deviceinfos.php')."</div><BR>";
// menu 2 custom
 $body = '<tr><td  style="vertical-align:middle;"><div  style="text-align:right;">Tuya device </div>	</td><td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">';
 $body .= '<select name="key1">'.optionsList("SELECT dName, dName FROM deviceinfos ORDER BY dName").'</select><BR></td></tr>';
 echo "<div align='center'>".putUI("Data Points explore","Auto/manual test. Requires tuyaDEAMON running",$body,'test_page.php')."</div><br>";
// menu 3 custom
 $body = '<tr><td  style="vertical-align:middle;"><div  style="text-align:right;">Tuya device </div></td><td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">';
 $body .= '<select name="key1">'.optionsList("SELECT dName, dName FROM deviceinfos ORDER BY dName").'</select><BR></td></tr>';
 echo "<div align='center'>".putUI("JSON creation","Copy/paste output into <code>global.alldevices</code>, then add local data",$body,'makeJSON.php')."</div><br>";
// menu 4: odtReportSQL menu standard, defined in DB table odt_reports
  echo "<div align='center'>".getReportMenu('index_page')."</div>";
// menu 5 custom
 $body = '<tr><td  style="vertical-align:middle;"><div  style="text-align:right;">Tuya device </div>	</td><td id="noMouseOver" style="vertical-align:middle;padding-left: 5px;">';
 $body .= '<select name="key1">'.optionsList("SELECT dName, dName FROM deviceinfos ORDER BY dName").'</select><BR></td></tr>';
 echo "<div align='center'>".putUI("Share device info","Makes a ZIP file: requires jpg, json, pdf files.",$body,'make_export.php')."</div><br>";

echo "<br></body></html>";  
$pdo = NULL; 

?>
