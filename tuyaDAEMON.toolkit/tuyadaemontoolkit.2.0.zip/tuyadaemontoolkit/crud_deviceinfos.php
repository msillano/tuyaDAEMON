<?php 
//
$r=dirname(__FILE__);
include("$r/lib/crudClass4.php");
require_once ("$r/lib/commonSQL.php");  // library + DB acess def
if (isset($_GET['dName'])){                                       // CHANGE:  here the PK 
   $_POST = $_GET;   // POST/GET compatible
   }
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo StyleSheet();
echo "</head><body>";
// 
/*
echo "<pre>";
echo print_r($_POST);
echo "</pre>";
*/
echo "<h1> devices master page: <i>add/edit/delete Tuya devices</i></h1>";//   page Title
echo "<div class='note' align='center'>This table presents all Tuya devices in DBase.</div>"; // 
// all the work is done by crudClass4: here only customizations for a good look and feel.
//--------------------------------------------------  CALLBACKS
//  add action SHOW DETAILS (dName is the pk/fk), goto: crud_devicedpoints.php?dName=xxxx
function crud_action_hook($record){
 // add action button 'VIEW DETAILS'  CHANGE:
    $code =  "<form action='crud_devicedpoints.php'  mode='POST'>";	   
    $code .= "<input type='hidden' name='dName' value=".$record['dName'].">";
    $code .=   "<input type='submit'  value='VIEW DETAILS'></form>";	   
   return $code;
}
// callback for some special edit fields, default is <input type='text'  value=$value>
function crud_get_edit($field, $value){
  $code = "$field: <input type='text' name='$field' value='$value' /><br>";  // general case txt
   // custom special case for select an array[constants]: "SELECT DISTINCT tbl.* FROM (VALUES('a'),('b'),('a'),('v')) AS tbl"
   // works with mariaDB 10.4.11, don't works with 10.6.4, replaced with make_select4list().
   if ($field === 'protocol'){
        // constants options, use SELECT to get array
      $code = crudClass::make_select4list($field, "WiFi,ZigBee,Bluethoot,mixed,other,NULL", $value);   //        list 
      }    
  if ($field === 'power'){
       // constants options, use SELECT to get array
     $code = crudClass::make_select4list($field, "BAT,USB,AC,USB+BAT,AC+BAT,UPS,NULL", $value);   //        list 
      } 
  if ($field === 'capabilities'){
         // checkbox, use SELECT to get array, requires format in before_update() and before_create())
     $code = crudClass::make_checkbox($field, ['ALL','SET','GET','SCHEMA','MULTIPLE','REFRESH','NONE'], explode(',',$value)," "); //  list
      } 
 return $code;
} 
// callback for some special input fields, default is <input type='text'>
function crud_get_input($field){
         
  $code = "$field: <input type='text' name='$field' /><br>";  // general case
   // custom special cases    
  if ($field === 'protocol'){
       // constants options, use SELECT to get array
       $code = crudClass::make_select4list($field, "WiFi,ZigBee,Bluethoot,mixed,NULL", 'WiFi');   //        list 
      }     
  if ($field === 'power'){
        // constants options, use SELECT to get array
      $code = crudClass::make_select4list($field, "BAT,USB,AC,USB+BAT,AC+BAT,UPS,NULL", 'BAT');     //        list 
      } 
  if ($field === 'capabilities'){
      // ceckbox, use SELECT to get array, requires format in before_update() and before_create())
     $code = crudClass::make_checkbox($field, ['ALL','SET','GET','SCHEMA','MULTIPLE','REFRESH','NONE'], ['ALL']," "); //  list 
      } 
 return $code;
} 
// extra cleanup for some user inputs
// ----------- for update
function cleanUpForFile($usrstr){
// chars not allowed in file name
preg_match ( "/^(.* = )'(.*)'$/", $usrstr ,$matches);
if (count($matches) <3) return $usrstr;
if (empty($matches[2]) || ($matches[2] === 'NULL')) return $matches[1].'NULL';
return  $matches[1]."'".str_replace(array("\\","/",":","*","?","\"","'","<",">",")","|",","," "),"_",$matches[2])."'";
}
function cleanUpForSafe($usrstr){
// safe for sql injection
preg_match ( "/^(.* = )'(.*)'$/", $usrstr ,$matches);
if (count($matches) <3) return $usrstr;
if (empty($matches[2]) || ($matches[2] === 'NULL')) return $matches[1].'NULL';
return  $matches[1]."'".str_replace(array("\\","\"","'","<",">"),array("\\\\","&#39;","&#39;","&#60;",">"),$matches[2])."'";
}
function cleanUpForURL($usrstr){
// urlescape
preg_match ( "/^(.* = )'(.*)'$/", $usrstr ,$matches);
if (count($matches) <3) return $usrstr;
if (empty($matches[2]) || ($matches[2] === 'NULL')) return $matches[1].'NULL';
return  $matches[1]."'".str_replace(array("\"","'"," "),array("%22","%27","+"),trim($matches[2],"'\""))."'";
}
// ----------- for create
function cleanCrForFile($usrstr){
if (empty($usrstr) || ($usrstr === "''") || ($usrstr === 'NULL') || ($usrstr === "'NULL'")) return 'NULL';
return  "'".str_replace(array("\\","/",":","*","?","\"","'","<",">","|",","," "),"_",trim($usrstr,"'"))."'";
}
function cleanCrForSafe($usrstr){
if (empty($usrstr) || ($usrstr === "''") || ($usrstr === 'NULL') || ($usrstr === "'NULL'")) return 'NULL';
preg_match ( "/^'(.*)'$/", $usrstr ,$matches);
return "'".str_replace(array("\\","\"","'","<",">"),array("\\\\","&#39;","&#39;","&#60;",">"),$matches[1])."'";
}
function cleanCrForURL($usrstr){
if (empty($usrstr) || ($usrstr === "''") || ($usrstr === 'NULL') || ($usrstr === "'NULL'")) return 'NULL';
return  "'".str_replace(array("\"","'"," "),array("%22","%27","+"),trim($usrstr,"'"))."'";
}

function before_update($update_array) {
 // special processing for checkbox, max 10 options
    $ckfield="capabilities";
    $i = 1;
    $st ="";
    for ($i = 1; $i<10; $i++){
        if (isset($_POST[$ckfield.$i])){
           if (strlen($st)>1)
               $st.=',';
           $st .= $_POST[$ckfield.$i];
           }   
        }    
    // the position is fixed, until don't change DB
   $update_array[7] = "`$ckfield` = '$st'";
//   
//    [0] => `dName` = '_Temperature_Humidity_Sensor_'
//    [1] => `model` = 'WSDCGQ11LM'
//    [2] => `picName` = 'Temperature_Humidity_Sensor.jpg'
   
// sanification of text fields  
   $update_array[0] = cleanUpForFile($update_array[0]);  
   $update_array[1] = cleanUpForSafe($update_array[1]);  
   $update_array[2] = cleanUpForFile($update_array[2]);
   $update_array[3] = cleanUpForSafe($update_array[3]);
   $update_array[4] = cleanUpForSafe($update_array[4]);
   $update_array[5] = cleanUpForSafe($update_array[5]);
   $update_array[6] = cleanUpForSafe($update_array[6]);
   $update_array[8] = cleanUpForSafe($update_array[8]);
   $update_array[9] = cleanUpForSafe($update_array[9]);
   $update_array[10] = cleanUpForSafe($update_array[10]);
   $update_array[11] = cleanUpForURL($update_array[11]);
   $update_array[12] = cleanUpForURL($update_array[12]);
   $update_array[13] = cleanUpForURL($update_array[13]);
 //  $update_array[14] = cleanUpForURL($update_array[14]);
  return $update_array;
}
// special processing for checkbox, max 10 options
function before_create($post_fields) {
    $ckfield="capabilities";
    $i = 1;
    $st ="";
    for ($i = 1; $i<10; $i++){
        if (isset($_POST[$ckfield.$i])){
           if (strlen($st)>1)
               $st.=',';
           $st .= $_POST[$ckfield.$i];
           }   
        }
// the position is fixed, until don't change DB
    $post_fields[7] = "'$st'";
//   [0] => '_Temperature_Humidity_Sensor_'
//   [1] => 'WSDCGQ11LM'
    
// sanification of text fields  
   $post_fields[0] = cleanCrForFile($post_fields[0]);  // name
   $post_fields[1] = cleanCrForSafe($post_fields[1]);  
   $post_fields[2] = cleanCrForFile($post_fields[2]);
   $post_fields[3] = cleanCrForSafe($post_fields[3]);
   $post_fields[4] = cleanCrForSafe($post_fields[4]);
   $post_fields[5] = cleanCrForSafe($post_fields[5]);
   $post_fields[6] = cleanCrForSafe($post_fields[6]);
   $post_fields[8] = cleanCrForSafe($post_fields[8]);
   $post_fields[9] = cleanCrForSafe($post_fields[9]);
   $post_fields[10] =cleanCrForSafe($post_fields[10]);
   $post_fields[11] = cleanCrForURL($post_fields[11]);
   $post_fields[12] = cleanCrForURL($post_fields[12]);
   $post_fields[13] = cleanCrForURL($post_fields[13]);
//   $post_fields[14] = cleanCrForURL($post_fields[14]);

 return $post_fields;
}
// -------------------------------------------------- END CALLBACKS
// ================= stuff required by crudClass4: 
//  Initiate the class with table information: table-name, fields, pk
$crud = new crudClass('deviceinfos','dName,model,picName,tuyaType,tuyaProductID,protocol,power,capabilities,description,note01,note02,sellerURL,refURL,infoURL','dName' );
// actions before to build the page
if (isset($_POST['submit'])){
    $create_sql = $crud->create();//Fetch INSERT query
    sql($create_sql);
}
if (isset($_POST['update'])){
    $update_sql = $crud->update();//Fetch UPDATE query
    sql($update_sql);
}
if (isset($_POST['delete'])){
    $delete_sql = $crud->delete();//Fetch DELETE query
    sql($delete_sql);
}
// ------------- builds the HTML:
if (isset($_POST['edit'])){
// edit
    echo "<div class='note' align='right'>";
    echo $crud->renderEditor();//Prepare data edit form
    echo '</div>' ;
    } else {
// or insert    
    echo "<div class='note' align='right'>";
    echo $crud->create_form();//Prepare data entry form
    echo '</div>';
    }
 // table   
  echo "<div class='note' align='center'>Choose a device, then edit/delete it, or edit <i>data points</i> definitions.<br>";
  echo "Do not forget the jpeg image 300x300 in the <code>/pics/</code> dir!</div>"; // custom intro box
//
echo $crud->renderVertically(' ORDER BY `dName`');       // custom for WHERE or ORDER or LIMIT 
// -------------------------------------------------- END PAGE (end stuff required by crudClass4) 
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br><br>';                                    // end page menu 
echo "</body></html>";  
$pdo = NULL; 
?>
