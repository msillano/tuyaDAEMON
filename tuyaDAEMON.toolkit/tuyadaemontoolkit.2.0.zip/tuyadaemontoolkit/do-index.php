 <?php

/*
# Devices availables

- ![](https://github.com/msillano/tuyaDAEMON/blob/main/pics/ico_Door_Sensor.gif) Tuya device [Door_Sensor](https://github.com/msillano/tuyaDAEMON/blob/main/devices/Door_sensor/device_Door_Sensor.pdf)
- ![](https://github.com/msillano/tuyaDAEMON/blob/main/pics/ico_LED_700ml_Humidifier.gif) Tuya device [LED_700ml_Humidifier](https://github.com/msillano/tuyaDAEMON/blob/main/devices/LED_700ml_Humidifier/device_LED_700ml_Humidifier.pdf)
*/
$r = dirname(__FILE__);
require_once("$r/lib/commonSQL.php");

// options
$COMMENTS_IN_ALLDEVICES = false;
$VALUES_IN_ALLDEVICES = true;

// --------------- start tests

// ------ globals
$indent = 3;
$thedevice = sqlArrayTot("SELECT dName, picName FROM deviceinfos ORDER BY dName");

function dodevice(){
global $thedevice;
$ret ="";
for( $i=0; $i< count($thedevice); $i++){
$xdev = $thedevice[$i][0];
$xpic = $thedevice[$i][1];
$ret .= "- ![](https://github.com/msillano/tuyaDAEMON/blob/main/pics/ico_$xpic) [$xdev](https://github.com/msillano/tuyaDAEMON/blob/main/devices/$xdev/device_$xdev.pdf) \n\r";
}

return $ret;
}




// ================================ main
$devdef = "";
$devdef .= doDevice();
$devdef .= "\r\n";
//
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo StyleSheet();
echo '</head><body>';
echo '<pre>';
echo $devdef;
echo '</pre>';
