 <?php
//
$r = dirname(__FILE__);
include("$r/lib/crudClass4.php");
require_once ("$r/lib/commonSQL.php");  // library + db access def
//
if (isset($_GET['dName'])) { // CHANGE:  here the PK
   $_POST = $_GET; // POST/GET compatible
} 
// test for dName (can be name)
if (!isset($_POST['dName'])){
     echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
     echo StyleSheet();
     echo '</head><body><div class="error">This is a DETAIL page: you can\'t open it directly.<BR>
     Start from <a href="crud_deviceinfos.php">master devices page.</a>';
     echo '</body></html>';
     exit;
     }
$apc = sqlValue("SELECT picName FROM deviceinfos WHERE dName = '".$_POST['dName']."';");
if ((!isset($apc)) ||($apc == null)){
     echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
     echo StyleSheet();
     echo '</head><body><div class="error">The "dName" ('.$_POST['dName'].') parameter is not valid/no picName field.<BR>
     Verify in <a href="crud_deviceinfos.php">master devices page.</a>';
     echo '</body></html>';
     exit;
}
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo StyleSheet();
echo "</head><body>";
echo '<h1> <i>device</i> '.$_POST['dName'].'</h1>';// CHANGE:  page Title
echo "<div class='note' ><table class='noborder' width=100%><tr class='noborder'><td class='noborder'><img border= 1px src='./pics/$apc' style='width:100px;height:100px;' alt='pics/$apc'></td><td class='noborder'>This table presents the known data points for this device. <br>Add/edit/delete them.</td></tr></table></div>"; //  CHANGE: intro box
// all the work is done by crudClass4: here only customizations for a good look and feel.
//--------------------------------------------------  CALLBACKS
// callback for some special input fields, default is <input type='text'>
function crud_get_input($field) {
   $code = "$field: <input type='text' name='$field' /><br>";
   if ($field == 'dName') {
     // readonly, set to  $_POST['dName']
      if (isset($_POST['dName'])) {
           $code = "device name: <input type='text' name='$field' value='".$_POST['dName']."' readonly /><br>";
      }
   }
   if ($field === 'DPdecode'){
      // gets values from lookup table
       $code = crudClass::make_select($field, "SELECT * FROM lookupdecode",('NULL'));   //        list 
      }  
   if ($field === 'DPtype'){
       // constants options, use SELECT to get array
       $code = crudClass::make_select4list($field, "boolean,enum,int,string,binary,NULL", ('NULL'));
      } 
   if ($field === 'DPcapability'){
        // constants options, use SELECT to get array
      $code = crudClass::make_select4list($field, "RW,WW,GW,RO,WO,TRG,PUSH,UNK", ('RW'));
      } 
  return $code;
}

// callback for some special edit fields, default is <input type='text' value='$value'>
function crud_get_edit($field, $value) {
   $code = "$field: <input type='text' name='$field' value='$value' /><br>"; // general case
   // custom special cases
   if ($field == 'dName') {
    //  readonly, 
      $code = "device.name: <input type='text' name='$field' value='$value' readonly /><br>";
   }
   if ($field === 'DPdecode'){
      // gets values from lookup table
      $code = crudClass::make_select($field, "SELECT * FROM lookupdecode", (empty($value)?'NULL': $value));   //        list 
      } 
   if ($field === 'DPtype'){
         // constants options, use SELECT to get array
     $code = crudClass::make_select4list($field, "boolean,enum,int,string,binary,NULL", (empty($value)?'NULL': $value));
      } 
   if ($field === 'DPcapability'){
         // constants options, use SELECT to get array
     $code = crudClass::make_select4list($field, "RW,WW,GW,RO,WO,TRG,PUSH,UNK", ($value));
      }    
    return $code;
}
// extra cleanup for some user inputs
function cleanUpForSafe($usrstr){
// safe for sql injection
preg_match ( "/^(.* = )'(.*)'$/", $usrstr ,$matches);
if (count($matches) <3) return $usrstr;
if (empty($matches[2]) || ($matches[2] === "NULL")) return $matches[1].'NULL';
//return  
return  $matches[1]."'".str_replace(array("\\","\"","'","<",">"),array("\\\\","&#39;","&#39;","&#60;",">"),$matches[2])."'";
}

function cleanCrForSafe($usrstr){
if (empty($usrstr) || ($usrstr === "''")|| ($usrstr === "NULL")|| ($usrstr === "'NULL'")) return 'NULL';
preg_match ( "/^'(.*)'$/", $usrstr ,$matches);
//return "'".str_replace(array("\\","\"","'","<",">","&"),array("&#92;","&#39;","&#39;","&#60;","&#62;","&#38;"),trim($usrstr,"'\""))."'";
return "'".str_replace(array("\\","\"","'","<",">"),array("\\\\","&#39;","&#39;","&#60;",">"),$matches[1])."'";
}
// 
function before_update($update_array) {
 // sanification of text fields  
  $update_array[1] = cleanUpForSafe($update_array[1]);  
  $update_array[2] = cleanUpForSafe($update_array[2]);
  $update_array[3] = cleanUpForSafe($update_array[3]);
  $update_array[4] = cleanUpForSafe($update_array[4]);
  $update_array[5] = cleanUpForSafe($update_array[5]);
  $update_array[6] = cleanUpForSafe($update_array[6]);
  $update_array[7] = cleanUpForSafe($update_array[7]);
  $update_array[8] = cleanUpForSafe($update_array[8]);   
return ($update_array);
}
function before_create($create_array) {
 // sanification of text fields  
   $create_array[1] = cleanCrForSafe($create_array[1]);
   $create_array[2] = cleanCrForSafe($create_array[2]);
   $create_array[3] = cleanCrForSafe($create_array[3]);
   $create_array[4] = cleanCrForSafe($create_array[4]);
   $create_array[5] = cleanCrForSafe($create_array[5]);
   $create_array[6] = cleanCrForSafe($create_array[6]);
   $create_array[7] = cleanCrForSafe($create_array[7]);
   $create_array[8] = cleanCrForSafe($create_array[8]);
return ($create_array);
}
// -------------------------------------------------- END CALLBACKS
// ================= stuff required by crudClass4: 
$crud = new crudClass('devicedpoints', 'dName,DPnumber,DPname,DPtype,DPvalues,DPdecode,DPcapability,DPnote01,DPnote02', 'dName,id'); //  Initiate the class with table information: table-name, fields, pk
// actions before to build the page
if (isset($_POST['submit'])) {
   $create_sql = $crud->create(); //Fetch INSERT query
   sql($create_sql);
}
if (isset($_POST['update'])) {
   $update_sql = $crud->update(); //Fetch UPDATE query
   sql($update_sql);
}
if (isset($_POST['delete'])) {
   $delete_sql = $crud->delete (); //Fetch DELETE query
   sql($delete_sql);
}
// ------------- builds the HTML:
if (isset($_POST['edit'])) {
   // edit
   echo "<div class='note' align='right'>";
   echo $crud->renderEditor(); //Prepare data edit form
   echo '</div>';
} else {
   // or insert
   echo "<div class='note' align='right'>";
   echo $crud->create_form(); //Prepare data entry form
   echo '</div>';
}
//  no custom intro box here
if (isset($_POST['dName'])) { // if becomes from master page  
   echo $crud->renderVertically(' WHERE dName = \''.$_POST['dName'].'\' ORDER BY DPnumber*1, DPnumber'); // DETAIL: limit records to dName
} else
   echo $crud->renderVertically(' ORDER BY DPnumber'); // else show all
// -------------------------------------------------- END PAGE (end stuff required by crudClass4) 
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="crud_deviceinfos.php">MASTER</a> &nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br><br>'; // end page menu 
echo "</body></html>";
?>
