 <?php
$r = dirname(__FILE__);
require_once("$r/lib/commonSQL.php");
include("$r/odtReportSQL.php");

// options
$COMMENTS_IN_ALLDEVICES = false;
$VALUES_IN_ALLDEVICES = true;

// --------------- start tests
if (isset($_GET['key1'])) {
   $_POST = $_GET; // POST/GET compatible
}

if (!isset($_POST['key1'])) {
   echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
   echo StyleSheet();
   echo '</head><body><div class="error">This is a DETAIL page: you can\'t open it directly.<BR>
   Start from <a href="index.php">index page.</a>';
   echo '</body></html>';
   exit;
}

// ------ globals
$indent = 3;
$thedevice = sqlArrayTot("SELECT * FROM deviceinfos WHERE dName = '".$_POST['key1']."';");
$thedps = sqlArrayTot("SELECT * FROM devicedpoints WHERE dName = '".$_POST['key1']."' ORDER BY DPnumber *1, DPnumber ;");

// ----------------  locals functions
function reverseForSafe($usrstr){
return str_replace(array("&#92;","&#34;","&#39;","&#60;","&#62;","&#38;"),array("\\","'","'","<",">","&"),$usrstr);
}

// prints string, skips optionals
function printlinestr($ind, $name, $val) {
   if (empty($val)) return "";
   $safestr =  json_encode($val); 
   $res = "\r\n".str_repeat(' ', $ind)."\"$name\": $safestr,";
   return $res;
}

// prints number, skips optionals
function printlinenum($ind, $name, $val) {
   if (empty($val)) return "";
   $res = "\r\n".str_repeat(' ', $ind)."\"$name\": ".$val.",";
   return $res;
}

// prints set, skips optionals
function printlineset($ind, $name, $val) {
   if (empty($val)) return "";
   $res = "\r\n".str_repeat(' ', $ind)."\"$name\": [";
   $parts = explode(',', $val);
   foreach($parts as $v)
   $res .= '"'.$v.'",';
   $res = killlast($res);
   $res .= '],';
   return $res;
}

// kills final ','
function killlast($buff) {
   return substr( $buff, 0, -1);
}

// print one dp
function doonedp($ind, $adp) {
   global $COMMENTS_IN_ALLDEVICES;
   global  $VALUES_IN_ALLDEVICES;
   $res = "";
   $res .= printlinenum($ind, 'dp', $adp['DPnumber']);
   $res .= printlinestr($ind, 'name', $adp['DPname']);
   if (( !empty($adp['DPcapability'])) && ($adp['DPcapability'] !== 'UNK') && ($adp['DPcapability'] !== 'RW'))
      $res .= printlinestr($ind, 'capability', $adp['DPcapability']);
   $pos = 1;   
   if (( !empty($adp['DPdecode'])) && ($adp['DPdecode'] !== 'NONE')){
      $res .= printlinestr($ind, 'typefield', $adp['DPdecode']);
      } else {
       if ( !empty($adp['DPtype'])) 
             $res .= printlinestr($ind, 'type', $adp['DPtype']);
       if ($VALUES_IN_ALLDEVICES){
          if ( !empty($adp['DPvalues'])){  
                $pos++;
                $res .= printlinestr($ind, 'comment_01', 'Values: '.$adp['DPvalues']);
                }
           }
       }
    if ($COMMENTS_IN_ALLDEVICES){
       if ( !empty($adp['DPnote01']))             
          $res .= printlinestr($ind, 'comment_0'.$pos++, $adp['DPnote01']);
       if ( !empty($adp['DPnote02']))             
          $res .= printlinestr($ind, 'comment_0'.$pos, $adp['DPnote02']);
          }
   $res = killlast($res);
   return ($res);
}

// print one device
function dodevice($ind) {
   global $COMMENTS_IN_ALLDEVICES;
   global $thedevice;
   global $thedps;
   global $indent;
   if (!isset($thedevice[0])) {   
        return "ERROR! device not found in global.tuyastatus";
       }   
   $res = "";
   $res .= printlinestr($ind, 'name', 'device-unique-user-name');
   if ($thedevice[0]['protocol'] !== 'WiFi') {
      $res .= printlinestr($ind, 'cid', 'device-cid');
      $res .= printlinestr($ind, 'gateway', 'gateway-id');
   } else {
      $res .= printlinestr($ind, 'id', 'device-id');
   }
   switch ($thedevice[0]['power']) {
      // from: 'AC','BAT','USB','USB+BAT','AC+BAT','other'
      // to:   'BAT'` | `'AC'` | `'UPS'`
      case 'BAT':
         $res .= printlinestr($ind, 'power', 'BAT');
         break;
      case 'USB':
      case 'AC':
         $res .= printlinestr($ind, 'power', 'AC');
         break;
      case 'UPS':
      case 'USB+BAT':
      case 'AC+BAT':
         $res .= printlinestr($ind, 'power', 'UPS');
         break;
      }
   if (( !empty($thedevice[0]['capabilities'])) && ($thedevice[0]['capabilities'] !== 'ALL'))
         $res .= printlineset($ind, 'capability', $thedevice[0]['capabilities']);
   if ($COMMENTS_IN_ALLDEVICES){
       if ( !empty($thedevice[0]['note-1'])) 
             $res .= printlinestr($ind, 'comment_01', $thedevice[0]['note01']);
       if ( !empty($thedevice[0]['note-2'])) 
             $res .= printlinestr($ind, 'comment_02', $thedevice[0]['note02']);
             }
   if (isset($thedps[0])) {         
       $res .= "\r\n".str_repeat(' ', $ind).'"dps": [';
       foreach($thedps as $adp) {
          $res .= "\r\n".str_repeat(' ', $ind + $indent).'{';
          $res .= doonedp($ind + $indent + $indent, $adp);
          $res .= "\r\n".str_repeat(' ', $ind + $indent).'},';
          }
       $res = killlast($res);
       $res .= "\r\n".str_repeat(' ', $ind).']';
       } else
         $res = killlast($res);
   return ($res);
}

// ================================ main
$devdef = "";
$spaces = $indent + $indent;
$devdef .= str_repeat(' ', $spaces).'{';
$devdef .= doDevice($spaces + $indent);
$devdef .= "\r\n".str_repeat(' ', $spaces).'},'."\n\r";
echo '<html><head><meta content="text/html; charset=UTF_8" http-equiv="content-type">';
echo StyleSheet();
echo '</head><body>';
echo '<pre>';
echo $devdef;
echo '</pre>';
// save as file
file_put_contents(realpath("./devicedata/").DIRECTORY_SEPARATOR.'device_'.$_POST['key1'].'.json',reverseForSafe($devdef));
//
echo 'Saved as <code>'.'devicedata/device_'.$_POST['key1'].'.json'.'</code><br>';
echo '<hr><center> <a href="javascript:history.go(-1)"><<< back </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="index.php">home</a> </center><hr><br><br>'; //   end page menu
echo '</body></html>';
?>
