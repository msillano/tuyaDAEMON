-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mar 01, 2021 alle 19:09
-- Versione del server: 10.4.11-MariaDB
-- Versione PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tuyathome`
--
CREATE DATABASE IF NOT EXISTS `tuyathome` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tuyathome`;

-- --------------------------------------------------------

--
-- Struttura della tabella `devicedpoints`
--

CREATE TABLE `devicedpoints` (
  `id` int(11) NOT NULL COMMENT 'auto index',
  `dName` char(80) DEFAULT NULL COMMENT 'fk from deviceinfos',
  `DPnumber` char(40) NOT NULL COMMENT 'Data Point ID (number)',
  `DPname` char(80) DEFAULT NULL COMMENT 'User data point name, or from smartlife app or from https://iot.tuya.com/cloud/appinfo/cappId/deviceList (info/detail) if available.',
  `DPtype` enum('boolean','enum','int','string','binary','see note') DEFAULT NULL COMMENT 'Used only if DPdecode not exist.\r\nDefault ''auto'' (i.e. number as INT).\r\nFrom device response.\r\nCompare also with https://iot.tuya.com/cloud/appinfo/cappId/deviceList (info/detail) if available. \r\n',
  `DPvalues` tinytext DEFAULT NULL COMMENT 'Free info, like:  A|B = one|two or range [1..255]',
  `DPdecode` char(40) DEFAULT NULL COMMENT 'from lookupudecode table. Keep it updated.',
  `DPcapability` enum('RO','WO','WW','GW','RW','TRG','PUSH','UNK') DEFAULT 'RW' COMMENT 'WW: use SET:null as GET;\r\nTRG: none, only TRIGGER;\r\nPUSH: none, auto-send.\r\nDefault: RW',
  `DPnote01` tinytext DEFAULT NULL COMMENT 'free  comment, used in ''alldevices''',
  `DPnote02` tinytext DEFAULT NULL COMMENT 'free comment, used in ''alldevices'''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `devicedpoints`
--

INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`, `DPcapability`, `DPnote01`, `DPnote02`) VALUES
(1, 'Smart_Switch01', '1', 'switch', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', 'Toggles when the countdown goes to 0; SET(102):0 =&#62; the switch does not change', NULL),
(2, 'Smart_Switch01', '102', 'countdown', 'int', '0..86500 s  (24H max.)', NULL, 'WW', 'PUSH every (30 * k) s; GET returns last PUSHed value, not the actual count', 'DPcapability for test: &#39;RW&#39;, for use: &#39;WW&#39;, as &#39;tuya_bridge&#39;:  &#39;TRG&#39;'),
(5, 'Smart_Switch01', '101', 'on reset', 'int', '0|1|2 = OFF|ON|HOLD', 'ENUMONOFFHOLD', 'WW', 'The initial switch status, after a reset.', NULL),
(34, 'LED_700ml_Humidifier', '1', 'spray', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'RW', NULL, NULL),
(35, 'LED_700ml_Humidifier', '2', 'output', 'string', '\'large\'|\'small\'', NULL, 'RW', 'Defined as boolean by Tuya, it works (GET,SET) with strings.', NULL),
(37, 'LED_700ml_Humidifier', '5', 'led', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'RW', 'When SET:ON it sends itself and default colour. ( FF00000000FFFF )', 'If led OFF, the colour is 00000000000000 and cannot be changed.'),
(38, 'LED_700ml_Humidifier', '6', 'led mode', 'string', '&#39;colour&#39;|&#39;colourful1&#39;', NULL, 'RW', 'In colourful1 mode, LED changes colour, but GET gives always FF00000000FFFF', NULL),
(41, 'LED_700ml_Humidifier', '8', 'colour', 'binary', 'RRGGBBHHHHSSVV = r,g,b [0..255], Hue [0..360], SS=VV=[0..0x64] (100%) ??', 'STRUCTCOLOUR', 'RW', 'JSON: {&#34;hex&#34;:&#34;RRGGBB0000FFFF&#34;} or {&#34;r&#34;:255, &#34;g&#34;:0,&#34; b&#34;:0, &#34;h&#34;:0, &#34;s&#34;:255, &#34;v&#34;:255}. The actual encoder accepts also {&#34;r&#34;:255, &#34;g&#34;:0, &#34;b&#34;:0}. ', 'Values h, v, s have no effect!? '),
(44, 'LED_700ml_Humidifier', '3', 'timer', 'string', '&#39;1&#39;|&#39;3&#39;|&#39;6&#39;|&#39;cancel&#39;', NULL, 'RW', 'In &#34;alldevices&#34;  type:string is mandatory, so  &#39;3&#39; do not becomes 3', NULL),
(50, 'TRV_Thermostatic_Radiator_Valve', '8', 'Open windows sensitivity', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WO', 'If ON ignores fast temperature down', NULL),
(51, 'TRV_Thermostatic_Radiator_Valve', '10', 'Antifreeze', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WO', 'Autostart:  5° ON, 8 °C OFF', NULL),
(52, 'TRV_Thermostatic_Radiator_Valve', '27', 'Actual T offset', 'int', '-6..+6 °C', NULL, 'WO', 'To compensate for the error in the actual T measurements', NULL),
(53, 'TRV_Thermostatic_Radiator_Valve', '40', 'Lock', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WO', 'Child lock', NULL),
(54, 'TRV_Thermostatic_Radiator_Valve', '101', 'Device', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WO', 'general ON|OFF', NULL),
(55, 'TRV_Thermostatic_Radiator_Valve', '102', 'Temperature', 'int', '50..300 = 5.0 .. 30.0 °C', 'BYTESMALLFLOAT', 'PUSH', 'Actual T', NULL),
(56, 'TRV_Thermostatic_Radiator_Valve', '103', 'Target T', 'int', '50..300 = 5.0..30.0 °C', 'BYTESMALLFLOAT', 'WO', 'Accepts increment of 0.1 (on smartlife app only 0.5)', NULL),
(57, 'TRV_Thermostatic_Radiator_Valve', '106', 'Away mode', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WO', 'Set target T to 16 °C', NULL),
(58, 'TRV_Thermostatic_Radiator_Valve', '110', 'Hist. day target T', 'binary', 'base64(Uint8Array[24]) =  [16,16,16,16,16,16,16,20,20,20,20,20,...', 'ARRAY8INT', 'PUSH', 'PUSHed  at HH:00', NULL),
(59, 'TRV_Thermostatic_Radiator_Valve', '112', 'Hist. week target T', 'binary', 'base64(Uint8Array[7]) =  [18,18,18,18,0,0,0]', 'ARRAY8INT', 'PUSH', NULL, NULL),
(60, 'TRV_Thermostatic_Radiator_Valve', '113', 'Hist. month target T', 'binary', 'base64(Uint8Array[31]) =  [18,18,18,18,18,18,18,18,18,18,18,18,18,18,18...', 'ARRAY8INT', 'PUSH', 'PUSHed ewery 4/5 days, at 00:00', NULL),
(61, 'TRV_Thermostatic_Radiator_Valve', '114', 'Hist. year target T', 'binary', 'base64(Uint8Array[12]) =  [18,18,18,18,0,0,0,0,0,0,0,0]', 'ARRAY8INT', 'PUSH', NULL, NULL),
(62, 'TRV_Thermostatic_Radiator_Valve', '115', 'Hist. day real T', 'binary', 'base64(Uint8Array[24]) = [15,14,14,14,13,13,16,18,19,0,0,0 ....', 'ARRAY8INT', 'PUSH', 'PUSHed  at HH:00', NULL),
(63, 'TRV_Thermostatic_Radiator_Valve', '116', 'Hist. week real T', 'binary', 'base64(Uint8Array[7]) = [17,18,17,18,18,0,0]', 'ARRAY8INT', 'PUSH', NULL, NULL),
(64, 'TRV_Thermostatic_Radiator_Valve', '117', 'Hist. month real T', 'binary', 'base64(Uint8Array[31]) =  [17,16,16,16,17,16,16,17,17,17,16,16,17,...', 'ARRAY8INT', 'PUSH', 'PUSHed ewery 4/5 days, at 00:00', NULL),
(65, 'TRV_Thermostatic_Radiator_Valve', '118', 'Hist. year real T', 'binary', 'base64(Uint8Array[12]) =  [17,18,18,18,0,0,0,0,0,0,0,0]', 'ARRAY8INT', 'PUSH', NULL, NULL),
(66, 'TRV_Thermostatic_Radiator_Valve', '119', 'Hist. day % power', 'binary', 'base64(Uint8Array[24]) =  [86,100,100,100,100,95,21,30,85,100,100,63,', 'ARRAY8INT', 'PUSH', 'PUSHed  at HH:00', 'If max &#38;#60; 100: redo \'rESE\' valve match.'),
(67, 'TRV_Thermostatic_Radiator_Valve', '120', 'Hist. week % power', 'binary', 'base64(Uint8Array[7]) = [80,83,79,0,0,0,0]', 'ARRAY8INT', 'PUSH', NULL, NULL),
(68, 'TRV_Thermostatic_Radiator_Valve', '121', 'Hist. month % power', 'binary', 'base64(Uint8Array[31]) = [78,71,85,88,76,80,79,76,78,85,90,82,78,67 ...', 'ARRAY8INT', 'PUSH', 'PUSHed ewery 4/5 days, at 00:00', NULL),
(69, 'TRV_Thermostatic_Radiator_Valve', '122', 'Hist. year % power', 'binary', 'base64(Uint8Array[12]) =  [68,72,0,0,0,0,0,0,0,0,0,0]', 'ARRAY8INT', 'PUSH', NULL, NULL),
(70, 'TRV_Thermostatic_Radiator_Valve', '123', 'Monday target T', 'binary', 'base64(Uint8Array[17])  = {\"count\":4,\"changes\":[{\"time\":\"06:00\",\"temp\":16},{\"time\":\"10:00\",\"temp\":21},{\"time\":\"13:00\",\"temp\":21},{\"time\":\"23:00\",\"temp\":16}]}', 'STRUCTARGETTEMP', 'PUSH', 'PUSHed  only on variations by smartlife app.', NULL),
(71, 'TRV_Thermostatic_Radiator_Valve', '124', 'Tuesday target T', 'binary', 'base64(Uint8Array[17])  = {\"count\":4,\"changes\":[{\"time\":\"06:00\",\"temp\":16},  ...', 'STRUCTARGETTEMP', 'PUSH', 'PUSHed  only on variations by smartlife app.', NULL),
(72, 'TRV_Thermostatic_Radiator_Valve', '125', 'Friday target T', 'binary', 'base64(Uint8Array[17])  = {\"count\":4,\"changes\":[{\"time\":\"06:00\",\"temp\":16},  ...', 'STRUCTARGETTEMP', 'PUSH', 'PUSHed  only on variations by smartlife app.', NULL),
(73, 'TRV_Thermostatic_Radiator_Valve', '126', 'Thursday target T', 'binary', 'base64(Uint8Array[17])  = {\"count\":4,\"changes\":[{\"time\":\"06:00\",\"temp\":16},  ...', 'STRUCTARGETTEMP', 'PUSH', 'PUSHed  only on variations by smartlife app.', NULL),
(74, 'TRV_Thermostatic_Radiator_Valve', '127', 'Friday target T', 'binary', 'base64(Uint8Array[17])  = {\"count\":4,\"changes\":[{\"time\":\"06:00\",\"temp\":16},  ...', 'STRUCTARGETTEMP', 'PUSH', 'PUSHed  only on variations by smartlife app.', NULL),
(75, 'TRV_Thermostatic_Radiator_Valve', '128', 'Saturday target T', 'binary', 'base64(Uint8Array[17])  = {\"count\":4,\"changes\":[{\"time\":\"06:00\",\"temp\":16},  ...', 'STRUCTARGETTEMP', 'PUSH', 'PUSHed  only on variations by smartlife app.', NULL),
(76, 'TRV_Thermostatic_Radiator_Valve', '129', 'Sunday target T', 'binary', 'base64(Uint8Array[17])  = {\"count\":4,\"changes\":[{\"time\":\"06:00\",\"temp\":16},  ...', 'STRUCTARGETTEMP', 'PUSH', 'PUSHed  only on variations by smartlife app.', NULL),
(77, 'TRV_Thermostatic_Radiator_Valve', '130', 'Water scale proof', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WO', 'Forces valve moves every two weeks', NULL),
(79, 'TRV_Thermostatic_Radiator_Valve', '108', 'Day program', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WO', 'If TRUE uses the daily T schedule, otherwise the target T is fixed ', NULL),
(81, 'TRV_Thermostatic_Radiator_Valve', '105', 'unknown01', NULL, '0?', NULL, 'PUSH', 'Found value 0 at 00:00 (rare: battery?)', NULL),
(85, 'TRV_Thermostatic_Radiator_Valve', '109', 'unknown02', NULL, 'unknown', NULL, 'WO', 'Unknown behavior: if SET, data as STRUCTARGETEMP, garbage in all day programs !?', NULL),
(86, 'Door_Sensor', '1030', 'status', 'boolean', 'true|false  = ON|OFF', 'BOOLEANOPENCLOSE', 'TRG', 'Automation  \'1030doorclosed\': if status.close, tuya_bridge.countdown:1030', 'Automation  \'1040dooropen\':   if status.open, tuya_bridge.countdown:1040'),
(87, 'PIR_motion', '1010', 'alarm', 'string', '&#39;ON&#39;|&#39;OFF&#39;', NULL, 'PUSH', 'Automation &#39;1010PIRoff&#39;: if status.open, tuya_bridge.countdown:1010', 'Automation &#39;1020PIRon&#39;: if status.close, tuya_bridge.countdown:1020'),
(88, 'Alarm_siren', '104', 'alarm', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'RW', NULL, NULL),
(89, 'Alarm_siren', '102', 'type', 'string', '&#39;1&#39;..&#39;10&#39;', NULL, 'RW', NULL, NULL),
(90, 'Alarm_siren', '103', 'duration', 'int', '0..60 s', NULL, 'RW', NULL, NULL),
(101, 'Temperature_Humidity_Sensor', '101', 'humidity', NULL, NULL, NULL, 'PUSH', NULL, NULL),
(106, 'Temperature_Humidity_Sensor', '103', 'temperature', NULL, NULL, NULL, 'PUSH', NULL, NULL),
(108, 'switch-4CH', '1', 'relay1', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
(109, 'switch-4CH', '2', 'relay2', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
(110, 'switch-4CH', '3', 'relay3', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
(111, 'switch-4CH', '4', 'relay4', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
(112, 'switch-4CH', '7', 'countdown1', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Countdown >= 0: PUSHed every sec. Count to 0, or SET 0: relay toggles. ', NULL),
(113, 'switch-4CH', '8', 'countdown2', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Countdown >= 0: PUSHed every sec. Count to 0, or SET 0: relay toggles.', NULL),
(114, 'switch-4CH', '9', 'countdown3', 'int', '0..86500 s  (24H max.)', NULL, 'WW', 'Countdown >= 0: PUSHed every sec. Count to 0, or SET 0: relay toggles.', NULL),
(115, 'switch-4CH', '10', 'countdown4', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Countdown >= 0: PUSHed every sec. Count to 0, or SET 0: relay toggles.', NULL),
(116, 'switch-4CH', '13', 'switch all', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
(117, 'switch-4CH', '101', 'power-on status', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
(118, 'switch-4CH', '102', 'mode', 'string', '&#39;selflock&#39;|&#39;inching&#39;|&#39;interlock&#39;', NULL, 'WW', '&#39;inching&#39; = momentary: time is &#39;dp&#39; 103', NULL),
(119, 'switch-4CH', '103', 'momentary time', 'int', '0...600 = 0...60.0 s', 'BYTESMALLFLOAT', 'WW', NULL, NULL),
(120, 'WiFi_IP_Camera', '106', 'sensibilità movimento', 'string', '&#39;0&#39;|&#39;1&#39;|&#39;2&#39; = LO|OK|HI', 'ENUMHIGHGOODLOW', 'WO', NULL, NULL),
(121, 'WiFi_IP_Camera', '134', 'rilevazione movimento', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WO', NULL, NULL),
(122, 'WiFi_IP_Camera', '110', 'mode', 'string', '5: format, 1: replay', NULL, 'PUSH', NULL, NULL),
(123, 'WiFi_IP_Camera', '103', 'upside down', 'boolean', 'true|false ', NULL, 'WO', NULL, NULL),
(124, 'WiFi_IP_Camera', '104', 'timestamp', 'boolean', 'true|false  ', NULL, 'WO', NULL, NULL),
(125, 'WiFi_IP_Camera', '109', 'SD status', 'string', 'all|used|free  (bytes)', 'SDSPACES', 'GW', 'only GET (as SET:null), no other SET.', NULL),
(126, 'WiFi_IP_Camera', '151', 'recording', 'string', '1|2 = continuous | events', 'RECMODE', 'WO', NULL, NULL),
(127, 'WiFi_IP_Camera', '111', 'start SD format', 'int', 'any ', NULL, 'WO', 'acts as a trigger', NULL),
(128, 'WiFi_IP_Camera', '117', 'SD format progress', 'int', '0...100 (%)', NULL, 'PUSH', NULL, NULL),
(129, 'switch-1CH', '1', 'relay', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', 'Toggles when the countdown goes to 0; SET(7):0 => the switch does not change', NULL),
(130, 'switch-1CH', '7', 'countdown', 'int', '0..86500 s  (24H max.)', NULL, 'WW', 'PUSH every (30 * k) s; GET returns last PUSHed value, not the actual count', 'DPcapability for test: &#39;RW&#39;, for use: &#39;WW&#39;, as &#39;tuya_bridge&#39;: &#39;TRG&#39;'),
(131, 'switch-1CH', '15', 'light mode', 'string', '&#39;pos&#39;|&#39;none&#39;|&#39;relay&#39;', NULL, 'WW', 'no HW: can be used as trigger', NULL),
(132, 'switch-1CH', '16', 'backlight', 'boolean', 'true|false ', NULL, 'WW', 'no HW: can be used as trigger', NULL),
(135, 'switch-1CH', '19', 'inching', 'binary', '{ inching: true|false delay: 0..3660} in sec', 'STRUCTINCH', 'WW', 'The inching (temporary) counter	SET:{} to clear	', NULL),
(136, 'switch-1CH', '14', 'restart status', 'string', '&#39;off&#39;|&#39;on&#39;|&#39;memory&#39;', NULL, 'WW', 'The initial switch status, after a reset.', NULL),
(137, 'switch-1CH', '17', 'circulate', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM, end: HH:MM, on: HH:MM, off: HH:MM}', 'STRUCTREPEAT', 'WW', 'Undocumented tentative.', 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once. SET:[] to clear	'),
(138, 'switch-1CH', '18', 'random', NULL, 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM end: HH:MM}', 'STRUCTRAND', 'WW', 'Undocumented tentative.', 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once.. SET:[] to clear'),
(139, 'smart_breaker', '1', 'relay', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
(140, 'smart_breaker', '9', 'countdown', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Relay toggles when count reaches 0. SET:0  no toggle.', 'PUSHed every 30 sec.'),
(141, 'smart_breaker', '38', 'restart status', 'string', 'off|on|memory', NULL, 'WW', NULL, NULL),
(142, 'smart_breaker', '40', 'light mode', 'string', 'pos|none|relay', NULL, 'WW', 'Led BLUE: as &#39;relay&#39; = OFF/ON, &#39;pos&#39; (position) inverted = ON/OFF, &#39;none&#39; = always OFF', NULL),
(143, 'smart_breaker', '41', 'child lock', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', 'in lock mode, the manual switch does not toggle the relay.', NULL),
(144, 'smart_breaker', '44', 'inching', 'binary', ' { inching: true|false delay: 0..3660} in sec', 'STRUCTINCH', 'WW', 'The inching (temporary) counter', 'SET:{} to clear'),
(145, 'smart_breaker', '42', 'circulate', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM,  end: HH:MM, on: HH:MM, off: HH:MM}', 'STRUCTREPEAT', 'WW', 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once.', 'SET:[] to clear'),
(146, 'smart_breaker', '43', 'random', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM  end: HH:MM}', 'STRUCTRAND', 'WW', 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once.', 'SET:[] to clear'),
(148, 'Smoke_Detector', '1800', 'alarm', 'string', '&#39;ON&#39;|&#39;OFF&#39;', NULL, 'PUSH', 'smoke1800: if alarm:on, &#39;tuya_bridge&#39;countdown:1800; ', 'smoke1810: if alarm:off, &#39;tuya_bridge&#39;countdown:1810; '),
(149, 'Smoke_Detector', '1820', 'battery', 'string', '&#39;OK&#39;|&#39;LOW&#39;', NULL, 'PUSH', 'smoke1820: if battery:low, &#39;tuya_bridge&#39;countdown:1820 (+ timer: 3:00H every day)', 'smoke1830A: if battery:medium, &#39;tuya_bridge&#39;countdown:1830 (+ timer: 3:00H every day); smoke1830B: if battery:good, &#39;tuya_bridge&#39;countdown:1830 (+ timer: 3:00H every day); '),
(150, 'Smoke_Detector', '1840', 'silence', 'string', ' &#39;ON&#39;|&#39;OFF&#39;', NULL, 'WO', 'smoke1840: if silence:on, &#39;tuya_bridge&#39;countdown:1840; smoke1850: if silence:off, &#39;tuya_bridge&#39;countdown:1850 ', 'smoke5800:if &#39;tuya_bridge&#39;countdown:5800,  &#39;tuya_bridge&#39;countdown:0+&#39;smoke&#39;silence:on   smoke5810:if &#39;tuya_bridge&#39;countdown:5810,  &#39;tuya_bridge&#39;countdown:0+&#39;smoke&#39;silence:off'),
(151, 'Alarm_siren', '101', 'battery', 'enum', '0..5 ?? = AC FULL|HIGHT |MEDIUM|LOW|BAD ??', NULL, 'RO', 'under investigation', NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `deviceinfos`
--

CREATE TABLE `deviceinfos` (
  `dName` char(80) NOT NULL COMMENT 'UNIQUE device name.\r\nLimit: only the chars allowed in file names. Unhallowed chars are replaced by ''_''.',
  `model` char(80) DEFAULT NULL COMMENT 'The original model by manufacturer.',
  `picName` char(80) DEFAULT NULL COMMENT 'only name for image file, 300x300, jpeg, like\r\n''switch_ab02.jpg'', required.\r\nPredefined dir: ''./pics''\r\n',
  `tuyaType` char(80) DEFAULT NULL COMMENT 'The Tuya ''Product Type'' definition, from page: https://iot.tuya.com/cloud/appinfo/cappId/deviceList',
  `tuyaProductID` char(40) DEFAULT NULL COMMENT 'The Tuya ''Product ID'' definition, from page: https://iot.tuya.com/cloud/appinfo/cappId/deviceList.\r\n',
  `protocol` enum('WiFi','ZigBee','Bluethoot','mixed','other') DEFAULT 'WiFi' COMMENT 'Device communication protocol.\r\nDefault: WiFi',
  `power` enum('AC','BAT','USB','USB+BAT','AC+BAT','UPS') DEFAULT 'BAT' COMMENT 'Device power suppy.\r\nFor alarms: if NULL the device is not tested for alarms.',
  `capabilities` set('SET','GET','SCHEMA','MULTIPLE','NONE','ALL') DEFAULT 'ALL' COMMENT 'Global device capabilities: one or more from SET|GET|SCHEMA|MULTIPLE or ALL|NONE.\r\nDefault ALL.\r\nLimits device access.',
  `description` tinytext DEFAULT NULL COMMENT 'free descripion.\r\nOnly for documentation.',
  `note01` tinytext DEFAULT NULL COMMENT 'Free. Used in ''alldevices''.',
  `note02` tinytext DEFAULT NULL COMMENT 'Free. Used in ''alldevices''.',
  `sellerURL` tinytext DEFAULT NULL COMMENT 'References to one or more sellers.',
  `refURL` tinytext DEFAULT NULL COMMENT 'Original manufactured reference.',
  `infoURL` tinytext DEFAULT NULL COMMENT 'More technical references: user manuals, schemas, use example, etc.',
  `copynotice` char(80) NOT NULL DEFAULT '2021 marco.sillano@gmail.com'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `deviceinfos`
--

INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('Alarm_siren', 'WKD-ALM01', 'Alarm_siren.jpg', 'Others', 'DYgId0sz6zWlmmYu', 'WiFi', 'AC+BAT', 'ALL', 'WiFi Smart alarm, sound alarm at the same time flashing, dazzling red light with alarm, full of power.', NULL, NULL, 'https://www.aliexpress.com/item/1005001897410585.html', 'http://www.zsviot.com/pd.jsp?id=10', NULL, '2021 marco.sillano@gmail.com'),
('Door_Sensor', 'WKD-D01', 'Door_Sensor.jpg', 'Door/Window Controller', 'oSQljE9YDqwCwTUA', 'WiFi', 'BAT', 'NONE', 'Tuya Smart Home Door Window Contact Sensor WiFi App Notification Alerts Battery Operated', 'Mirror device: low power standby without MQTT, data PUSHed only by tuyaTRIGGER ', NULL, 'https://www.aliexpress.com/item/4001276833472.html', 'http://www.zsviot.com/pd.jsp?id=27', NULL, '2021 marco.sillano@gmail.com'),
('LED_700ml_Humidifier', '1201W', 'LED_700ml_Humidifier.jpg', 'Humidifier', 'c0nh3LmEk0NDebrq', 'WiFi', 'AC', 'ALL', 'WiFi Profession Desktop Square Mist Humidifier Led Light Humidifier Machine Diffuser Oil Humidifier', 'Any GET and SCHEMA  returns all 1,2,3,5,6,8 dp infos. User actions on buttons are sent.', 'Automatic shutdown if there is not enough water.', 'https://www.aliexpress.com/item/4000432962187.html', 'https://yymhealth.manufacturer.globalsources.com', NULL, '2021 marco.sillano@gmail.com'),
('PIR_motion', 'WDK-PR01', 'PIR_motion.jpg', 'Motion Detector', 'Okurono2XLVRV0fB', 'WiFi', 'BAT', 'NONE', 'Tuya Mini WIFI PIR Motion Sensor Human Body Sensor Wireless Infrared Detector built-in battery Hole-free installation ', 'Mirror device: low power standby without MQTT, data PUSHed only by tuyaTRIGGER	', NULL, 'https://www.aliexpress.com/item/4001000424566.html', 'http://www.zsviot.com/pd.jsp?id=48', NULL, '2021 marco.sillano@gmail.com'),
('smart_breaker', 'S3077', 'smart_breaker.jpg', 'Breaker', 'ily6yaiza2eytgnc', 'WiFi', 'AC', 'ALL', 'Good switch rich of features: circulate and random with week planning, countdown and inching.', 'Any GET sends all data (like SCHEMA), SET:null works OK, so all dp &#39;WW&#39;', NULL, 'https://www.aliexpress.com/item/1005001863612580.html', NULL, NULL, '2021 marco.sillano@gmail.com'),
('Smart_Switch01', 'MOES QS-WIFI-S03', 'Smart_Switch01.jpg', 'switch', '5vorxbbzvavwrrqs', 'WiFi', 'AC', 'SET,GET,MULTIPLE', 'Wifi Smart Light Switch, DIY Breaker Module Smart Life/Tuya APP Remote Control, Works with Alexa Echo Google Home, 1/2 Way', 'Can be used as tuya_bridge: set name &#39;tuya_bridge&#39;, dp 102 name &#39;reserved (trigger)&#39; and capability &#39;TRG&#39;', 'All dps: GET fires the &#34;json obj data unvalid&#34; warning, then sends a valid response: SET:null works better.', 'https://www.aliexpress.com/item/33012114855.html', 'https://www.moeshouse.com/collections/diy-smart-switch', 'https://lamiacasaelettrica.com/moes-interruttore-intelligente-smart-life/', '2021 marco.sillano@gmail.com'),
('Smoke_Detector', 'TYYG2', 'Smoke_Detector.jpg', 'Smoke detector', 'ljmfjahi9bbv2huq', 'WiFi', 'BAT', 'SET', 'Tuya WiFi Smoke Alarm Fire Protection Smoke Detector Smoke', 'Low power standby without MQTT. ', 'Mirror device: tuyaDAEMON uses TRIGGERs to exchange data with the real device.', 'https://www.aliexpress.com/item/4000990605711.html', 'https://ewelink.eachen.cc/product/eachen-wifi-strobe-smoke-detector-sensor-phone-call-app-push-alarm-compatible-with-tuya-smart-life/', NULL, '2021 marco.sillano@gmail.com'),
('switch-1CH', 'TYWR 7-32', 'switch-1CH.jpg', 'switch', 'hryktirnvgdua5cm', 'WiFi', 'USB', 'ALL', 'WIFI Wireless Smart Home Switch with RF433 Control', 'Any GET sends all data (like SCHEMA), SET:null works OK, so all dp &#39;WW&#39;', 'Can be used as tuya_bridge device', 'https://www.aliexpress.com/item/1005001292612142.html', NULL, 'https://developer.tuya.com/en/docs/iot/device-development/module/wifibt-dual-mode-module/wb-series-module/wb3sipex-module-datasheet', '2021 marco.sillano@gmail.com'),
('switch-4CH', NULL, 'switch-4CH.jpg', 'switch', 'waq2wj9pjadcg1qc', 'WiFi', 'USB', 'ALL', '4CH Tuya Switch WiFi Switch Module', 'Any GET sends all data (like SCHEMA), SET:null works OK, so all dp &#39;WW&#39;', 'To SET countdown to 0, toggles relay', 'https://www.aliexpress.com/item/4001268704361.html', NULL, 'https://developer.tuya.com/en/docs/iot/device-development/module/wifibt-dual-mode-module/wb-series-module/wb3sipex-module-datasheet', '2021 marco.sillano@gmail.com'),
('Temperature_Humidity_Sensor', 'WSDCGQ11LM', 'Temperature_Humidity_Sensor.jpg', 'Others', 'vtA4pDd6PLUZzXgZ', 'ZigBee', 'BAT', 'NONE', 'Monitors temperature, humidity, and atmospheric pressure in real time. No Wiring Required | Temperature and Humidity Notification | 2 Years Battery Life', 'For Mijia Homekit app. With smarthome PUSHs  temperature, humidity  20&#39;-3h interval (no pressure)', 'Works only SET with last value received (?)', 'https://www.aliexpress.com/32977883360.html', 'https://www.aqara.com/us/temperature_humidity_sensor.html', NULL, '2021 marco.sillano@gmail.com'),
('TRV_Thermostatic_Radiator_Valve', 'SEA801-ZIGBEE', 'TRV_Thermostatic_Radiator_Valve.jpg', 'Thermostat', 'c88teujp', 'ZigBee', 'BAT', 'SET', 'SEA801 TRV Programmable Controller is a stylish and accurate TRV programmable controller has been designed for independent control heating radiators.', 'Chosen for front panel, having no side space: but never needed to look panel!', 'Few SET dp, PUSH actual temperature every 20-30 min, historical data for the graphs every h.', 'https://www.aliexpress.com/item/4000805305958.html', 'https://www.saswell.com/trv-programmable-controller-sea801_p101.html', 'https://www.zigbee2mqtt.io/devices/SEA801-Zigbee_SEA802-Zigbee.html', '2021 marco.sillano@gmail.com'),
('WiFi_IP_Camera', 'WKD-IPC02', 'WiFi_IP_Camera.jpg', 'Smart camera', 'ds0dztbnkfwlnhrk', 'WiFi', 'USB', 'ALL', 'The best choice for your guard home security', NULL, NULL, NULL, 'http://www.zsviot.com/pd.jsp?id=9', NULL, '2021 marco.sillano@gmail.com');

-- --------------------------------------------------------

--
-- Struttura della tabella `lookupdecode`
--

CREATE TABLE `lookupdecode` (
  `type` char(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `lookupdecode`
--

INSERT INTO `lookupdecode` (`type`) VALUES
(''),
('ARRAY8INT'),
('BOOLEANONOFF'),
('BOOLEANOPENCLOSE'),
('BYTESMALLFLOAT'),
('ENUMHIGHGOODLOW'),
('ENUMONOFFHOLD'),
('NULL'),
('RECMODE'),
('SDSPACES'),
('STRUCTARGETTEMP'),
('STRUCTCOLOUR'),
('STRUCTINCH'),
('STRUCTRAND'),
('STRUCTREPEAT'),
('STRUCTTIMEHMS');

-- --------------------------------------------------------

--
-- Struttura della tabella `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL,
  `action` enum('TX','RX') NOT NULL DEFAULT 'RX',
  `device-id` char(30) NOT NULL,
  `device-name` char(40) NOT NULL,
  `dps` char(40) NOT NULL,
  `dp-name` char(40) NOT NULL,
  `data` tinytext DEFAULT NULL,
  `value` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struttura della tabella `odt_queries`
--

CREATE TABLE `odt_queries` (
  `ID` int(11) NOT NULL COMMENT 'key auto',
  `templateID` char(80) NOT NULL COMMENT 'template name',
  `block` char(40) DEFAULT NULL COMMENT 'only if block, name',
  `parent` char(40) DEFAULT NULL COMMENT 'only if nested block, name',
  `query` varchar(16000) NOT NULL COMMENT 'SQL query'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='fields and blocks queries definitions';

--
-- Dump dei dati per la tabella `odt_queries`
--

INSERT INTO `odt_queries` (`ID`, `templateID`, `block`, `parent`, `query`) VALUES
(1, 'deviceinfo', NULL, NULL, 'SELECT * FROM deviceinfos WHERE dName = \'#key1#\''),
(2, 'deviceinfo', NULL, NULL, 'SELECT CONCAT(\'pics/\',picname) AS \'img_device\', if( (LOWER(note01) LIKE \'%mirror%\') OR (LOWER(note02) LIKE \'%mirror%\') OR (LOWER(note01) LIKE \'%fake%\') OR (LOWER(note02) LIKE \'%fake%\'),\'User defined\',\'Known\') as \'Known\' FROM deviceinfos WHERE dName = \'#key1#\''),
(3, 'deviceinfo', 'dps', NULL, 'SELECT *, CONCAT(DPnote01, IF(ISNULL(DPnote02),\'\', CONCAT(\' \',DPnote02))) AS DPnotes FROM devicedpoints WHERE dName = \'#key1#\' ORDER BY DPnumber * 1, DPnumber');

-- --------------------------------------------------------

--
-- Struttura della tabella `odt_reports`
--

CREATE TABLE `odt_reports` (
  `ID` int(11) NOT NULL COMMENT 'index auto',
  `page` char(60) NOT NULL COMMENT 'the destination page ',
  `position` int(11) UNSIGNED NOT NULL COMMENT 'order index',
  `templateID` char(60) NOT NULL COMMENT 'the file name (.odt)',
  `show` varchar(500) DEFAULT NULL COMMENT 'php: returns true|false',
  `outmode` enum('send','save','send_save') NOT NULL DEFAULT 'send' COMMENT 'Document destination',
  `outfilepath` varchar(200) DEFAULT NULL COMMENT 'php: return file name',
  `shortName` char(250) DEFAULT NULL COMMENT 'php: return short name',
  `description` varchar(500) DEFAULT NULL COMMENT 'php: returns description (HTML)',
  `key1type` enum('hidden','HTML','list','radio','date','foreach') DEFAULT NULL COMMENT 'the key type',
  `key1name` char(60) DEFAULT NULL COMMENT 'the key name (HTML)',
  `key1value` varchar(2500) DEFAULT NULL COMMENT 'php|SELECT query',
  `key2type` enum('hidden','HTML','list','radio','date','foreach') DEFAULT NULL COMMENT 'the key type',
  `key2name` char(60) DEFAULT NULL COMMENT 'the key name (HTML)',
  `key2value` varchar(2500) DEFAULT NULL COMMENT 'php|SELECT query',
  `key3type` enum('hidden','HTML','list','radio','date') DEFAULT NULL COMMENT 'the key type',
  `key3name` char(60) DEFAULT NULL COMMENT 'the key name (HTML)',
  `key3value` varchar(2500) DEFAULT NULL COMMENT 'php|SELECT query',
  `key4type` enum('hidden','HTML','list','radio','date') DEFAULT NULL COMMENT 'the key type',
  `key4name` char(60) DEFAULT NULL COMMENT 'the key name (HTML)',
  `key4value` varchar(2500) DEFAULT NULL COMMENT 'php|SELECT query',
  `key5type` enum('hidden','HTML','list','radio','date') DEFAULT NULL COMMENT 'the key type',
  `key5name` char(60) DEFAULT NULL COMMENT 'php|SELECT query',
  `key5value` varchar(2500) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Definizione reports';

--
-- Dump dei dati per la tabella `odt_reports`
--

INSERT INTO `odt_reports` (`ID`, `page`, `position`, `templateID`, `show`, `outmode`, `outfilepath`, `shortName`, `description`, `key1type`, `key1name`, `key1value`, `key2type`, `key2name`, `key2value`, `key3type`, `key3name`, `key3value`, `key4type`, `key4name`, `key4value`, `key5type`, `key5name`, `key5value`) VALUES
(3, 'index_page', 1, 'deviceinfo', 'return true;', 'save', '\r\n\r\nreturn \"$baseDir/devicedata/device_$key1.odt\";', 'return \'device documentation\';', 'return \'An information page about the Tuya device. Use OpenOffice4 to export it as .pdf.\';', 'list', 'Tuya device', 'SELECT dName, dName FROM deviceinfos', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `devicedpoints`
--
ALTER TABLE `devicedpoints`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dName_2` (`dName`,`DPnumber`),
  ADD KEY `dataformat` (`DPdecode`),
  ADD KEY `dName` (`dName`) USING BTREE;

--
-- Indici per le tabelle `deviceinfos`
--
ALTER TABLE `deviceinfos`
  ADD PRIMARY KEY (`dName`);

--
-- Indici per le tabelle `lookupdecode`
--
ALTER TABLE `lookupdecode`
  ADD PRIMARY KEY (`type`) USING BTREE;

--
-- Indici per le tabelle `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `timestamp` (`timestamp`,`device-id`,`dps`) USING BTREE;

--
-- Indici per le tabelle `odt_queries`
--
ALTER TABLE `odt_queries`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `templateID` (`templateID`),
  ADD KEY `block` (`block`);

--
-- Indici per le tabelle `odt_reports`
--
ALTER TABLE `odt_reports`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `templateID` (`templateID`),
  ADD UNIQUE KEY `page` (`page`,`position`) USING BTREE;

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `devicedpoints`
--
ALTER TABLE `devicedpoints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto index', AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT per la tabella `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `odt_queries`
--
ALTER TABLE `odt_queries`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'key auto', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `odt_reports`
--
ALTER TABLE `odt_reports`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'index auto', AUTO_INCREMENT=4;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `devicedpoints`
--
ALTER TABLE `devicedpoints`
  ADD CONSTRAINT `dataformat` FOREIGN KEY (`DPdecode`) REFERENCES `lookupdecode` (`type`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `datapointof` FOREIGN KEY (`dName`) REFERENCES `deviceinfos` (`dName`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
