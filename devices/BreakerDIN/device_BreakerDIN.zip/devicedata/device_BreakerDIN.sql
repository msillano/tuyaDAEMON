INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('BreakerDIN', 'OPWTY-63', 'BreakerDIN.jpg', NULL, NULL, 'WiFi', 'AC', 'REFRESH,ALL', 'DIN Breaker w  Earth Leakage Over Under Voltage Protector Energy Power kW', 'Good for home as main AC switch', 'Any GET acts as SCHEMA.', 'https://www.aliexpress.com/item/1005002361164427.html', 'https://developer.tuya.com/en/docs/iot/smart_meter(requires+account)', 'OPWTY-63', '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'BreakerDIN', '1', 'total_ene', 'number', '0..99999999  kWh *100', 'INTE2FLOAT', 'PUSH', 'total (forward) enegy:  neutral direction.', NULL),
 ('', 'BreakerDIN', '6', 'phaseA', 'binary', 'struct: { V, Leack, A, W}', 'STRUCTELERT', 'PUSH', NULL, NULL),
 ('', 'BreakerDIN', '7', 'phaseB', 'binary', NULL, NULL, 'PUSH', 'three-phase current, not used', NULL),
 ('', 'BreakerDIN', '8', 'phaseC', 'binary', NULL, NULL, 'PUSH', 'three-phase current, not used', NULL),
 ('', 'BreakerDIN', '9', 'fault value?', 'int', '0..??', NULL, 'WW', 'see https://developer.tuya.com/en/docs/iot/smart_meter (require access) for alarm list', 'PUSHed, WRITE 0 to clear'),
 ('', 'BreakerDIN', '11', 'prepayment', 'boolean', 'true, false', NULL, 'WW', NULL, NULL),
 ('', 'BreakerDIN', '12', 'clear energy', 'boolean', 'true, false', NULL, 'WW', 'clear total energy counter (not balance)', NULL),
 ('', 'BreakerDIN', '13', 'balance_ene', 'number', '0..99999999 kWh * 100', 'INTE2FLOAT', 'GW', 'energy balance (prepayment mode)', NULL),
 ('', 'BreakerDIN', '14', 'charge_ene', 'number', '0..999999 kWh * 100', 'INTE2FLOAT', 'WW', 'Add payed energy to balance (prepayment mode)', NULL),
 ('', 'BreakerDIN', '16', 'switch', 'boolean', 'true|false =ON|OFF', 'BOOLEANONOFF', 'WW', 'Power switch', NULL),
 ('', 'BreakerDIN', '19', 'Breaker_ID', 'string', 'e.g. &#39;FSE-F723C51D7A727B&#39;', NULL, 'GW', 'Unique HW ID', NULL),
 ('', 'BreakerDIN', '101', 'overvoltage', 'int', '250..300 V', NULL, 'WW', 'Get/Set limit value', NULL),
 ('', 'BreakerDIN', '102', 'undervoltage', 'int', '160..190 V', NULL, 'WW', 'Get/Set limit value', NULL),
 ('', 'BreakerDIN', '103', 'overcurrent', 'int', '1..63 A', NULL, 'WW', 'Get/Set limit value', NULL),
 ('', 'BreakerDIN', '104', 'leakage', 'int', '10..100 mA', NULL, 'WW', 'Get/Set limit value', NULL),
 ('', 'BreakerDIN', '105', 'mute mode', 'boolean', 'true, false', NULL, 'WW', NULL, NULL),
 ('', 'BreakerDIN', '106', 'trip mode', 'boolean', 'true, false', NULL, 'WW', NULL, NULL);