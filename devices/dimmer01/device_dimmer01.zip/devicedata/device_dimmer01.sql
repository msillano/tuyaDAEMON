INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('dimmer01', 'KS-D01W', 'dimmer01.png', NULL, NULL, 'WiFi', 'AC', 'SET,GET,SCHEMA', '1 switch ON-OFF + 2 buttons: UP/DOWN, with fade-in, fade-out', 'Keygma  smart dimmer, optimized for light management', '100-250 VAC, 600 W (resistive load)', 'https://it.aliexpress.com/item/1005004453423603.html', 'http://www.keygma.com/en/zhinengdiaoguangqi/162.html', NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'dimmer01', '1', 'switch', 'boolean', 'true, false', 'BOOLEANONOFF', 'RW', NULL, NULL),
 ('', 'dimmer01', '2', 'brightness', NULL, '0..1000', NULL, 'RW', 'values outside the min/Max limits are replaced by the limit', NULL),
 ('', 'dimmer01', '3', 'min-brightness', NULL, '0..1000', NULL, 'RW', 'if necessary, the brightness is also updated', NULL),
 ('', 'dimmer01', '4', 'light type', 'string', 'led|incandescent|halogen', NULL, 'RW', 'min/Max brightness are stored per type: changing type also changes min/Max', NULL),
 ('', 'dimmer01', '5', 'max-brightness', NULL, '0..1000', NULL, 'RW', 'if necessary, the brightness is also updated', NULL),
 ('', 'dimmer01', '6', 'countdown', NULL, '0..86500s (24H)', NULL, 'RW', 'Relay toggles when count reaches 0. SET:0 no toggle.', 'PUSHed every 30s'),
 ('', 'dimmer01', '14', 'power-on', 'string', 'on|off|memory', NULL, 'RW', NULL, NULL);