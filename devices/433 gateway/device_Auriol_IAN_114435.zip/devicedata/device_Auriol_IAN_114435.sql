INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('Auriol_IAN_114435', 'H13716b, H13716c', 'Auriol_IAN_114435.jpg', 'custom', '433 MHz devices', 'other', 'BAT', 'NONE', 'Two ensambles:H13726b (temperature, humidity + wind); H13726c (rain)', 'RTL_433 protocol is #16: AlectoV1-Temperature, AlectoV1-Wind, AlectoV1-Rain.', '433 MHz gateway decodes three data packets: random ID every batteries change', 'https://fandilidl.it/volantino/2019.01.21.caldo.inverno/17080,Stazione-meteorologica', NULL, 'H13716b, H13716c', '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'Auriol_IAN_114435', '_battery_low', NULL, NULL, 'WIND|RAIN|TEMPERATURE', NULL, 'PUSH', 'WIND never sent: only TX off.', NULL),
 ('', 'Auriol_IAN_114435', '_day', NULL, NULL, NULL, NULL, 'PUSH', 'The meteorological day-of-year.', 'The rollover time is user defined (default 09:00:00) '),
 ('', 'Auriol_IAN_114435', '_dew_point', NULL, NULL, '°C', NULL, 'PUSH', 'calculated by device driver', NULL),
 ('', 'Auriol_IAN_114435', '_heat_index', NULL, NULL, '°C', NULL, 'PUSH', 'calculated by device driver', NULL),
 ('', 'Auriol_IAN_114435', '_humidity', NULL, NULL, '%', NULL, 'PUSH', 'from probe H13726B', NULL),
 ('', 'Auriol_IAN_114435', '_rain_day_mm', NULL, NULL, NULL, NULL, 'PUSH', 'calculated by device driver', 'reset every day at rollower time'),
 ('', 'Auriol_IAN_114435', '_rain_tot_mm', NULL, NULL, NULL, NULL, 'PUSH', 'from probe H13726C, every 40s', 'cumulate, reset changing batteries'),
 ('', 'Auriol_IAN_114435', '_temperature', NULL, NULL, NULL, NULL, 'PUSH', 'from probe H13726B, every 3 min.', NULL),
 ('', 'Auriol_IAN_114435', '_wind_avg_m_s', NULL, NULL, NULL, NULL, 'PUSH', 'from probe H13726B every 50-120 s.', 'last 2 min avg'),
 ('', 'Auriol_IAN_114435', '_wind_chill', NULL, NULL, '°C', NULL, 'PUSH', 'calculated by device driver', NULL),
 ('', 'Auriol_IAN_114435', '_wind_daymax_m_s', NULL, NULL, NULL, NULL, 'PUSH', 'calculated by device driver', 'reset every day at rollower time'),
 ('', 'Auriol_IAN_114435', '_wind_dir_deg', NULL, NULL, NULL, NULL, 'PUSH', 'from probe H13726B, every 40 s.', 'Battery replacement requires calibration: see wiki'),
 ('', 'Auriol_IAN_114435', '_wind_max_m_s', NULL, NULL, NULL, NULL, 'PUSH', 'from probe H13726B', 'max in last 10 min');