INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('Soil_probeZB', 'QT-07S', 'Soil_probeZB.png', 'zwjcg', NULL, 'ZigBee', 'BAT', 'SET,GET,SCHEMA', 'Wireless Soil Temperature and humidity sensor', '2xAA Batteries, 6 months life', 'GET like SCHEMA', 'https://it.aliexpress.com/item/1005005861668556.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'Soil_probeZB', '3', 'humidity', NULL, '0..100 (%)', NULL, 'RO', NULL, NULL),
 ('', 'Soil_probeZB', '5', 'temperature', NULL, NULL, NULL, 'RO', NULL, NULL),
 ('', 'Soil_probeZB', '9', 'unit', NULL, '&#39;c&#39;|&#39;f&#39;', NULL, 'RW', 'hit for UI temperature.', NULL),
 ('', 'Soil_probeZB', '14', 'batt_level', NULL, '&#39;low&#39;|&#39;middle&#39;|&#39;hight&#39;', NULL, 'RO', NULL, NULL),
 ('', 'Soil_probeZB', '15', 'batt_charge', NULL, '0..100 (%)', NULL, 'RO', 'Battery SOC (%)', NULL);