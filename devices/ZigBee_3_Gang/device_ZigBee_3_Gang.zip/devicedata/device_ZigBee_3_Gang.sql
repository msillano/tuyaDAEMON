INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('ZigBee_3_Gang', 'LoraTap SS600ZB', 'ZigBee_3_Gang.jpg', 'Wireless Switch', 'bi6lpsew', 'ZigBee', 'BAT', 'SET', '3 buttons remote control', NULL, NULL, 'https://www.aliexpress.com/item/1005001512559760.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'ZigBee_3_Gang', '1', 'button1', NULL, 'single_click|double_click|long_press', NULL, 'SKIP', 'long_press without feedback.', 'SET simulates click'),
 ('', 'ZigBee_3_Gang', '2', 'button2', NULL, 'single_click|double_click|long_press', NULL, 'SKIP', 'long_press without feedback.', 'SET simulates click'),
 ('', 'ZigBee_3_Gang', '3', 'button3', NULL, 'single_click|double_click|long_press', NULL, 'SKIP', 'long_press without feedback.', 'SET simulates click'),
 ('', 'ZigBee_3_Gang', '10', 'battery', NULL, '0..100 (%)', NULL, 'PUSH', NULL, NULL);