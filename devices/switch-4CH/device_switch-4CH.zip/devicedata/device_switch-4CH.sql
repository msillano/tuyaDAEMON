INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('switch-4CH', NULL, 'switch-4CH.jpg', 'switch', 'waq2wj9pjadcg1qc', 'WiFi', 'USB', 'ALL', '4CH Tuya Switch WiFi Switch Module', 'Any GET sends all data (like SCHEMA), SET:null works OK, so all dp &#39;WW&#39;', 'To SET countdown to 0, toggles relay', 'https://www.aliexpress.com/item/4001268704361.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'switch-4CH', '1', 'relay1', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'switch-4CH', '2', 'relay2', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'switch-4CH', '3', 'relay3', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'switch-4CH', '4', 'relay4', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'switch-4CH', '7', 'countdown1', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Countdown >= 0: PUSHed every sec. Count to 0, or SET 0: relay toggles. ', NULL),
 ('', 'switch-4CH', '8', 'countdown2', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Countdown >= 0: PUSHed every sec. Count to 0, or SET 0: relay toggles.', NULL),
 ('', 'switch-4CH', '9', 'countdown3', 'int', '0..86500 s  (24H max.)', NULL, 'WW', 'Countdown >= 0: PUSHed every sec. Count to 0, or SET 0: relay toggles.', NULL),
 ('', 'switch-4CH', '10', 'countdown4', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Countdown >= 0: PUSHed every sec. Count to 0, or SET 0: relay toggles.', NULL),
 ('', 'switch-4CH', '13', 'switch all', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'switch-4CH', '101', 'power-on status', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'switch-4CH', '102', 'mode', 'string', '&#39;selflock&#39;|&#39;inching&#39;|&#39;interlock&#39;', NULL, 'WW', '&#39;inching&#39; = momentary: time is &#39;dp&#39; 103', NULL),
 ('', 'switch-4CH', '103', 'momentary time', 'int', '0...600 = 0...60.0 s', 'BYTESMALLFLOAT', 'WW', NULL, NULL);