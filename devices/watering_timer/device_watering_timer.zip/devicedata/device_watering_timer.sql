INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('watering_timer', 'QT06', 'watering_timer.png', 'ggp', NULL, 'ZigBee', 'BAT', 'ALL', 'Intelligent Watering Timer', 'Historical measurements in liters and duration', NULL, 'https://it.aliexpress.com/item/1005004222098040.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'watering_timer', '1', 'Switch', 'boolean', NULL, NULL, 'RW', 'mode: time (false) | liters (true)', NULL),
 ('', 'watering_timer', '2', 'Start', 'boolean', NULL, NULL, 'RW', NULL, NULL),
 ('', 'watering_timer', '101', 'Last irrigation time', 'string', 'like &#39;12:52:53&#39;', NULL, 'RO', NULL, NULL),
 ('', 'watering_timer', '102', 'Next irrigation time', 'string', 'like &#39;12:52:53&#39;', NULL, 'RO', 'unknown ?', NULL),
 ('', 'watering_timer', '103', 'Number of times', NULL, NULL, NULL, 'RW', NULL, NULL),
 ('', 'watering_timer', '104', 'Duration', 'int', NULL, NULL, 'RW', 'single cycle, time (seconds) or liters', NULL),
 ('', 'watering_timer', '105', 'Irrigation interval', 'int', NULL, NULL, 'RW', 'interval [s] between cycles (103)', NULL),
 ('', 'watering_timer', '106', 'Temperature', NULL, NULL, NULL, 'RW', 'unknown', NULL),
 ('', 'watering_timer', '107', 'Smart weather', 'string', 'cloudy|rainy|snowy (24|48|72 h)', NULL, 'RW', 'delay in rainy and snowy days', NULL),
 ('', 'watering_timer', '108', 'Battery charge', NULL, '0..100 (%)', NULL, 'RO', NULL, NULL),
 ('', 'watering_timer', '109', 'Cyclic irrigation parameters', NULL, NULL, 'STRUCTREPEAT', 'RW', 'unknown', NULL),
 ('', 'watering_timer', '110', 'Cumulative duration', NULL, NULL, NULL, 'RW', 'seconds', NULL),
 ('', 'watering_timer', '111', 'Cumulative volume', NULL, NULL, NULL, 'RW', 'liters', NULL),
 ('', 'watering_timer', '112', 'Other extensions', NULL, NULL, NULL, 'RW', 'unknown', NULL),
 ('', 'watering_timer', '113', 'Timing function ?', NULL, NULL, NULL, 'RW', 'unknown, no GET', NULL),
 ('', 'watering_timer', '114', 'Statistical function', NULL, 'like &#39;00:03:05,0&#39;', NULL, 'RO', NULL, NULL),
 ('', 'watering_timer', '115', 'Time zone', NULL, NULL, NULL, 'WO', 'from phone, like &#39;Europe/Rome&#39;', NULL);