INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('soil_flora', ' HC010-2', 'mi_flora.jpg', 'zwjcy', NULL, 'Bluethoot', 'BAT', 'ALL', 'HHCC flora meter: temperature, humidity, EC, light (Tuya version - pink)', 'tuyapi captures only controls, not data: use triggers', 'problems with SmartLife, no measures ', 'https://www.aliexpress.com/item/1005004254429745.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'soil_flora', '3', 'Humidity', NULL, '0..100 [%]', NULL, 'RO', NULL, NULL),
 ('', 'soil_flora', '5', 'Temperature(C)', NULL, '0..100.0  [°C]', NULL, 'RO', NULL, NULL),
 ('', 'soil_flora', '6', 'Sunlight(LUX)', NULL, '0..200000', NULL, 'RO', NULL, NULL),
 ('', 'soil_flora', '9', 'Temp unit convert', NULL, '&#39;f&#39;|&#39;c&#39;', NULL, 'RW', 'Temperature unit', NULL),
 ('', 'soil_flora', '15', 'Battery level', NULL, '0..210 [%]', NULL, 'RO', NULL, NULL),
 ('', 'soil_flora', '101', 'EC', NULL, NULL, NULL, 'RO', NULL, NULL),
 ('', 'soil_flora', '102', 'Curve switching', 'int', NULL, NULL, 'RW', NULL, NULL),
 ('', 'soil_flora', '103', 'Temperature(F)', NULL, NULL, NULL, 'RO', NULL, NULL),
 ('', 'soil_flora', '104', 'find device', NULL, '10', NULL, 'RW', 'unknown', NULL),
 ('', 'soil_flora', '105', 'Sunlight(PAR)', NULL, NULL, NULL, 'RO', NULL, NULL),
 ('', 'soil_flora', '106', 'Light unit convert', NULL, '&#39;LUX&#39;|&#39;PAR&#39;', NULL, 'RW', 'luminance unit', NULL),
 ('', 'soil_flora', '107', 'Synchronize historical data', 'int', NULL, NULL, 'RO', NULL, NULL),
 ('', 'soil_flora', '108', 'Change Control', NULL, '&#39;on&#39;|&#39;off&#39;', NULL, 'RW', NULL, NULL);