INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('ACmeter', 'DDS238-2 WIFI', 'ACmeter.jpg', 'Socket', 'sw9asyjj8j44frjl', 'WiFi', 'AC', 'SET,GET,SCHEMA,REFRESH', 'Single Phase 65A Din Rail WIFI Smart Energy Meter', 'Sends total Energy, R.M.S current , voltage , active power', 'Real-time display of Voltage, Current, Active Power, reactive Power, power factor ,frequence, total Energy kWh', 'https://www.aliexpress.com/item/4000530641386.html', 'https://m.made-in-china.com/product/Dds238-2-WiFi-Single-Phase-DIN-Rail-Type-WiFi-Remote-Control-Energy-Meter-790065132.html', NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'ACmeter', '1', 'switch', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, 'GET acts like SCHEMA'),
 ('', 'ACmeter', '9', 'countdown', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Switch toggles when count reaches 0. SET:0  no toggle. Push every 1s.', 'GET acts like SCHEMA'),
 ('', 'ACmeter', '18', 'current', 'int', 'mA', NULL, 'PUSH', NULL, NULL),
 ('', 'ACmeter', '19', 'power', 'int', 'W * 10', NULL, 'PUSH', NULL, NULL),
 ('', 'ACmeter', '20', 'voltage', 'int', 'V*10', NULL, 'PUSH', NULL, NULL),
 ('', 'ACmeter', '101', 'Energy', 'int', 'KWh *100', NULL, 'PUSH', 'This is a cumulative counter, it cannot be reset.', NULL);