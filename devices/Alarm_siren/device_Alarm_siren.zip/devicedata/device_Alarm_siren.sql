INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('Alarm_siren', 'WKD-ALM01', 'Alarm_siren.jpg', 'Others', 'DYgId0sz6zWlmmYu', 'WiFi', 'AC+BAT', 'ALL', 'WiFi Smart alarm, sound alarm at the same time flashing, dazzling red light with alarm, full of power.', NULL, NULL, 'https://www.aliexpress.com/item/1005001897410585.html', 'http://www.zsviot.com/pd.jsp?id=10', NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'Alarm_siren', '101', 'battery', 'enum', '0..5 ?? = AC FULL|HIGHT |MEDIUM|LOW|BAD ??', NULL, 'RO', 'under investigation', NULL),
 ('', 'Alarm_siren', '102', 'type', 'string', '&#39;1&#39;..&#39;10&#39;', NULL, 'RW', NULL, NULL),
 ('', 'Alarm_siren', '103', 'duration', 'int', '0..60 s', NULL, 'RW', NULL, NULL),
 ('', 'Alarm_siren', '104', 'alarm', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'RW', NULL, NULL);