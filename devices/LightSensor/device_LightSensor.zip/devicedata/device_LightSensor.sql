INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('LightSensor', NULL, 'light-sensor.png', NULL, NULL, 'WiFi', 'USB', 'SET,GET,SCHEMA', 'Interior Light meter 0-1000 LUX', 'All GETs like SCHEMA ', NULL, 'https://it.aliexpress.com/item/4001287340039.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'LightSensor', '6', 'state', 'string', 'high|middle|low  (1000-130-60-0 lux)', NULL, 'RO', NULL, NULL),
 ('', 'LightSensor', '7', 'lux', 'int', '0-1000 [lux]', NULL, 'RO', 'sent at any change', NULL),
 ('', 'LightSensor', '101', 'findme', 'boolean', 'true|false', NULL, 'RW', 'LED blinking', NULL);