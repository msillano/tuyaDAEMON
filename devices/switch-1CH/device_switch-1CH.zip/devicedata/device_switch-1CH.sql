INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('switch-1CH', NULL, 'switch-1CH.jpg', 'switch', 'hryktirnvgdua5cm', 'WiFi', 'USB', 'ALL', 'WIFI Wireless Smart Home Switch with RF433 Control', 'Any GET sends all data (like SCHEMA), SET:null works OK, so all dp &#39;WW&#39;', 'Can be used as tuya_bridge device', 'https://www.aliexpress.com/item/1005001292612142.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'switch-1CH', '1', 'relay', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', 'Toggles when the countdown goes to 0; SET(7):0 => the switch does not change', NULL),
 ('', 'switch-1CH', '7', 'countdown', 'int', '0..86500 s  (24H max.)', NULL, 'WW', 'PUSH every (30 * k) s; GET returns last PUSHed value, not the actual count', 'DPcapability for test: &#39;RW&#39;, for use: &#39;WW&#39;, as &#39;tuya_bridge&#39;: &#39;TRG&#39;'),
 ('', 'switch-1CH', '14', 'restart status', 'string', 'off|on|memory', NULL, 'WW', 'The initial switch status, after a reset.', NULL),
 ('', 'switch-1CH', '15', 'light mode', 'string', 'pos|none|relay', NULL, 'WW', 'no HW: can be used as trigger', NULL),
 ('', 'switch-1CH', '16', 'backlight', 'boolean', 'true|false ', NULL, 'WW', 'no HW: can be used as trigger', NULL),
 ('', 'switch-1CH', '17', 'unknown2', NULL, NULL, NULL, 'WW', 'on SCHEMA response, null string', NULL),
 ('', 'switch-1CH', '18', 'unknown3', NULL, NULL, NULL, 'WW', 'on SCHEMA response, null string', NULL),
 ('', 'switch-1CH', '19', 'inching', 'string', 'AQAC|AAAC =  ON|OFF ?', NULL, 'WW', 'The inching (temporary) counter is SW, in the tuya-cloud', 'Don&#39;t use it');