INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('WiFi_IP_Camera', 'WKD-IPC02', 'WiFi_IP_Camera.jpg', 'Smart camera', 'ds0dztbnkfwlnhrk', 'WiFi', 'USB', 'ALL', 'The best choice for your guard home security', NULL, NULL, NULL, 'http://www.zsviot.com/pd.jsp?id=9', NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'WiFi_IP_Camera', '103', 'upside down', 'boolean', 'true|false ', NULL, 'WO', NULL, NULL),
 ('', 'WiFi_IP_Camera', '104', 'timestamp', 'boolean', 'true|false  ', NULL, 'WO', NULL, NULL),
 ('', 'WiFi_IP_Camera', '106', 'sensibilità movimento', 'string', '&#39;0&#39;|&#39;1&#39;|&#39;2&#39; = LO|OK|HI', 'ENUMHIGHGOODLOW', 'WO', NULL, NULL),
 ('', 'WiFi_IP_Camera', '109', 'SD status', 'string', 'all|used|free  (bytes)', 'SDSPACES', 'GW', 'only GET (as SET:null), no other SET.', NULL),
 ('', 'WiFi_IP_Camera', '110', 'mode', 'string', '5: format, 1: replay', NULL, 'PUSH', NULL, NULL),
 ('', 'WiFi_IP_Camera', '111', 'start SD format', 'int', 'any ', NULL, 'WO', 'acts as a trigger', NULL),
 ('', 'WiFi_IP_Camera', '117', 'SD format progress', 'int', '0...100 (%)', NULL, 'PUSH', NULL, NULL),
 ('', 'WiFi_IP_Camera', '134', 'rilevazione movimento', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WO', NULL, NULL),
 ('', 'WiFi_IP_Camera', '151', 'recording', 'string', '1|2 = continuous | events', 'RECMODE', 'WO', NULL, NULL);