INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('Smart_socket', 'EU 20A', 'Smart_socket.jpg', 'cz', 'AUBESS Smart Socket EU 20A', 'WiFi', 'AC', 'SET,GET,SCHEMA', 'Wifi Remote Power Socket With Energy Monitoring (V, I, W)', 'Power is always positive', 'Timer, Today Ele (kWh) and Total Ele (kWh) are not availables (Cloud functions).', 'https://it.aliexpress.com/item/1005003640472196.html', NULL, 'EU 20A', '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'Smart_socket', '1', 'switch_1', 'boolean', 'true|false =ON|OFF', 'BOOLEANONOFF', 'WW', 'GET acts like SCHEMA	', NULL),
 ('', 'Smart_socket', '9', 'countdown', 'int', '0-86400 s (24 h)', NULL, 'WW', 'Switch toggles when count reaches 0.', 'GET acts like SCHEMA'),
 ('', 'Smart_socket', '18', 'cur_current', 'int', '0-30000 mA', NULL, 'GW', 'PUSH time variable', 'GET acts like SCHEMA'),
 ('', 'Smart_socket', '19', 'cur_powe', 'int', '0-5000 W*10', 'BYTESMALLFLOAT', 'GW', 'PUSH time variable', 'GET acts like SCHEMA'),
 ('', 'Smart_socket', '20', 'cur_voltage', 'int', '0-5000 V*10', 'BYTESMALLFLOAT', 'GW', 'PUSH time variable', 'GET acts like SCHEMA'),
 ('', 'Smart_socket', '21', 'test flag', 'int', '0..5', NULL, 'WW', 'constant 1 ?', 'GET acts like SCHEMA'),
 ('', 'Smart_socket', '22', 'voltage coefficent', 'int', '0..1000000', NULL, 'WW', 'constant 555?', 'GET acts like SCHEMA'),
 ('', 'Smart_socket', '23', 'current coefficent', 'int', '0..1000000', NULL, 'WW', 'constant 26447 ?', 'GET acts like SCHEMA'),
 ('', 'Smart_socket', '24', 'power coefficient', 'int', '0..1000000', NULL, 'WW', 'constant 1446 ?', 'GET acts like SCHEMA'),
 ('', 'Smart_socket', '25', 'statistic coefficient', 'int', '0..1000000', NULL, 'WW', 'constant 1444 ?', 'GET acts like SCHEMA');