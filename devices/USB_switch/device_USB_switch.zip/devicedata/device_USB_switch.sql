INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('USB_switch', NULL, 'USB_switch.png', 'tdq', 'flcvzjtnkhsreazp', 'WiFi', 'USB', NULL, 'USB Smart Adapter: Micro USB Switch 5-12V WiFi', NULL, NULL, 'https://it.aliexpress.com/item/1005005875950948.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'USB_switch', '1', 'switch_1', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'RW', NULL, NULL),
 ('', 'USB_switch', '9', 'countdown_1', 'int', '0..86500s (24H)', NULL, 'RW', ' switch toggles at count = 0', NULL),
 ('', 'USB_switch', '24', 'test_bit', NULL, '0 ?', NULL, 'UNK', 'unknown ?', NULL),
 ('', 'USB_switch', '38', 'relay_status', 'string', '&#39;power_off&#39;|&#39;power_on&#39;|&#39;last&#39;', NULL, 'RW', 'The initial switch status, after a reset', NULL),
 ('', 'USB_switch', '42', 'random_time', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM end: HH:MM} ', 'STRUCTRAND', 'RW', NULL, 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once. SET:[] to clear'),
 ('', 'USB_switch', '43', 'cycle_time', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM, end: HH:MM, on: HH:MM, off: HH:MM} ', 'STRUCTREPEAT', 'RW', NULL, 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once. SET:[] to clear');