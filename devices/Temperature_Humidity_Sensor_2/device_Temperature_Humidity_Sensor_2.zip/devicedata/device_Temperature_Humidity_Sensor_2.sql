INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('Temperature_Humidity_Sensor_2', '温湿度传感器 (Temperature and humidity sensor) by haozee', 'Temperature_Humidity_Sensor_2.jpg', 'qt', NULL, 'ZigBee', 'BAT', 'GET,SCHEMA', 'Tuya Smart ZigBee Temperature And Humidity Sensor Indoor', 'Smpling rates: 1 / 120 min.', NULL, 'https://www.aliexpress.com/item/1005003718187629.html', 'https://manuals.plus/zh-CN/haozee/haozee-zigbee-temperature-and-humidity-sensor', NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'Temperature_Humidity_Sensor_2', '1', 'temperatrure', NULL, NULL, 'BYTESMALLFLOAT', 'PUSH', NULL, NULL),
 ('', 'Temperature_Humidity_Sensor_2', '2', 'humidity', NULL, NULL, 'BYTESMALLFLOAT', 'PUSH', NULL, NULL),
 ('', 'Temperature_Humidity_Sensor_2', '4', 'battery', NULL, NULL, NULL, 'PUSH', NULL, NULL);