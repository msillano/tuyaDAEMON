INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('Wifi_Plug', 'LU-LSPA8-IT', 'Wifi_Plug.jpg', 'Socket', 'j0zozzoarutv0nu1', 'WiFi', 'AC', 'REFRESH,ALL', 'Smart Plug WiFi Socket + power energy meter', 'any GET acts like SCHEMA', 'REFRESH sends only changed DPs', 'https://www.aliexpress.com/item/1005001845795494.html', 'http://www.qdlucent.com/content/?604.html', 'LU-LSPA8-IT', '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'Wifi_Plug', '1', 'switch', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'Wifi_Plug', '9', 'countdown', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Switch toggles when count reaches 0. SET:0  no toggle. ', 'PUSHed every 30*K sec., '),
 ('', 'Wifi_Plug', '17', 'unknown17', NULL, NULL, NULL, 'WW', 'constant 3 ?', NULL),
 ('', 'Wifi_Plug', '18', 'current', 'int', 'mA', NULL, 'GW', NULL, NULL),
 ('', 'Wifi_Plug', '19', 'power', 'int', 'W * 10', 'BYTESMALLFLOAT', 'GW', NULL, NULL),
 ('', 'Wifi_Plug', '20', 'voltage', 'int', 'V*10', 'BYTESMALLFLOAT', 'GW', NULL, NULL),
 ('', 'Wifi_Plug', '21', 'test flag', NULL, '0..5', NULL, 'WW', 'constant 1 ?', 'unknown'),
 ('', 'Wifi_Plug', '22', 'voltage coefficient', NULL, '0-1&#39;000&#39;000', NULL, 'WW', 'constant 627 ?', 'unknown'),
 ('', 'Wifi_Plug', '23', 'current coefficient', NULL, '0-1&#39;000&#39;000', NULL, 'WW', 'constant 29228 ?', 'unknown'),
 ('', 'Wifi_Plug', '24', 'power coefficient', NULL, '0-1&#39;000&#39;000', NULL, 'WW', 'constant 17033 ?', 'unknown'),
 ('', 'Wifi_Plug', '25', 'statistics coefficient', NULL, '0-1&#39;000&#39;000', NULL, 'WW', 'constant 2460 ?', 'unknown'),
 ('', 'Wifi_Plug', '26', 'warning', 'string', 'fault ?', NULL, 'GW', 'constant 0 ?', 'unknown'),
 ('', 'Wifi_Plug', '38', 'on reset', 'string', '&#39;off&#39;|&#39;on&#39;|&#39;memory&#39;', NULL, 'WW', 'The initial switch status, after a reset.', NULL),
 ('', 'Wifi_Plug', '41', 'circulate', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM, end: HH:MM, on: HH:MM, off: HH:MM}', 'STRUCTREPEAT', 'WW', 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once.', 'SET:[] to clear'),
 ('', 'Wifi_Plug', '42', 'random', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM end: HH:MM}', 'STRUCTRAND', 'WW', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM end: HH:MM}', 'SET:[] to clear'),
 ('', 'Wifi_Plug', '46', 'owercharge', 'boolean', 'true|false = ON|OFF', 'BOOLEANONOFF', 'WW', '16A  protection', NULL);