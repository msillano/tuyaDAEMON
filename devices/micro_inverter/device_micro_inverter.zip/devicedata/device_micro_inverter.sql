INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('micro_inverter', 'SG300MS', 'micro_inverter.jpg', NULL, NULL, 'WiFi', 'AC', 'GET,SCHEMA', 'Smart solar inverter max 300W', 'At night the inverter goes offline.', NULL, 'https://www.aliexpress.com/item/1005004174104849.html', 'http://www.newenergytek.com/index.php/content-43', 'SG300MS', '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'micro_inverter', '2', 'Cumulative_kWh', NULL, NULL, 'INTE2FLOAT', 'RO', NULL, NULL),
 ('', 'micro_inverter', '10', 'out_W', NULL, NULL, 'BYTESMALLFLOAT', 'RO', NULL, NULL),
 ('', 'micro_inverter', '15', 'Model', 'string', NULL, NULL, 'RO', NULL, NULL),
 ('', 'micro_inverter', '16', 'HW_ID', 'string', NULL, NULL, 'RO', NULL, NULL),
 ('', 'micro_inverter', '102', 'DC_I', NULL, NULL, 'INTE2FLOAT', 'RO', NULL, NULL),
 ('', 'micro_inverter', '103', 'DC_V', NULL, NULL, 'BYTESMALLFLOAT', 'RO', NULL, NULL),
 ('', 'micro_inverter', '104', 'AC_V', NULL, NULL, 'BYTESMALLFLOAT', 'RO', NULL, NULL),
 ('', 'micro_inverter', '105', 'AC_I', NULL, NULL, 'INTE2FLOAT', 'RO', NULL, NULL);