INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('Ozone_PDMtimer', 'timerPDM02', 'Ozone_PDMtimer.jpg', 'custom', 'MQTT device', 'other', 'AC', 'SET,GET,REFRESH', 'Stand alone timer for ozone generators, MQTT interface,  node-red and Android UI', 'Do not requires MQTT broker, uses esp_MQTT', 'fom a WiFi switch Sonoff S20 or basic.', 'https://www.aliexpress.com/item/32873063240.html', 'https://github.com/msillano/Ozone-coronavirus-sonoff/blob/master/PROJECTS-DIY/timerPDM/timerPDM_sonoff_en.pdf', 'timerPDM02', '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'Ozone_PDMtimer', '_clock', NULL, 'string', 'HH:MM:SS (locale)', NULL, 'RW', 'device clock, also in the _info string', 'SET forces _timezone = 0, used in &#39;soloAP&#39; mode '),
 ('', 'Ozone_PDMtimer', '_count', NULL, NULL, 'ONtime|OFFtime...0 [minutes]', NULL, 'PUSH', 'countdown to TOGGLE', 'Also in the _info string'),
 ('', 'Ozone_PDMtimer', '_countdown', NULL, NULL, '60...0[sec]', NULL, 'PUSH', 'manual button GO countdown ', 'Also in the _info string'),
 ('', 'Ozone_PDMtimer', '_end', NULL, NULL, 'any', NULL, 'WO', 'trigger', 'SET in OFF mode'),
 ('', 'Ozone_PDMtimer', '_go', NULL, NULL, 'any', NULL, 'WO', 'trigger', 'Start now, from remote: immediate'),
 ('', 'Ozone_PDMtimer', '_info', NULL, NULL, '&#60;status> like &#39;08:29:22 Loop: ON 58% (4/5)&#39;', NULL, 'PUSH', 'For UI, until every second', '_refreshCycle controls the period'),
 ('', 'Ozone_PDMtimer', '_led', NULL, NULL, 'gray|green|red (native 0|1|2)', NULL, 'PUSH', 'blink green: waiting MODE, green: waiting START | switch   OFF, red: switch ON', 'duplicates real LEDs, _refreshCycle controls the period'),
 ('', 'Ozone_PDMtimer', '_mode', NULL, NULL, 'OFF|AUTO|LOOP (native: 0|1|2)', NULL, 'RW', 'Forces passage to OFF. Also mode in the _info string', 'Then wait for &#39;_startTime&#39; (AUTO) or &#39;_go&#39; (AUTO, LOOP immadiate) or button (AUTO, LOOP delayed)'),
 ('', 'Ozone_PDMtimer', '_off', NULL, NULL, 'any', NULL, 'WO', 'trigger', 'SET switch OFF, but don&#39;t change mode (pause).'),
 ('', 'Ozone_PDMtimer', '_OFFtime', NULL, 'int', 'min', NULL, 'RW', 'For LOOP mode', 'Also in the _info string'),
 ('', 'Ozone_PDMtimer', '_ONtime', NULL, 'int', 'min', NULL, 'RW', 'For AUTO and LOOP mode', 'Also in the _info string'),
 ('', 'Ozone_PDMtimer', '_PDM', NULL, 'int', '2..100 (%)', NULL, 'RW', 'Generator power control', 'Also in the _info string'),
 ('', 'Ozone_PDMtimer', '_pssw', NULL, NULL, 'Wifi router password', NULL, 'PUSH', 'SET ssid password and enables STA mode', 'only in &#39;soloAP&#39; mode'),
 ('', 'Ozone_PDMtimer', '_refresh', NULL, NULL, 'any', NULL, 'WO', 'trigger (same as _send)', 'standard REFRESH function'),
 ('', 'Ozone_PDMtimer', '_refreshCycle', NULL, 'int', 'N [sec]', NULL, 'RW', 'Sets push _info, _led period, implemented filtering MQTT (native: 1s)', 'better to use odd numbers to capture led blinking'),
 ('', 'Ozone_PDMtimer', '_send', NULL, NULL, 'any', NULL, 'WO', 'trigger', 'resend some data'),
 ('', 'Ozone_PDMtimer', '_ssid', NULL, 'string', 'Wifi router name', NULL, 'PUSH', 'If NOT fallowed by _pssw, blocks STA', 'only in &#39;soloAP&#39; mode'),
 ('', 'Ozone_PDMtimer', '_startTime', NULL, 'string', 'HH:MM[:SS]', NULL, 'RW', 'AUTO mode only', 'Also in the _info string'),
 ('', 'Ozone_PDMtimer', '_switch', NULL, NULL, '0|1 => OFF|ON', 'BOOLEANONOFF', 'PUSH', 'Output relay status', 'Also in the _info string'),
 ('', 'Ozone_PDMtimer', '_timezone', NULL, 'int', '-12... + 12', NULL, 'RW', 'Only if clock is from NTP server', 'SET _clock forces _timezone to 0');