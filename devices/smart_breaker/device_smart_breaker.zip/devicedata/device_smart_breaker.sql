INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('smart_breaker', 'S3077', 'smart_breaker.jpg', 'Breaker', 'ily6yaiza2eytgnc', 'WiFi', 'AC', 'ALL', 'Good switch rich of features: circulate and random with week planning, countdown and inching.', 'Any GET sends all data (like SCHEMA), SET:null works OK, so all dp &#39;WW&#39;', NULL, 'https://www.aliexpress.com/item/1005001863612580.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'smart_breaker', '1', 'relay', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', NULL, NULL),
 ('', 'smart_breaker', '9', 'countdown', 'int', '0..86500 s (24H max.)', NULL, 'WW', 'Relay toggles when count reaches 0. SET:0  no toggle.', 'PUSHed every 30 sec.'),
 ('', 'smart_breaker', '38', 'restart status', 'string', 'off|on|memory', NULL, 'WW', NULL, NULL),
 ('', 'smart_breaker', '40', 'light mode', 'string', 'pos|none|relay', NULL, 'WW', 'Led BLUE: as &#39;relay&#39; = OFF/ON, &#39;pos&#39; (position) inverted = ON/OFF, &#39;none&#39; = always OFF', NULL),
 ('', 'smart_breaker', '41', 'child lock', 'boolean', 'true|false  = ON|OFF', 'BOOLEANONOFF', 'WW', 'in lock mode, the manual switch does not toggle the relay.', NULL),
 ('', 'smart_breaker', '42', 'circulate', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM,  end: HH:MM, on: HH:MM, off: HH:MM}', 'STRUCTREPEAT', 'WW', 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once.', 'SET:[] to clear'),
 ('', 'smart_breaker', '43', 'random', 'binary', 'array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM  end: HH:MM}', 'STRUCTRAND', 'WW', 'day: skip=&#39;-&#39;, do: any char. If day:&#39;-------&#39;, once.', 'SET:[] to clear'),
 ('', 'smart_breaker', '44', 'inching', 'binary', ' { inching: true|false delay: 0..3660} in sec', 'STRUCTINCH', 'WW', 'The inching (temporary) counter', 'SET:{} to clear');