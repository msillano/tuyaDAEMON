INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('multi_gateway02', 'RSH-GW018', 'multi_gateway02.png', NULL, NULL, 'WiFi', 'USB', 'ALL', 'Tuya Multi Mode ZigBee 3.0, Bluetooth 5.0 BLE Gateway Hub ', 'see also multi_gateway device', NULL, 'https://www.aliexpress.com/item/1005005875938991.html', 'https://www.alibaba.com/product-detail/RSH-Mini-Smart-Home-Hub-Tuya_1600197226609.html', NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'multi_gateway02', '4', 'switch_alarmsound', 'boolean', 'true|false', NULL, 'RW', NULL, NULL),
 ('', 'multi_gateway02', '32', 'master_state', 'string', '&#39;normal&#39;|&#39;alarm&#39;', NULL, 'RW', 'SET &#39;alarm&#39; changes dP 4 to &#39;true&#39;', NULL),
 ('', 'multi_gateway02', '34', 'factory reset', 'boolean', 'true|false', NULL, 'RW', 'not tested', NULL),
 ('', 'multi_gateway02', '45', 'alarm_active', 'string', NULL, NULL, 'PUSH', 'SET-GET causes error', NULL);