INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('watering_sys', 'ver. 1.0', 'watering_sys.jpg', 'derived device', 'none', 'WiFi', 'AC', 'SET,GET', 'Advanced watering controller, derived from standard Tuya switches', 'This fake derived device uses one  &#39;smart_breaker&#39;  and one Smart_Switch01. Days and time programming.', 'Fuzzy logic for PDM control using data shared from external sensors. ', NULL, NULL, 'ver. 1.0', '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'watering_sys', '1', 'relay', 'string', 'ON|OFF', NULL, 'RW', 'temporally, until next programmed time.', ' Inheritance from &#39;smart_breaker&#39;,dp(1)'),
 ('', 'watering_sys', '1ans', 'share relay', 'string', 'see dp 1', NULL, 'PUSH', 'pushed share message', 'internal use'),
 ('', 'watering_sys', '2', 'switch', 'string', 'ON|OFF', NULL, 'RW', 'when the &#39;switch&#39; is OFF, the &#39;timer&#39; is disconnected (no power)', ' inheritance from &#39;Smart_Switch01&#39;,dp(1)'),
 ('', 'watering_sys', '2ans', 'share switch', 'string', 'see dp 2', NULL, 'PUSH', 'pushed share message', 'internal use'),
 ('', 'watering_sys', '3', 'toggle timer', NULL, 'any', NULL, 'WO', 'trigger, changes output temporally, until next programmed time', 'Implemented setting &#39;countdown&#39; = 1 '),
 ('', 'watering_sys', '4', 'adjust water', 'number', '0...100 (%)', NULL, 'RO', 'calculated by fuzzy controller once a day', NULL),
 ('', 'watering_sys', '5', 'waterweek', 'int', '0.... ', NULL, 'RW', 'litres/week of water. With a slider the user defines the max value.', NULL),
 ('', 'watering_sys', '6', 'reset', NULL, 'any', NULL, 'WO', 'trigger.', 'Initialize and restore saved programming data.'),
 ('', 'watering_sys', '42', 'circulate', 'binary', 'decoded: array of {active: true|false, day:SMTWTFS|DLMMGVS, start HH:MM, end: HH:MM, on: HH:MM, off: HH:MM}', NULL, 'RW', 'stored in the breaker: + water/week, + adjust + store-times, to get persistence.', 'inheritance from &#39;smart_breaker&#39;,dp(42)'),
 ('', 'watering_sys', '42ans', 'timer circulate', 'binary', 'see dp 42', NULL, 'PUSH', 'pushed share message', 'internal use'),
 ('', 'watering_sys', '111', 'timer connected', 'boolean', 'true|false ', NULL, 'PUSH', NULL, '&#39;use&#39; info from &#39;smart_breaker&#39;,dp(_connected)'),
 ('', 'watering_sys', '112', 'main connected', 'boolean', 'true|false', NULL, 'PUSH', NULL, '&#39;use&#39; info from &#39;smart_switch&#39;,dp(_connected)'),
 ('', 'watering_sys', '201', 'Temp', 'int', '-20... +50 °C', NULL, 'PUSH', 'External temperature for fuzzy controller ', '&#39;use&#39; info from &#39;external&#39; sensor,dp(103)'),
 ('', 'watering_sys', '202', 'RH', 'int', '0..100 %', NULL, 'PUSH', 'External Relative Humidity for fuzzy controller', '&#39;use&#39; info from &#39;external&#39; sensor,dp(101)');