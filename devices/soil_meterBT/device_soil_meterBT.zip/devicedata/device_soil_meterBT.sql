INSERT INTO `deviceinfos` (`dName`, `model`, `picName`, `tuyaType`, `tuyaProductID`, `protocol`, `power`, `capabilities`, `description`, `note01`, `note02`, `sellerURL`, `refURL`, `infoURL`, `copynotice`) VALUES
('soil_meterBT', NULL, 'soil_meterBT.png', NULL, NULL, 'Bluethoot', 'BAT', 'SET', 'Soil Humidity  and Temperature Meter  ', 'data PUSHed, random intervals (?)', NULL, 'https://www.aliexpress.com/item/1005005237033834.html', NULL, NULL, '2021 marco.sillano@gmail.com'); 
INSERT INTO `devicedpoints` (`id`, `dName`, `DPnumber`, `DPname`, `DPtype`, `DPvalues`, `DPdecode`,
       `DPcapability`, `DPnote01`, `DPnote02`) VALUES   
 ('', 'soil_meterBT', '3', 'humidity', NULL, '0..100 (%)', NULL, 'RO', 'soil humidity ', 'GET returns all data (like SCHEMA) '),
 ('', 'soil_meterBT', '5', 'temperature', NULL, NULL, 'BYTESMALLFLOAT', 'RO', NULL, 'GET returns all data (like SCHEMA) '),
 ('', 'soil_meterBT', '9', 'unit', NULL, '&#39;c&#39;|&#39;f&#39;', NULL, 'RW', 'hit for UI temperature.', 'GET returns all data (like SCHEMA) '),
 ('', 'soil_meterBT', '14', 'batt_level', NULL, '&#39;low&#39;|&#39;middle&#39;|&#39;hight&#39;', NULL, 'RO', 'battery level', 'GET returns all data (like SCHEMA) '),
 ('', 'soil_meterBT', '15', 'batt_charge', NULL, '0..100 (%)', NULL, 'RO', 'Battery SOC (%)', 'GET returns all data (like SCHEMA) ');