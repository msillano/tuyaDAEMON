INSTALLAZIONE TUYADAMON-CORE (minima)
ver 2.2.2


tuyaDAEMOH è un potente ambiente di sviluppo IOT aperto.
sito TuyaDAEMON: https://github.com/msillano/tuyaDAEMON
WIKI:  https://github.com/msillano/tuyaDAEMON/wiki

Si è fatto ogni sforzo per documentare e semplificare ogni operazione, ma, 
per ottenere un ambiente di sviluppo caratterizzato dalla massima 
flessibilità, sono necessari alcuni interventi dell'utente in node-red.

tuyaDAEMON.CORE-install-2.2.2\
		readme.it.txt
		readme.en.txt
		tuyadaemon-core.2.2.2.json			    flow, da importare in node-red
    	DB_CORE.2.2.2.sql						eseguire in phpMyAdmin per creare le tavole del DB
		tutadaemontoolkit\
			device__core.zip					standard documentazione del device _core
		
1) INSTALLAZIONE CORE
    Seguire le istruzioni generali qui: 
	  https://github.com/msillano/tuyaDAEMON/blob/main/tuyaDAEMON/README.md#first-time-installation-core

    Ogni flow importato viene avviato subito dopo il 'Deploy', è il
	funzionamento normale di node-red. Potete avere dei messaggi di errore:
	ignorateli per ora e proseguite con la configurazione.

2) CONFIGURAZIONE
    Guida generale: https://github.com/msillano/tuyaDAEMON/blob/main/tuyaDAEMON/README.md#configuration-all-modules
    Vedi  'Global core config' node 'info'.
 
3) RUNTIME
    TuyaDAEMON presenta i messaggi di LOG e di ERRORE nel 'sidebar'.'Debug 
	messages'. Assicurarsi che 'Filter messages' sia su 'all nodes'.
	
	Al runtime TuyaDAEMON cerca di intercettare ogni errore e fornire messaggi 
	chiari e utili per il debug, spesso uniti ad una copia dei dati che 
	causano l'errore.
	
	Ogni modulo ha nella parte inferiore, piccoli 'flow' di test. Usateli per 
	familiarizzare con le capabilities del modulo e per fare i vostri test.
	Ogni test ha info nel proprio nodo 'inject'. 

4) INSTALLAZIONE COMPLETA (opzionale)

    In qualunque momento potete aggiungere i seguenti moduli di base:

  - SYSTEM  - aggiunge molte utiliy e funzioni di controllo. 
               Vedi: https://github.com/msillano/tuyaDAEMON/wiki/custom-device-_system  

  - MQTT    - aggiunge un MQTT broker, abilita l'uso di 'MQTT Explorer' come 
              UI.
               Vedi https://github.com/msillano/tuyaDAEMON#mqtt-interface

  - TRIGGER - aggiunge un canale bidirezionale con Tuya Cloud e permette di 
              creare device 'mirror'. 
			  Utile se volete usate device Tyua NON compatibili con tuyaAPI 
			   (e.g. sensori WiFi a battera)
               Vedi https://github.com/msillano/tuyaDAEMON/wiki/tuyaTRIGGER-info

 Extra:
   Se avete installato un server HTTP (Apache) e prevedete di usare molti 
   diversi device, potete installare l'utility 'tuyaDAEMON-toolkit', un tool 
   in PHP e MySQL per la definizione e gestione dei nuovi device.
      Vedi https://github.com/msillano/tuyaDAEMON/wiki/tuyaDAEMON-toolkit

5) SVILUPPO E PERSONALIZZAZIONE

L'obiettivo di TuyaDAEMON è quello di fornirvi un ambiente di sviluppo IOT: 
quindi una volta installato CORE (ed eventualmente SYSTEM, MQTT, TRIGGER) dovete
inserire i vostri device e dovete usarlo per le vostre applicazioni.

Scoprirete che molte applicazioni IOT possono essere implementate usando solo le 
risorse di TuyaDAEMON, senza sviluppare flow node-red specifici.

Per approfondire tuyaDAEMON
   vedi WIKI/"tuyaDAEMON as event processor": https://github.com/msillano/tuyaDAEMON/wiki/tuyaDAEMON-as-event-processor
   vedi WIKI/"ver. 2.0  milestones": https://github.com/msillano/tuyaDAEMON/wiki/ver.-2.0--milestones

