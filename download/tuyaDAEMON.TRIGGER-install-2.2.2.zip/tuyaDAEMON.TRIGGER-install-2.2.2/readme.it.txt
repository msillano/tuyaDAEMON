INSTALLAZIONE TUYADAEMON-TRIGGER
ver 2.2.2


TuyaDAEMON è un potente ambiente di sviluppo IOT aperto.
sito TuyaDAEMON: https://github.com/msillano/tuyaDAEMON
WIKI:  https://github.com/msillano/tuyaDAEMON/wiki

Si è fatto ogni sforzo per documentare e semplificare ogni operazione, ma, 
per ottenere un ambiente di sviluppo caratterizzato dalla massima 
flessibilità, sono necessari alcuni interventi dell'utente in node-red.

QUESTO MODULO RICHIEDE TuyaDAEMON CORE, SYSTEM INSTALLATI e FUNZIONANTI

tuyaDAEMON.TRIGGER-install-2.2.2\
		readme.it.txt
		readme.en.txt
		tuyadaemon-trigger.2.2.2.json	  	   core_TRIGGER flow, da importare in node-red
		tuyadaemon-mirror_devices.2.2.2.json   esempio, da importare in node-red, vedi oltre.
		device__trigger.json				   Per CORE.'global.alldevices' vedi configurazione.
		tuyadaemontoolkit\
		     device__trigger.zip			   standard documentazione del device _trigger
		
1) INSTALLAZIONE TRIGGER
   
    Importare in node_red il file tuyadaemon-trigger.2.2.2.json
	Importare in node-red il file tuyadaemon-mirror_devices.2.2.2.json, ma 
	     lasciarlo disabilitato (si può fare anche in un secondo tempo).
   
    Ogni flow importato viene avviato subito dopo il 'Deploy', è il
	funzionamento normale di node-red. Potete avere dei messaggi di errore:
	ignorateli per ora e proseguite con la configurazione.

2) CONFIGURAZIONE
     Vedi  '*Global trigger config' node 'info'.
 
3) RUNTIME
    TuyaDAEMON presenta i messaggi di LOG e di ERRORE nel 'sidebar'.'Debug 
	messages'. Assicurarsi che 'Filter messages' sia su 'all nodes'.
	
	Al runtime TuyaDAEMON cerca di intercettare ogni errore e fornire messaggi 
	chiari e utili per il debug, spesso uniti ad una copia dei dati che 
	causano l'errore.
	
	Ogni modulo ha nella parte inferiore, piccoli 'flow' di test. Usateli per 
	familiarizzare con le capabilities del modulo e per fare i vostri test.
	Ogni test ha info nel proprio nodo 'inject'. 
	
4) MIRROR DEVICES
    Il flow 'mirror_devices' è un esempio di uso dei TRIGGER e di 'mirror' 
	device sfruttando 'tuya_bridge'. 	
	Importare il flow in node-red, e lascirlo 'disabilitato'. Usarlo come 
	istruzioni (leggere i readme) e modello per aggiungere i vostri TRIGGER 
	custom e i vostri 'mirror' device.
	

5) SVILUPPO E PERSONALIZZAZIONE

L'obiettivo di TuyaDAEMON è quello di fornirvi un ambiente di sviluppo IOT: 
quindi una volta installato TRIGGER (ed eventualmente MQTT) vorrete
inserire i vostri device ed usarlo per le vostre applicazioni.

Per aggiungere device 'mirror', ovvero device Tuya non connessi da tuyaAPI, 
tipicamente sensori a batteria:
   vedi WIKI/"tuyaTRIGGER info": https://github.com/msillano/tuyaDAEMON/wiki/tuyaTRIGGER-info
   vedi esempi in 'mirror_devices' flow, con istruzioni nei readme.
 
Buon divertimento.