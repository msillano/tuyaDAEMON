INSTALLING TUYADAEMON-TRIGGER
ver 2.2.2


TuyaDAEMON is a powerful open IOT development environment.
TuyaDAEMON site: https://github.com/msillano/tuyaDAEMON
WIKI: https://github.com/msillano/tuyaDAEMON/wiki

Every effort has been made to document and simplify every operation, but,
to obtain a development environment characterized by the maximum
flexibility, some user intervention is required in node-red.

THIS MODULE REQUIRES TuyaDAEMON CORE, SYSTEMS INSTALLED and RUNNING

tuyaDAEMON.TRIGGER-install-2.2.2\
      readme.it.txt
      readme.en.txt
      tuyadaemon-trigger.2.2.2.json 		core_TRIGGER flow, to import into node-red
	  tuyadaemon-mirror_devices.2.2.2.json  example, to import into node-red.
      device__trigger.json                  For CORE.'global.alldevices' see configuration.
	  tuyadaemontoolkit\
            device__trigger.zip             standard device _trigger documentation

1) TRIGGER INSTALLATION
   
   Import the tuyadaemon-trigger.2.2.2.json file into node_red
   Import the tuyadaemon-mirror_devices.2.2.2.json file into node-red,
   but leave it disabled (you can also do it later).
   
   Each imported flow is started immediately after 'Deploy', it is the
   normal operation of node-red. You may get error messages:
   ignore them for now and continue with the configuration.

2) CONFIGURATION

      See '*Global trigger config' node 'info'.
 
3) RUNTIME

     TuyaDAEMON presents LOG and ERROR messages in the 'sidebar'.'Debug
     messages'. Make sure 'Filter messages' is set to 'all nodes'.

At runtime TuyaDAEMON tries to catch any errors and provide messages
clear and useful for debugging, often combined with a copy of the data that
cause the error.

Each module has small test 'flows' at the bottom. Use them for
familiarize yourself with the capabilities of the module and to do your own tests.
Each test has info in its own 'inject' node.

4) MIRROR DEVICES flow

     The flow 'mirror_devices' is an example of using TRIGGER and 'mirror'
     device using 'tuya_bridge'.
     Import the flow into node-red, and leave it 'disabled'. Use it like
     instructions (read the readme) and template to add your TRIGGERs
     custom and your 'mirror' devices.


5) DEVELOPMENT AND CUSTOMIZATION

     The goal of TuyaDAEMON is to provide you with an IOT development environment:
     so once TRIGGER (and possibly MQTT) is installed you will want
     insert your devices and use it for your applications.

     To add 'mirror' devices, i.e. Tuya devices not connected by tuyaAPI,
     typically battery operated sensors:
        see WIKI/"tuyaTRIGGER info": https://github.com/msillano/tuyaDAEMON/wiki/tuyaTRIGGER-info
        see examples in 'mirror_devices' flow, with instructions in readme.
 
Good fun.