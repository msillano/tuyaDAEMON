INSTALLAZIONE TUYADAEMON-MQTT
ver 2.2.2


TuyaDAEMON è un potente ambiente di sviluppo IOT aperto.
sito TuyaDAEMON: https://github.com/msillano/tuyaDAEMON
WIKI:  https://github.com/msillano/tuyaDAEMON/wiki

Si è fatto ogni sforzo per documentare e semplificare ogni operazione, ma, 
per ottenere un ambiente di sviluppo caratterizzato dalla massima 
flessibilità, sono necessari alcuni interventi dell'utente in node-red.

QUESTO MODULO RICHIEDE TuyaDAEMON CORE INSTALLATO e FUNZIONANTE

tuyaDAEMON.MQTT-install-2.2.2\
		readme.it.txt
		readme.en.txt
		tuyadaemon-mqtt.2.2.2.json		core_MQTT flow, da importare in node-red
		
1) INSTALLAZIONE MQTT
   
    Importare in node_red il file tuyadaemon-mqtt.2.2.2.json
	nota: non è un device, non richiede estensioni di 'global.alldevices'.
   
    Ogni flow importato viene avviato subito dopo il 'Deploy', è il
	funzionamento normale di node-red. Potete avere dei messaggi di errore:
	ignorateli per ora e proseguite con la configurazione.

2) CONFIGURAZIONE
     Vedi  '*Global MQTT config' node 'info'.
 
3) SVILUPPO E PERSONALIZZAZIONE
     - L'utente può cambiare la struttura dei topic
     - Varie configurazioni sono possibili in caso di multiple istanze in rete di tuyaDAEMON.
       Vedi  '*Global MQTT config' node 'info'.
