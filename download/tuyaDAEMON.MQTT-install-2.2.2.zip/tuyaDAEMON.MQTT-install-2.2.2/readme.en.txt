INSTALLING TUYADAEMON-MQTT
ver 2.2.2


TuyaDAEMON is a powerful open IOT development environment.
TuyaDAEMON site: https://github.com/msillano/tuyaDAEMON
WIKI: https://github.com/msillano/tuyaDAEMON/wiki

Every effort has been made to document and simplify every operation, but,
to obtain a development environment characterized by the maximum
flexibility, some user intervention is required in node-red.

THIS MODULE REQUIRES TuyaDAEMON CORE INSTALLED and WORKING


tuyaDAEMON.MQTT-install-2.2.2\
          readme.it.txt
          readme.en.txt
          tuyadaemon-mqtt.2.2.2.json      core_MQTT flow, to import into node-red


1) MQTT INSTALLATION
   
     Import the tuyadaemon-mqtt.2.2.2.json file into node_red.
     note: it's not a device, it doesn't require extensions of 'global.alldevices'.
   
     Each imported flow is started immediately after 'Deploy', it is the
     normal operation of node-red. You may get error messages:
     ignore them for now and continue with the configuration.

2) CONFIGURATION
      See '*Global MQTT config' node 'info'.
 
3) DEVELOPMENT AND CUSTOMIZATION

      Various configurations are possible in case of multiple networked instances of tuyaDAEMON.
      See '*Global MQTT config' node 'info'.
