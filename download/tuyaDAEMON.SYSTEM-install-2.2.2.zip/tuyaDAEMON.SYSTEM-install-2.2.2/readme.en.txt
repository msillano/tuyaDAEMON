TUYADAEMON-SYSTEM INSTALLATION
ver 2.2.2


    TuyaDAEMON is a powerful open IOT development environment.
      TuyaDAEMON site: https://github.com/msillano/tuyaDAEMON
      WIKI: https://github.com/msillano/tuyaDAEMON/wiki

    Every effort has been made to document and simplify every operation, but,
    to obtain a development environment characterized by the maximum
    flexibility, some user intervention is required in node-red.

THIS MODULE REQUIRES TuyaDAEMON CORE INSTALLED and WORKING

   tuyaDAEMON.SYSTEM-install-2.2.2\
         readme.it.txt
         readme.en.txt
         tuyadaemon-system.2.2.2.json		core_SYSTEM flow, to import into node-red
         device__system.json 				For CORE.'global.alldevices': copy the content to 'fake'.
         tuyadaemontoolkit\
                device__system.zip 			standard device '_system' documentation

1) 'SYSTEM' INSTALLATION
   
     Import the tuyadaemon-system.2.2.2.json file into node_red
   
     Each imported flow is started immediately after 'Deploy', it is the
     normal operation of node-red. You may get error messages: 
     ignore them for now and continue with the configuration.

2) CONFIGURATION
     See '*Global system config' node 'info'.
 
3) RUNTIME
     TuyaDAEMON presents LOG and ERROR messages in the 'sidebar'.'Debug
     messages'. Make sure 'Filter messages' is set to 'all nodes'.

     At runtime TuyaDAEMON tries to catch any errors and provide messages
     clear and useful for debugging, often combined with a copy of the data that
     cause the error.



     Each module has small test 'flows' at the bottom. Use them for
     familiarize yourself with the capabilities of the module and to do your own tests.
     Each test has info in its own 'inject' node.

4) FULL INSTALLATION (optional)

     You can add the following basic modules at any time:

    - MQTT - add MQTT broker, enable use of 'MQTT Explorer' as UI.
                See https://github.com/msillano/tuyaDAEMON#mqtt-interface

   - TRIGGER - adds a two-way channel with Tuya Cloud and allows you to
               create 'mirror' devices.
               Useful if you want to use Tyua devices NOT compatible with tuyaAPI
               (e.g. battery-operated WiFi sensors)
                See https://github.com/msillano/tuyaDAEMON/wiki/tuyaTRIGGER-info

  Extra:
    If you have an HTTP server (Apache) installed and plan to use many
    different devices, you can install the 'tuyaDAEMON-toolkit' utility, a tool
    in PHP and MySQL for the definition and management of new devices.
       See https://github.com/msillano/tuyaDAEMON/wiki/tuyaDAEMON-toolkit

5) DEVELOPMENT AND CUSTOMIZATION

     The goal of TuyaDAEMON is to provide you with an IOT development environment:
     so once installed CORE + SYSTEM (and eventually MQTT, TRIGGER) you have to
     enter your devices and you have to use it for your applications.

     You will find that many IoT applications can be implemented using just the
     TuyaDAEMON resources, without developing specific node-red flows.

To learn more tuyaDAEMON
    see WIKI/"tuyaDAEMON as event processor": https://github.com/msillano/tuyaDAEMON/wiki/tuyaDAEMON-as-event-processor
    see WIKI/"ver. 2.0 milestones": https://github.com/msillano/tuyaDAEMON/wiki/ver.-2.0--milestones

To add standard Tuya devices,
    see WIKY/"Howto: add a new device to tuyaDAEMON". https://github.com/msillano/tuyaDAEMON/wiki/Howto:-add-a-new-device-to-tuyaDAEMON

To add 'mirror' devices, i.e. Tyua devices, not connected by tuyaAPI,
    you use tuyaTRIGGER:
    see WIKI/"tuyaTRIGGER info": https://github.com/msillano/tuyaDAEMON/wiki/tuyaTRIGGER-info
    see WIKY/"mirror device 'Smoke_Detector': case study", https://github.com/msillano/tuyaDAEMON/wiki/mirror-device-'Smoke_Detector':-case-study

To define 'derived' devices, which are composed of one or more existing devices
   (Object Oriented style):
   - see: https://github.com/msillano/tuyaDAEMON/wiki/ver.-2.0--milestones
   - see WIKY example/"derived device 'watering_sys': case study" https://github.com/msillano/tuyaDAEMON/wiki/derived-device-'watering_sys':-case-study

To add non-Tuya devices (custom or third-party) you must always develop
a flow node-red interface. Some examples serve as a guide:
   - USB/COM device: see WIKY/"custom device 'PM-detector': case study". https://github.com/msillano/tuyaDAEMON/wiki/custom-device-'PM-detector':-case-study
   - MQTT device: see WIKY/"custom MQTT device 'Ozone_PDMtimer'". https://github.com/msillano/tuyaDAEMON/wiki/custom-device--MQTT-'Ozone_PDMtimer'-
   - 433MHz device: see WIKY/"case study: 433 MHz weather station" https://github.com/msillano/tuyaDAEMON/wiki/case-study:-433-MHz-weather-station
  
To add software-only devices, i.e. libraries that add functionality
of specific interest to tuyaDAEMON, external API stubs etc.:
   - see example SYSTEM: https://github.com/msillano/tuyaDAEMON/wiki/custom-device-_system